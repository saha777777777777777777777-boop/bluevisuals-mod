package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class HudOverlay {
    private static double fx;
    private static double fy;
    private static double fz;
    private static double rx;
    private static double rz;
    private static double ux;
    private static double uy;
    private static double uz;
    private static double tanHalf;
    private static double aspect;
    private static int sw;
    private static int sh;
    private static Vec3d cam;

    public static void register() {
        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            BlueConfig cfg = BlueConfig.get();
            if (mc.player == null || mc.world == null || mc.options.hudHidden) {
                return;
            }
            Camera c = mc.gameRenderer.getCamera();
            if (c == null || !c.isReady()) {
                return;
            }
            float td = tick.getTickDelta(false);
            cam = c.getPos();
            double yaw = Math.toRadians(c.getYaw());
            double pitch = Math.toRadians(c.getPitch());
            fx = -Math.sin(yaw) * Math.cos(pitch);
            fy = -Math.sin(pitch);
            fz = Math.cos(yaw) * Math.cos(pitch);
            rx = -Math.cos(yaw);
            rz = -Math.sin(yaw);
            ux = -rz * fy;
            uy = rz * fx - rx * fz;
            uz = rx * fy;
            tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
            sw = mc.getWindow().getScaledWidth();
            sh = mc.getWindow().getScaledHeight();
            aspect = (double) sw / sh;
            int rgb = 0xFF000000 | BlueConfig.rgb();

            if (cfg.hologram) {
                float time = mc.world.getTime() + td;
                Entity target = null;
                if (!cfg.hologramAll) {
                    Entity looked = mc.targetedEntity;
                    if (looked instanceof PlayerEntity && looked != mc.player) {
                        target = looked;
                    } else if (HitEffects.lastTarget instanceof PlayerEntity && !HitEffects.lastTarget.isRemoved()
                            && mc.world.getTime() - HitEffects.lastHitTime < 60) {
                        target = HitEffects.lastTarget;
                    }
                }
                for (Entity e : mc.world.getEntities()) {
                    if (!(e instanceof PlayerEntity) || e == mc.player || e.isRemoved()) {
                        continue;
                    }
                    if (!cfg.hologramAll && e != target) {
                        continue;
                    }
                    double lim = cfg.lite ? 32.0 : 48.0;
                    if (mc.player.squaredDistanceTo(e) > lim * lim) {
                        continue;
                    }
                    double x = MathHelper.lerp(td, e.prevX, e.getX());
                    double y = MathHelper.lerp(td, e.prevY, e.getY()) + e.getHeight() * 0.5;
                    double z = MathHelper.lerp(td, e.prevZ, e.getZ());
                    double[] p = project(x, y, z);
                    if (p == null) {
                        continue;
                    }
                    double half = Math.max(8.0, (e.getHeight() * 0.6) * p[2]);
                    drawSquare(ctx, p[0], p[1], half, time * 0.07, rgb);
                    if (!cfg.lite) {
                        drawSquare(ctx, p[0], p[1], half * 0.7, -time * 0.09, rgb);
                    }
                }
            }

            int index = 0;
            for (BlueConfig.Marker mk : cfg.markers) {
                index++;
                double[] p = project(mk.x, mk.y + 1.0, mk.z);
                if (p == null) {
                    continue;
                }
                int px = (int) MathHelper.clamp(p[0], 12, sw - 12);
                int py = (int) MathHelper.clamp(p[1], 12, sh - 24);
                double dx = mk.x - mc.player.getX();
                double dy = mk.y - mc.player.getY();
                double dz = mk.z - mc.player.getZ();
                int dist = (int) Math.sqrt(dx * dx + dy * dy + dz * dz);
                String name = (mk.name == null || mk.name.isEmpty()) ? "Метка " + index : mk.name;
                String label = name + "  " + dist + " бл";
                ctx.fill(px - 4, py - 4, px + 5, py + 5, 0xFF000000);
                ctx.fill(px - 3, py - 3, px + 4, py + 4, rgb);
                int w = mc.textRenderer.getWidth(label);
                ctx.fill(px - w / 2 - 2, py + 7, px + w / 2 + 3, py + 18, 0x90000000);
                ctx.drawText(mc.textRenderer, label, px - w / 2, py + 9, rgb, false);
            }
        });
    }

    // returns {screenX, screenY, pixelsPerBlock} or null when behind camera
    private static double[] project(double x, double y, double z) {
        double dx = x - cam.x;
        double dy = y - cam.y;
        double dz = z - cam.z;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.1) {
            return null;
        }
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double sx = sw / 2.0 * (1.0 + xc / (zc * tanHalf * aspect));
        double sy = sh / 2.0 * (1.0 - yc / (zc * tanHalf));
        double ppb = (sh / 2.0) / (zc * tanHalf);
        return new double[]{sx, sy, ppb};
    }

    private static void drawSquare(DrawContext ctx, double cx, double cy, double half, double ang, int color) {
        double cos = Math.cos(ang);
        double sin = Math.sin(ang);
        double[][] k = {{-half, -half}, {half, -half}, {half, half}, {-half, half}};
        int steps = (int) MathHelper.clamp(half, 6, 40);
        for (int i = 0; i < 4; i++) {
            double ax = k[i][0];
            double ay = k[i][1];
            double bx = k[(i + 1) % 4][0];
            double by = k[(i + 1) % 4][1];
            for (int s = 0; s < steps; s++) {
                double t = (double) s / steps;
                double lx = ax + (bx - ax) * t;
                double ly = ay + (by - ay) * t;
                int x = (int) Math.round(cx + lx * cos - ly * sin);
                int y = (int) Math.round(cy + lx * sin + ly * cos);
                ctx.fill(x, y, x + 2, y + 2, color);
            }
        }
    }
}
