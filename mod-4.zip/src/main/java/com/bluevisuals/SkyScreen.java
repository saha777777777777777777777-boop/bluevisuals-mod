package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class SkyScreen extends Screen {
    private final Screen parent;

    public SkyScreen(Screen parent) {
        super(Text.literal("Небо"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        BlueConfig c = BlueConfig.get();
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = 34;
        int step = 24;

        addToggle(x, y, w, "Оттенок неба", () -> c.skyTint, v -> c.skyTint = v);
        this.addDrawableChild(ButtonWidget.builder(skyLabel(), b -> {
            c.skyColorIndex = (c.skyColorIndex + 1) % BlueConfig.COLOR_RGB.length;
            b.setMessage(skyLabel());
            BlueConfig.save();
        }).dimensions(x, y + step, w, 20).build());
        addToggle(x, y + step * 2, w, "Звёзды ночью", () -> c.stars, v -> c.stars = v);
        addToggle(x, y + step * 3, w, "Падающие кометы", () -> c.fallingStars, v -> c.fallingStars = v);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), b -> this.close())
                .dimensions(x, y + step * 4 + 6, w, 20).build());
    }

    private static Text skyLabel() {
        return Text.literal("Цвет неба: " + BlueConfig.skyColorName());
    }

    private void addToggle(int x, int y, int w, String name, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        this.addDrawableChild(ButtonWidget.builder(label(name, getter.get()), b -> {
            boolean now = !getter.get();
            setter.accept(now);
            b.setMessage(label(name, now));
            BlueConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, 0xFF14062B, 0xFF030208);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 16, 0xFF000000 | BlueConfig.skyRgb());
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
