package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Cosmetics {
    public static final String[] STYLES = {"Ангел", "Демон", "Кристалл"};

    private static final float[][][] WING = {
            {{0.1f, 1.45f}, {0.5f, 1.95f}, {1.2f, 2.15f}, {1.6f, 1.8f}, {1.4f, 1.4f}, {1.1f, 1.0f}, {0.7f, 1.1f}, {0.35f, 0.9f}},
            {{0.1f, 1.45f}, {0.7f, 2.2f}, {0.95f, 1.6f}, {1.5f, 2.0f}, {1.5f, 1.45f}, {2.0f, 1.4f}, {1.3f, 1.0f}, {0.6f, 0.85f}},
            {{0.1f, 1.4f}, {0.4f, 2.1f}, {0.9f, 1.5f}, {1.3f, 2.2f}, {1.5f, 1.3f}, {1.9f, 1.6f}, {1.2f, 0.8f}, {0.5f, 0.7f}}
    };

    private static int cr;
    private static int cg;
    private static int cb;
    private static VertexConsumer vc;
    private static MatrixStack.Entry en;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            BlueConfig cfg = BlueConfig.get();
            if (!cfg.wings && !cfg.mask && !cfg.vest && !cfg.shields && !cfg.halo && !cfg.horns && !cfg.aura) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            en = ctx.matrixStack().peek();
            int rgb = BlueConfig.cosRgb();
            cr = (rgb >> 16) & 0xFF;
            cg = (rgb >> 8) & 0xFF;
            cb = rgb & 0xFF;
            float time = mc.world.getTime() + td;
            boolean first = mc.options.getPerspective().isFirstPerson();

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity) || e.isRemoved()) {
                    continue;
                }
                PlayerEntity p = (PlayerEntity) e;
                boolean self = p == mc.player;
                if (self && first) {
                    continue;
                }
                if (!self) {
                    if (!cfg.cosOthers || cfg.lite || p.isInvisible() || mc.player.squaredDistanceTo(p) > 32 * 32) {
                        continue;
                    }
                }
                float x = (float) (MathHelper.lerp(td, p.prevX, p.getX()) - cam.x);
                float y = (float) (MathHelper.lerp(td, p.prevY, p.getY()) - cam.y);
                float z = (float) (MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z);
                float yaw = (float) Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
                float fx = -MathHelper.sin(yaw);
                float fz = MathHelper.cos(yaw);
                float rx = -MathHelper.cos(yaw);
                float rz = -MathHelper.sin(yaw);
                float drop = p.isInSneakingPose() ? -0.25f : 0.0f;
                y += drop;
                if (cfg.wings) {
                    wings(x, y, z, fx, fz, rx, rz, cfg.wingStyle, time);
                }
                if (cfg.mask) {
                    mask(x, y, z, fx, fz, rx, rz);
                }
                if (cfg.vest) {
                    box(x, y, z, fx, fz, rx, rz, -0.3f, 0.3f, 0.72f, 1.42f, -0.18f, 0.18f);
                    box(x, y, z, fx, fz, rx, rz, -0.2f, -0.05f, 0.85f, 1.0f, 0.18f, 0.26f);
                    box(x, y, z, fx, fz, rx, rz, 0.05f, 0.2f, 0.85f, 1.0f, 0.18f, 0.26f);
                }
                if (cfg.shields) {
                    shields(x, y, z, time);
                }
                if (cfg.halo) {
                    ring(x, y + 2.0f + 0.05f * MathHelper.sin(time * 0.1f), z, 0.32f, time * 0.05f, 20);
                    ring(x, y + 2.0f + 0.05f * MathHelper.sin(time * 0.1f), z, 0.26f, -time * 0.05f, 20);
                }
                if (cfg.aura) {
                    float k = (time * 0.02f) % 1.0f;
                    ring(x, y + 0.05f + k * 1.9f, z, 0.9f - 0.3f * k, time * 0.04f, 24);
                    ring(x, y + 0.05f + ((k + 0.5f) % 1.0f) * 1.9f, z, 0.9f - 0.3f * ((k + 0.5f) % 1.0f), -time * 0.04f, 24);
                }
                if (cfg.horns) {
                    for (int side = -1; side <= 1; side += 2) {
                        float[] pv = null;
                        float[][] hp = {{0.18f, 1.82f, 0.0f}, {0.3f, 1.95f, 0.02f}, {0.36f, 2.1f, 0.06f}, {0.3f, 2.25f, 0.12f}, {0.2f, 2.32f, 0.16f}};
                        for (float[] q : hp) {
                            float[] cur = loc(x, y, z, fx, fz, rx, rz, q[0] * side, q[1], q[2]);
                            if (pv != null) {
                                seg(pv, cur);
                            }
                            pv = cur;
                        }
                    }
                }
            }
        });
    }

    private static void wings(float x, float y, float z, float fx, float fz, float rx, float rz, int style, float time) {
        float[][] pts = WING[Math.floorMod(style, WING.length)];
        float flap = 0.9f + 0.1f * MathHelper.sin(time * 0.15f);
        for (int side = -1; side <= 1; side += 2) {
            float[] px = null;
            float[] first = pts[0];
            for (int i = 0; i < pts.length; i++) {
                float a = pts[i][0] * flap * side;
                float b = pts[i][1];
                float c = -0.15f - Math.abs(a) * 0.3f;
                float[] cur = loc(x, y, z, fx, fz, rx, rz, a, b, c);
                if (px != null) {
                    seg(px, cur);
                }
                // feather lines to shoulder
                if (i > 0) {
                    float[] sh = loc(x, y, z, fx, fz, rx, rz, first[0] * side, first[1], -0.15f);
                    seg(sh, cur);
                }
                px = cur;
            }
            seg(px, loc(x, y, z, fx, fz, rx, rz, first[0] * side, first[1], -0.15f));
        }
    }

    private static void mask(float x, float y, float z, float fx, float fz, float rx, float rz) {
        box(x, y, z, fx, fz, rx, rz, -0.2f, 0.2f, 1.42f, 1.68f, 0.26f, 0.3f);
        box(x, y, z, fx, fz, rx, rz, -0.09f, 0.09f, 1.42f, 1.56f, 0.3f, 0.45f);
        box(x, y, z, fx, fz, rx, rz, -0.28f, 0.28f, 1.55f, 1.68f, -0.28f, 0.28f);
    }

    private static void shields(float x, float y, float z, float time) {
        for (int k = 0; k < 3; k++) {
            double ang = time * 0.06 + k * Math.PI * 2.0 / 3.0;
            float ox = (float) Math.cos(ang) * 1.15f;
            float oz = (float) Math.sin(ang) * 1.15f;
            float tx = (float) -Math.sin(ang);
            float tz = (float) Math.cos(ang);
            for (int r = 0; r < 2; r++) {
                float hw = r == 0 ? 0.3f : 0.2f;
                float lo = r == 0 ? 0.55f : 0.7f;
                float hi = r == 0 ? 1.45f : 1.3f;
                float[] a = {x + ox - tx * hw, y + lo, z + oz - tz * hw};
                float[] b = {x + ox + tx * hw, y + lo, z + oz + tz * hw};
                float[] c = {x + ox + tx * hw, y + hi, z + oz + tz * hw};
                float[] d = {x + ox - tx * hw, y + hi, z + oz - tz * hw};
                seg(a, b);
                seg(b, c);
                seg(c, d);
                seg(d, a);
            }
        }
    }

    private static void ring(float x, float y, float z, float r, float rot, int n) {
        float[] pv = null;
        float[] first = null;
        for (int i = 0; i <= n; i++) {
            float a = rot + (float) (Math.PI * 2.0 * i / n);
            float[] cur = {x + MathHelper.cos(a) * r, y, z + MathHelper.sin(a) * r};
            if (pv != null && (i % 2 == 0)) {
                seg(pv, cur);
            } else if (pv != null && r < 0.5f) {
                seg(pv, cur);
            }
            pv = cur;
        }
    }

    private static float[] loc(float x, float y, float z, float fx, float fz, float rx, float rz, float a, float b, float c) {
        return new float[]{x + rx * a + fx * c, y + b, z + rz * a + fz * c};
    }

    private static void box(float x, float y, float z, float fx, float fz, float rx, float rz,
                            float a1, float a2, float b1, float b2, float c1, float c2) {
        float[][] p = new float[8][];
        int i = 0;
        for (int ai = 0; ai < 2; ai++) {
            for (int bi = 0; bi < 2; bi++) {
                for (int ci = 0; ci < 2; ci++) {
                    p[i++] = loc(x, y, z, fx, fz, rx, rz, ai == 0 ? a1 : a2, bi == 0 ? b1 : b2, ci == 0 ? c1 : c2);
                }
            }
        }
        // index = ai*4 + bi*2 + ci
        for (int k = 0; k < 8; k++) {
            if ((k & 1) == 0) {
                seg(p[k], p[k + 1]);
            }
            if ((k & 2) == 0) {
                seg(p[k], p[k + 2]);
            }
            if ((k & 4) == 0) {
                seg(p[k], p[k + 4]);
            }
        }
    }

    private static void seg(float[] a, float[] b) {
        float dx = b[0] - a[0];
        float dy = b[1] - a[1];
        float dz = b[2] - a[2];
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.0001f) {
            return;
        }
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(en, a[0], a[1], a[2]).color(cr, cg, cb, 255).normal(en, dx, dy, dz);
        vc.vertex(en, b[0], b[1], b[2]).color(cr, cg, cb, 255).normal(en, dx, dy, dz);
    }
}
