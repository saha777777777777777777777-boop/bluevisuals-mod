package com.bluevisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class BlueConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static BlueConfig instance = new BlueConfig();

    public static final String[] COLOR_NAMES = {"Синий", "Голубой", "Фиолетовый", "Розовый", "Красный", "Зелёный", "Белый"};
    public static final int[] COLOR_RGB = {0x3C8CFF, 0x30E0FF, 0xA050FF, 0xFF60C0, 0xFF4040, 0x40E060, 0xFFFFFF};

    public boolean armorHud = true;
    public boolean armorPercent = true;
    public boolean noFire = true;
    public boolean hitParticles = true;
    public boolean hologram = true;
    public boolean hologramAll = true;
    public boolean stars = true;
    public boolean fallingStars = true;
    public boolean lite = false;
    public boolean pearlPath = true;
    public boolean skyTint = true;
    public int skyColorIndex = 2;
    public boolean healthTags = true;
    public int colorIndex = 0;
    public boolean shulkerPreview = true;
    public boolean wings = true;
    public int wingStyle = 0;
    public boolean mask = false;
    public boolean vest = false;
    public boolean shields = false;
    public boolean cosOthers = true;
    public int cosColorIndex = 2;
    public boolean sparks = true;
    public List<Marker> markers = new ArrayList<>();

    public static class Marker {
        public double x;
        public double y;
        public double z;
        public String name = "";

        public Marker(double x, double y, double z, String name) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.name = name;
        }
    }

    public static BlueConfig get() {
        return instance;
    }

    public static int rgb() {
        int i = Math.floorMod(instance.colorIndex, COLOR_RGB.length);
        return COLOR_RGB[i];
    }

    public static int cosRgb() {
        return COLOR_RGB[Math.floorMod(instance.cosColorIndex, COLOR_RGB.length)];
    }

    public static int skyRgb() {
        int i = Math.floorMod(instance.skyColorIndex, COLOR_RGB.length);
        return COLOR_RGB[i];
    }

    public static String skyColorName() {
        int i = Math.floorMod(instance.skyColorIndex, COLOR_NAMES.length);
        return COLOR_NAMES[i];
    }

    public static String colorName() {
        int i = Math.floorMod(instance.colorIndex, COLOR_NAMES.length);
        return COLOR_NAMES[i];
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("bluevisuals.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                BlueConfig loaded = GSON.fromJson(Files.readString(p), BlueConfig.class);
                if (loaded != null) {
                    if (loaded.markers == null) {
                        loaded.markers = new ArrayList<>();
                    }
                    instance = loaded;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (IOException ignored) {
        }
    }
}
