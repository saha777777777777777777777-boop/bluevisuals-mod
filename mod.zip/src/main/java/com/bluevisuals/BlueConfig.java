package com.bluevisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class BlueConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static BlueConfig instance = new BlueConfig();

    public boolean armorHud = true;
    public boolean armorPercent = true;
    public boolean noFire = true;
    public boolean hitParticles = true;
    public boolean hologram = true;

    public static BlueConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("bluevisuals.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                BlueConfig loaded = GSON.fromJson(Files.readString(p), BlueConfig.class);
                if (loaded != null) {
                    instance = loaded;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (IOException ignored) {
        }
    }
}
