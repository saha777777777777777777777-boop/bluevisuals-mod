package com.bluevisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class BlueConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static BlueConfig instance = new BlueConfig();

    public static final String[] COLOR_NAMES = {"Синий", "Голубой", "Фиолетовый", "Розовый", "Красный", "Зелёный", "Белый"};
    public static final int[] COLOR_RGB = {0x3C8CFF, 0x30E0FF, 0xA050FF, 0xFF60C0, 0xFF4040, 0x40E060, 0xFFFFFF};

    public boolean armorHud = true;
    public boolean armorPercent = true;
    public boolean noFire = true;
    public boolean hitParticles = true;
    public boolean hologram = true;
    public boolean hologramAll = true;
    public boolean stars = true;
    public boolean fallingStars = true;
    public boolean lite = false;
    public boolean pearlPath = true;
    public boolean skyTint = true;
    public int skyColorIndex = 2;
    public boolean healthTags = true;
    public int colorIndex = 0;
    public boolean shulkerPreview = true;
    public boolean fpsGuard = false;
    public int playerTarget = 0;
    public int totemSkin = 0;
    public int swordSkin = 0;
    public int appleSkin = 0;
    public int pearlSkin = 0;
    public boolean miniInv = false;
    public boolean freeSlots = true;
    public boolean targetGear = true;
    public boolean handStock = true;
    public boolean totemWarn = true;
    public boolean armorValue = false;
    public boolean hungerWarn = true;
    public boolean tipDura = true;
    public boolean itemCounts = false;
    public boolean xpLevel = false;
    public boolean hitsPerSec = false;
    public boolean speedHud = false;
    public boolean pingHud = true;
    public boolean deathMarker = true;
    public boolean cooldownRing = true;
    public boolean hitSound = false;
    public boolean noDamageTilt = false;
    public double tiltBackup = 1.0;
    public boolean brightness = false;
    public double gammaBackup = 0.5;
    public boolean hat = false;
    public boolean scarf = false;
    public boolean combatTimer = true;
    public boolean pvpStock = true;
    public boolean effectsHud = false;
    public boolean nearestInfo = true;
    public boolean handDura = false;
    public boolean worldTime = false;
    public boolean lowHp = true;
    public boolean autoSprint = false;
    public boolean swordBack = false;
    public boolean ringFeet = false;
    public boolean crosshair = true;
    public boolean trail = false;
    public boolean targetInfo = true;
    public boolean combo = true;
    public boolean coords = false;
    public int targetStyle = 0;
    public int viewModel = 0;
    public float mDx = 0f, mDy = 0f, mDz = 0f, oDx = 0f, oDy = 0f, oDz = 0f;
    public boolean adjMinus = false;
    public boolean spinSwing = true;
    public boolean totalDealt = false;
    public boolean maxComboHud = false;
    public boolean hitTotal = false;
    public boolean rainHearts = false;
    public boolean magicFx = false;
    public boolean portalFx = false;
    public boolean notesFx = false;
    public boolean ashFx = false;
    public boolean petalsFx = false;
    public boolean hitLightning = false;
    public boolean hitBlood = false;
    public boolean hitFire = false;
    public boolean hitMagic = false;
    public boolean haloFx = false;
    public boolean flameAura = false;
    public boolean helixFx = false;
    public boolean targetRing = false;
    public boolean rocketTrail = false;
    public boolean levelUpFx = false;
    public boolean jumpRing = false;
    public boolean footFx = false;
    public int footStyle = 0;
    public boolean auraFx = false;
    public boolean snowFx = false;
    public boolean killFx = false;
    public boolean noFovFx = false;
    public double fovBackup = 1.0;
    public boolean noBob = false;
    public boolean bobBackup = true;
    public boolean fewParticles = false;
    public int partBackup = 0;
    public boolean noClouds = false;
    public int cloudBackup = 2;
    public int viewDistPreset = 0;
    public boolean targetDist = false;
    public boolean weaponCd = false;
    public boolean gappleCd = false;
    public boolean sprintState = false;
    public boolean dealtDmg = false;
    public boolean reachHud = false;
    public boolean critCount = false;
    public boolean killCount = false;
    public boolean blockWarn = false;
    public boolean critReady = false;
    public boolean proxAlert = false;
    public boolean hpSelf = false;
    public boolean lastDmg = false;
    public boolean pearlCd = false;
    public boolean xpProgress = false;
    public boolean noFood = false;
    public boolean elytraHud = false;
    public boolean vertSpeed = false;
    public boolean nightTimer = false;
    public boolean offhandInfo = false;
    public boolean lowTool = false;
    public boolean realClock = false;
    public boolean biomeHud = false;
    public boolean lightHud = false;
    public boolean dimHud = false;
    public boolean fallHud = false;
    public boolean memHud = false;
    public boolean nearCount = false;
    public boolean lookBlock = false;
    public boolean yawPitch = false;
    public boolean airHud = false;
    public boolean satHud = false;
    public boolean sessHud = false;
    public boolean underBlock = false;
    public boolean mobCount = false;
    public boolean weatherHud = false;
    public boolean dayHud = false;
    public boolean handName = false;
    public boolean absHud = false;
    public boolean armorMin = false;
    public boolean onlineHud = false;
    public float mRx = 0f, mRz = 0f, oRx = 0f, oRz = 0f;
    public boolean crown = false;
    public boolean tail = false;
    public boolean visor = false;
    public boolean stars3d = false;
    public boolean cape = false;
    public boolean pads = false;
    public boolean hearts3d = false;
    public boolean ears = false;
    public boolean jetpack = false;
    public boolean crystal = false;
    public boolean halo = false;
    public boolean horns = false;
    public boolean aura = false;
    public boolean wings = true;
    public int wingStyle = 0;
    public boolean mask = false;
    public boolean vest = false;
    public boolean shields = false;
    public boolean cosOthers = true;
    public int cosColorIndex = 2;
    public boolean sparks = true;
    public List<Marker> markers = new ArrayList<>();

    public static class Marker {
        public double x;
        public double y;
        public double z;
        public String name = "";

        public Marker(double x, double y, double z, String name) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.name = name;
        }
    }

    public static BlueConfig get() {
        return instance;
    }

    public static int rgb() {
        int i = Math.floorMod(instance.colorIndex, COLOR_RGB.length);
        return COLOR_RGB[i];
    }

    public static int cosRgb() {
        return COLOR_RGB[Math.floorMod(instance.cosColorIndex, COLOR_RGB.length)];
    }

    public static int skyRgb() {
        int i = Math.floorMod(instance.skyColorIndex, COLOR_RGB.length);
        return COLOR_RGB[i];
    }

    public static String skyColorName() {
        int i = Math.floorMod(instance.skyColorIndex, COLOR_NAMES.length);
        return COLOR_NAMES[i];
    }

    public static String colorName() {
        int i = Math.floorMod(instance.colorIndex, COLOR_NAMES.length);
        return COLOR_NAMES[i];
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("bluevisuals.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                BlueConfig loaded = GSON.fromJson(Files.readString(p), BlueConfig.class);
                if (loaded != null) {
                    if (loaded.markers == null) {
                        loaded.markers = new ArrayList<>();
                    }
                    instance = loaded;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (IOException ignored) {
        }
    }
}
