package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class MarkerRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            BlueConfig cfg = BlueConfig.get();
            if (cfg.markers.isEmpty()) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            Vec3d cam = ctx.camera().getPos();
            MatrixStack m = ctx.matrixStack();
            int rgb = BlueConfig.rgb();
            int cr = (rgb >> 16) & 0xFF;
            int cg = (rgb >> 8) & 0xFF;
            int cb = rgb & 0xFF;

            // PASS 1: beams and ground squares (lines only)
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            MatrixStack.Entry entry = m.peek();
            for (BlueConfig.Marker mk : cfg.markers) {
                float x = (float) (mk.x - cam.x);
                float y = (float) (mk.y - cam.y);
                float z = (float) (mk.z - cam.z);

                line(vc, entry, x, y - 2.0f, z, 255, x, y + 150.0f, z, 60, 0, 1, 0, cr, cg, cb);
                if (!cfg.lite) {
                    line(vc, entry, x + 0.05f, y - 2.0f, z, 255, x + 0.05f, y + 150.0f, z, 60, 0, 1, 0, cr, cg, cb);
                    line(vc, entry, x, y - 2.0f, z + 0.05f, 255, x, y + 150.0f, z + 0.05f, 60, 0, 1, 0, cr, cg, cb);
                }
                float h = 0.7f;
                line(vc, entry, x - h, y, z - h, 255, x + h, y, z - h, 255, 1, 0, 0, cr, cg, cb);
                line(vc, entry, x + h, y, z - h, 255, x + h, y, z + h, 255, 0, 0, 1, cr, cg, cb);
                line(vc, entry, x + h, y, z + h, 255, x - h, y, z + h, 255, -1, 0, 0, cr, cg, cb);
                line(vc, entry, x - h, y, z + h, 255, x - h, y, z - h, 255, 0, 0, -1, cr, cg, cb);
            }

            // PASS 2: dot + name + distance (text only, visible through blocks)
            VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();
            TextRenderer tr = mc.textRenderer;
            int index = 0;
            for (BlueConfig.Marker mk : cfg.markers) {
                index++;
                float x = (float) (mk.x - cam.x);
                float y = (float) (mk.y - cam.y);
                float z = (float) (mk.z - cam.z);
                double dist = Math.sqrt((double) x * x + (double) y * y + (double) z * z);
                double s = dist > 12.0 ? 12.0 / dist : 1.0;
                String name = (mk.name == null || mk.name.isEmpty()) ? "Метка " + index : mk.name;
                String label = name + "  " + (int) dist + " бл";

                m.push();
                m.translate(x * s, (y + 3.0f) * s, z * s);
                m.multiply(ctx.camera().getRotation());
                m.scale(-0.1f, -0.1f, 0.1f);
                Matrix4f dotMat = m.peek().getPositionMatrix();
                String dot = "●";
                tr.draw(Text.literal(dot), -tr.getWidth(dot) / 2.0f, -4.0f, 0xFF000000 | rgb, false, dotMat, imm,
                        TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
                m.pop();

                m.push();
                m.translate(x * s, (y + 3.0f) * s, z * s);
                m.multiply(ctx.camera().getRotation());
                m.scale(-0.04f, -0.04f, 0.04f);
                Matrix4f mat = m.peek().getPositionMatrix();
                float w = tr.getWidth(label);
                tr.draw(Text.literal(label), -w / 2.0f, 14.0f, 0xFF000000 | rgb, false, mat, imm,
                        TextRenderer.TextLayerType.SEE_THROUGH, 0x60000000, 0xF000F0);
                m.pop();
            }
            imm.draw();
        });
    }

    private static void line(VertexConsumer vc, MatrixStack.Entry e,
                             float x1, float y1, float z1, int a1,
                             float x2, float y2, float z2, int a2,
                             float nx, float ny, float nz, int cr, int cg, int cb) {
        vc.vertex(e, x1, y1, z1).color(cr, cg, cb, a1).normal(e, nx, ny, nz);
        vc.vertex(e, x2, y2, z2).color(cr, cg, cb, a2).normal(e, nx, ny, nz);
    }
}
