package com.bluevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ViewEditScreen extends Screen {
    private final Screen parent;
    private boolean offHand = false;
    private boolean rotate = false;
    private ButtonWidget handBtn;
    private ButtonWidget modeBtn;

    public ViewEditScreen(Screen parent) {
        super(Text.literal("Положение предмета"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = 110;
        int x = this.width / 2 - w - 4;
        int y = this.height - 52;
        handBtn = ButtonWidget.builder(Text.literal(""), b -> {
            offHand = !offHand;
            upd();
        }).dimensions(x, y, w, 20).build();
        modeBtn = ButtonWidget.builder(Text.literal(""), b -> {
            rotate = !rotate;
            upd();
        }).dimensions(x + w + 8, y, w, 20).build();
        addDrawableChild(handBtn);
        addDrawableChild(modeBtn);
        addDrawableChild(ButtonWidget.builder(Text.literal("Положить плашмя"), b -> {
            BlueConfig c = BlueConfig.get();
            if (offHand) {
                c.oRz = -90.0f;
                c.oRx = 0.0f;
            } else {
                c.mRz = -90.0f;
                c.mRx = 0.0f;
            }
        }).dimensions(x, y + 24, w, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Сброс"), b -> {
            BlueConfig c = BlueConfig.get();
            if (offHand) {
                c.oDx = 0.0f; c.oDy = 0.0f; c.oDz = 0.0f; c.oRx = 0.0f; c.oRz = 0.0f;
            } else {
                c.mDx = 0.0f; c.mDy = 0.0f; c.mDz = 0.0f; c.mRx = 0.0f; c.mRz = 0.0f;
            }
        }).dimensions(x + w + 8, y + 24, 54, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> close())
                .dimensions(x + w + 66, y + 24, 52, 20).build());
        upd();
    }

    private void upd() {
        handBtn.setMessage(Text.literal(offHand ? "Тотем (левая рука)" : "Меч (правая рука)"));
        modeBtn.setMessage(Text.literal(rotate ? "Режим: Поворот" : "Режим: Двигать"));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (my > this.height - 56) {
            return super.mouseDragged(mx, my, button, dx, dy);
        }
        BlueConfig c = BlueConfig.get();
        float fx = (float) dx;
        float fy = (float) dy;
        if (rotate) {
            if (offHand) {
                c.oRz += fx * 0.6f;
                c.oRx += fy * 0.6f;
            } else {
                c.mRz += fx * 0.6f;
                c.mRx += fy * 0.6f;
            }
        } else {
            if (offHand) {
                c.oDx = clamp(c.oDx + fx * 0.004f);
                c.oDy = clamp(c.oDy - fy * 0.004f);
            } else {
                c.mDx = clamp(c.mDx + fx * 0.004f);
                c.mDy = clamp(c.mDy - fy * 0.004f);
            }
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hx, double vy) {
        BlueConfig c = BlueConfig.get();
        if (offHand) {
            c.oDz = clamp(c.oDz + (float) vy * 0.05f);
        } else {
            c.mDz = clamp(c.mDz + (float) vy * 0.05f);
        }
        return true;
    }

    private static float clamp(float v) {
        return Math.max(-2.0f, Math.min(2.0f, v));
    }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) {
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        g.drawCenteredTextWithShadow(this.textRenderer, "Зажми и води пальцем по экрану", this.width / 2, 12, 0xFFFFFFFF);
        g.drawCenteredTextWithShadow(this.textRenderer, rotate ? "Сейчас: поворот предмета" : "Сейчас: перемещение предмета", this.width / 2, 24, 0xFFC0B0E8);
        super.render(g, mx, my, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        BlueConfig.save();
        MinecraftClient.getInstance().setScreen(parent);
    }
}
