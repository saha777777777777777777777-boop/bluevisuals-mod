package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class HealthTags {
    private static final double RANGE = 32.0;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!BlueConfig.get().healthTags) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            MatrixStack m = ctx.matrixStack();
            double range = BlueConfig.get().lite ? 16.0 : RANGE;

            List<LivingEntity> list = new ArrayList<>();
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity || e.isRemoved()) {
                    continue;
                }
                double lim = (e instanceof net.minecraft.entity.player.PlayerEntity) ? range + 8.0 : range;
                if (mc.player.squaredDistanceTo(e) > lim * lim) {
                    continue;
                }
                list.add((LivingEntity) e);
            }
            if (list.isEmpty()) {
                return;
            }

            // PASS 1: hearts (lines only)
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            MatrixStack.Entry entry = m.peek();
            Vector3f right = new Vector3f(1.0f, 0.0f, 0.0f);
            ctx.camera().getRotation().transform(right);
            right.negate();
            Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
            ctx.camera().getRotation().transform(up);

            for (LivingEntity le : list) {
                double x = MathHelper.lerp(td, le.prevX, le.getX()) - cam.x;
                double y = MathHelper.lerp(td, le.prevY, le.getY()) - cam.y;
                double z = MathHelper.lerp(td, le.prevZ, le.getZ()) - cam.z;
                float hp = le.getHealth();
                float max = Math.max(2.0f, le.getMaxHealth());
                int n = Math.max(1, Math.min(20, (int) Math.ceil(max / 2.0f)));
                drawHearts(vc, entry, (float) x, (float) (y + le.getHeight() + 0.5), (float) z, right, up, n, hp, 0.085f);
            }

            // PASS 2: numbers (text only)
            VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();
            TextRenderer tr = mc.textRenderer;
            for (LivingEntity le : list) {
                double x = MathHelper.lerp(td, le.prevX, le.getX()) - cam.x;
                double y = MathHelper.lerp(td, le.prevY, le.getY()) - cam.y;
                double z = MathHelper.lerp(td, le.prevZ, le.getZ()) - cam.z;
                float hp = le.getHealth();
                float ratio = MathHelper.clamp(hp / Math.max(1.0f, le.getMaxHealth()), 0.0f, 1.0f);
                int color = ratio > 0.6f ? 0xFF55FF55 : (ratio > 0.3f ? 0xFFFFDD55 : 0xFFFF5555);
                String s = String.valueOf(Math.round(hp * 10.0f) / 10.0f);

                m.push();
                int rows = (int) Math.ceil(Math.min(20, Math.max(1, Math.ceil(Math.max(2.0f, le.getMaxHealth()) / 2.0f))) / 10.0);
                m.translate(x, y + le.getHeight() + 0.65 + rows * 0.2, z);
                m.multiply(ctx.camera().getRotation());
                m.scale(-0.025f, -0.025f, 0.025f);
                Matrix4f mat = m.peek().getPositionMatrix();
                float w = tr.getWidth(s);
                tr.draw(Text.literal(s), -w / 2.0f, 0.0f, color, false, mat, imm,
                        TextRenderer.TextLayerType.SEE_THROUGH, 0x40000000, 0xF000F0);
                m.pop();
            }
            imm.draw();
        });
    }

    private static void drawHearts(VertexConsumer vc, MatrixStack.Entry entry, float bx, float by, float bz,
                                   Vector3f right, Vector3f up, int n, float hp, float size) {
        float spacing = size * 2.1f;
        int full = (int) Math.floor(hp / 2.0f);
        boolean half = hp / 2.0f - full >= 0.25f;
        for (int i = 0; i < n; i++) {
            int row = i / 10;
            int inRow = Math.min(10, n - row * 10);
            int col = i % 10;
            float cx = -(inRow - 1) * spacing / 2.0f + col * spacing;
            float cy = row * size * 2.1f;
            boolean on = i < full;
            boolean h = !on && half && i == full;
            int r = (on || h) ? 255 : 90;
            int g = (on || h) ? 60 : 90;
            int b = (on || h) ? 60 : 90;
            if (h) {
                heart(vc, entry, bx, by, bz, right, up, cx, cy, size, 90, 90, 90);
                heart(vc, entry, bx, by, bz, right, up, cx, cy, size * 0.5f, 255, 60, 60);
            } else {
                heart(vc, entry, bx, by, bz, right, up, cx, cy, size, r, g, b);
                if (on && !BlueConfig.get().lite) {
                    heart(vc, entry, bx, by, bz, right, up, cx, cy, size * 0.55f, r, g, b);
                }
            }
        }
    }

    private static void heart(VertexConsumer vc, MatrixStack.Entry entry, float bx, float by, float bz,
                              Vector3f right, Vector3f up, float cx, float cy, float size, int r, int g, int b) {
        int seg = BlueConfig.get().lite ? 8 : 12;
        float px = 0.0f;
        float py = 0.0f;
        float pz = 0.0f;
        for (int k = 0; k <= seg; k++) {
            double t = Math.PI * 2.0 * k / seg;
            float hx = (float) (16.0 * Math.pow(Math.sin(t), 3)) / 17.0f;
            float hy = (float) (13.0 * Math.cos(t) - 5.0 * Math.cos(2 * t) - 2.0 * Math.cos(3 * t) - Math.cos(4 * t)) / 17.0f;
            float ox = cx + hx * size;
            float oy = cy + hy * size;
            float wx = bx + right.x * ox + up.x * oy;
            float wy = by + right.y * ox + up.y * oy;
            float wz = bz + right.z * ox + up.z * oy;
            if (k > 0) {
                float dx = wx - px;
                float dy = wy - py;
                float dz = wz - pz;
                float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len > 0.0001f) {
                    float nx = dx / len;
                    float ny = dy / len;
                    float nz = dz / len;
                    vc.vertex(entry, px, py, pz).color(r, g, b, 255).normal(entry, nx, ny, nz);
                    vc.vertex(entry, wx, wy, wz).color(r, g, b, 255).normal(entry, nx, ny, nz);
                }
            }
            px = wx;
            py = wy;
            pz = wz;
        }
    }
}
