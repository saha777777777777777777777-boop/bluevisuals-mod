package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class HealthTags {
    private static final double RANGE = 32.0;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!BlueConfig.get().healthTags) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            MatrixStack m = ctx.matrixStack();
            TextRenderer tr = mc.textRenderer;
            VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            MatrixStack.Entry entry = m.peek();
            Vector3f right = new Vector3f(1.0f, 0.0f, 0.0f);
            ctx.camera().getRotation().transform(right);
            right.negate();
            Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
            ctx.camera().getRotation().transform(up);

            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity || !e.isAlive()) {
                    continue;
                }
                double range = BlueConfig.get().lite ? 16.0 : RANGE;
                if (mc.player.squaredDistanceTo(e) > range * range) {
                    continue;
                }
                LivingEntity le = (LivingEntity) e;
                double x = MathHelper.lerp(td, e.prevX, e.getX()) - ctx.camera().getPos().x;
                double y = MathHelper.lerp(td, e.prevY, e.getY()) - ctx.camera().getPos().y;
                double z = MathHelper.lerp(td, e.prevZ, e.getZ()) - ctx.camera().getPos().z;

                float hp = le.getHealth();
                float max = Math.max(1.0f, le.getMaxHealth());
                float ratio = MathHelper.clamp(hp / max, 0.0f, 1.0f);
                int color = ratio > 0.6f ? 0xFF55FF55 : (ratio > 0.3f ? 0xFFFFDD55 : 0xFFFF5555);
                String s = "♥ " + (Math.round(hp * 10.0f) / 10.0f);

                int n = Math.max(1, Math.min(10, (int) Math.ceil(max / 2.0f)));
                if (BlueConfig.get().lite) {
                    n = Math.min(n, 5);
                }
                int filled = Math.round(ratio * n);
                if (hp > 0.0f && filled == 0) {
                    filled = 1;
                }
                drawHearts(vc, entry, (float) x, (float) (y + e.getHeight() + 0.7), (float) z, right, up, n, filled, 0.14f);

                m.push();
                m.translate(x, y + e.getHeight() + 1.15, z);
                m.multiply(ctx.camera().getRotation());
                m.scale(-0.025f, -0.025f, 0.025f);
                Matrix4f mat = m.peek().getPositionMatrix();
                float w = tr.getWidth(s);
                tr.draw(Text.literal(s), -w / 2.0f, 0.0f, color, false, mat, imm,
                        TextRenderer.TextLayerType.SEE_THROUGH, 0x40000000, 0xF000F0);
                m.pop();
            }
            imm.draw();
        });
    }

    private static void drawHearts(VertexConsumer vc, MatrixStack.Entry entry, float bx, float by, float bz,
                                   Vector3f right, Vector3f up, int n, int filled, float size) {
        float spacing = size * 2.4f;
        float start = -(n - 1) * spacing / 2.0f;
        for (int i = 0; i < n; i++) {
            boolean on = i < filled;
            int r = on ? 255 : 90;
            int g = on ? 60 : 90;
            int b = on ? 60 : 90;
            float cx = start + i * spacing;
            heart(vc, entry, bx, by, bz, right, up, cx, size, r, g, b);
            if (on) {
                heart(vc, entry, bx, by, bz, right, up, cx, size * 0.55f, r, g, b);
            }
        }
    }

    private static void heart(VertexConsumer vc, MatrixStack.Entry entry, float bx, float by, float bz,
                              Vector3f right, Vector3f up, float cx, float size, int r, int g, int b) {
        int seg = 12;
        float px = 0.0f;
        float py = 0.0f;
        float pz = 0.0f;
        for (int k = 0; k <= seg; k++) {
            double t = Math.PI * 2.0 * k / seg;
            float hx = (float) (16.0 * Math.pow(Math.sin(t), 3)) / 17.0f;
            float hy = (float) (13.0 * Math.cos(t) - 5.0 * Math.cos(2 * t) - 2.0 * Math.cos(3 * t) - Math.cos(4 * t)) / 17.0f;
            float ox = cx + hx * size;
            float oy = hy * size;
            float wx = bx + right.x * ox + up.x * oy;
            float wy = by + right.y * ox + up.y * oy;
            float wz = bz + right.z * ox + up.z * oy;
            if (k > 0) {
                float dx = wx - px;
                float dy = wy - py;
                float dz = wz - pz;
                float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len > 0.0001f) {
                    float nx = dx / len;
                    float ny = dy / len;
                    float nz = dz / len;
                    vc.vertex(entry, px, py, pz).color(r, g, b, 255).normal(entry, nx, ny, nz);
                    vc.vertex(entry, wx, wy, wz).color(r, g, b, 255).normal(entry, nx, ny, nz);
                }
            }
            px = wx;
            py = wy;
            pz = wz;
        }
    }
}
