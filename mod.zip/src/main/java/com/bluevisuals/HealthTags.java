package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

public class HealthTags {
    private static final double RANGE = 32.0;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!BlueConfig.get().healthTags) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            MatrixStack m = ctx.matrixStack();
            TextRenderer tr = mc.textRenderer;

            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity || !e.isAlive()) {
                    continue;
                }
                if (mc.player.squaredDistanceTo(e) > RANGE * RANGE) {
                    continue;
                }
                LivingEntity le = (LivingEntity) e;
                double x = MathHelper.lerp(td, e.prevX, e.getX()) - ctx.camera().getPos().x;
                double y = MathHelper.lerp(td, e.prevY, e.getY()) - ctx.camera().getPos().y;
                double z = MathHelper.lerp(td, e.prevZ, e.getZ()) - ctx.camera().getPos().z;

                float hp = le.getHealth();
                float max = Math.max(1.0f, le.getMaxHealth());
                float ratio = MathHelper.clamp(hp / max, 0.0f, 1.0f);
                int color = ratio > 0.6f ? 0xFF55FF55 : (ratio > 0.3f ? 0xFFFFDD55 : 0xFFFF5555);
                String s = "♥ " + (Math.round(hp * 10.0f) / 10.0f);

                m.push();
                m.translate(x, y + e.getHeight() + 0.85, z);
                m.multiply(ctx.camera().getRotation());
                m.scale(-0.025f, -0.025f, 0.025f);
                Matrix4f mat = m.peek().getPositionMatrix();
                float w = tr.getWidth(s);
                tr.draw(Text.literal(s), -w / 2.0f, 0.0f, color, false, mat, ctx.consumers(),
                        TextRenderer.TextLayerType.SEE_THROUGH, 0x40000000, 0xF000F0);
                m.pop();
            }
        });
    }
}
