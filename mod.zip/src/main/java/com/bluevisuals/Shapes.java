package com.bluevisuals;

public class Shapes {
    public static final String[] NAMES = {"Квадрат", "Треугольник", "Шестиугольник", "Круг", "Звезда"};

    public static final String[] PLAYER_MODES = {"Как у мобов (3D)", "Плоская на экране"};
    public static final String[] VIEW_NAMES = {"Обычный", "Лежит", "Большой", "Огромный"};

    // closed polygon points (x, z) for the given style, "half" = half size
    public static float[][] poly(int style, float half) {
        style = Math.floorMod(style, NAMES.length);
        int n;
        boolean star = false;
        float r = half * 1.2f;
        float start = (float) (-Math.PI / 2);
        switch (style) {
            case 0:
                n = 4;
                r = half * 1.4142f;
                start = (float) (Math.PI / 4);
                break;
            case 1:
                n = 3;
                r = half * 1.3f;
                break;
            case 2:
                n = 6;
                break;
            case 3:
                n = 24;
                break;
            default:
                n = 10;
                star = true;
                r = half * 1.35f;
                break;
        }
        float[][] p = new float[n][2];
        for (int i = 0; i < n; i++) {
            float a = start + (float) (Math.PI * 2 * i / n);
            float rr = star ? (i % 2 == 0 ? r : r * 0.45f) : r;
            p[i][0] = (float) Math.cos(a) * rr;
            p[i][1] = (float) Math.sin(a) * rr;
        }
        return p;
    }
}
