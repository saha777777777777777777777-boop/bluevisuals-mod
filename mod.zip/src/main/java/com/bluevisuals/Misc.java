package com.bluevisuals;

import net.minecraft.client.MinecraftClient;

public class Misc {
    public static void bright(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.brightness) {
            c.gammaBackup = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(1.0);
            c.brightness = true;
        } else if (!on && c.brightness) {
            mc.options.getGamma().setValue(c.gammaBackup);
            c.brightness = false;
        }
        BlueConfig.save();
    }

    public static void noTilt(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.noDamageTilt) {
            c.tiltBackup = mc.options.getDamageTiltStrength().getValue();
            mc.options.getDamageTiltStrength().setValue(0.0);
            c.noDamageTilt = true;
        } else if (!on && c.noDamageTilt) {
            mc.options.getDamageTiltStrength().setValue(c.tiltBackup);
            c.noDamageTilt = false;
        }
        BlueConfig.save();
    }
}
