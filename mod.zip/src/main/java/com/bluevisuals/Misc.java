package com.bluevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.SimpleOption;

public class Misc {
    public static void bright(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.brightness) {
            c.gammaBackup = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(1.0);
            c.brightness = true;
        } else if (!on && c.brightness) {
            mc.options.getGamma().setValue(c.gammaBackup);
            c.brightness = false;
        }
        BlueConfig.save();
    }

    public static void noTilt(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.noDamageTilt) {
            c.tiltBackup = mc.options.getDamageTiltStrength().getValue();
            mc.options.getDamageTiltStrength().setValue(0.0);
            c.noDamageTilt = true;
        } else if (!on && c.noDamageTilt) {
            mc.options.getDamageTiltStrength().setValue(c.tiltBackup);
            c.noDamageTilt = false;
        }
        BlueConfig.save();
    }

    public static void noFovFx(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.noFovFx) {
            c.fovBackup = mc.options.getFovEffectScale().getValue();
            mc.options.getFovEffectScale().setValue(0.0);
            c.noFovFx = true;
        } else if (!on && c.noFovFx) {
            mc.options.getFovEffectScale().setValue(c.fovBackup);
            c.noFovFx = false;
        }
        BlueConfig.save();
    }

    public static void noBob(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.noBob) {
            c.bobBackup = mc.options.getBobView().getValue();
            mc.options.getBobView().setValue(false);
            c.noBob = true;
        } else if (!on && c.noBob) {
            mc.options.getBobView().setValue(c.bobBackup);
            c.noBob = false;
        }
        BlueConfig.save();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void fewParticles(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        SimpleOption raw = (SimpleOption) mc.options.getParticles();
        Object[] v = ((Enum) raw.getValue()).getDeclaringClass().getEnumConstants();
        if (on && !c.fewParticles) {
            c.partBackup = ((Enum) raw.getValue()).ordinal();
            raw.setValue(v[v.length - 1]);
            c.fewParticles = true;
        } else if (!on && c.fewParticles) {
            raw.setValue(v[Math.floorMod(c.partBackup, v.length)]);
            c.fewParticles = false;
        }
        BlueConfig.save();
    }

    public static void noClouds(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        if (mc.options == null) {
            return;
        }
        if (on && !c.noClouds) {
            c.cloudBackup = mc.options.getCloudRenderMode().getValue().ordinal();
            mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            c.noClouds = true;
        } else if (!on && c.noClouds) {
            CloudRenderMode[] v = CloudRenderMode.values();
            mc.options.getCloudRenderMode().setValue(v[Math.floorMod(c.cloudBackup, v.length)]);
            c.noClouds = false;
        }
        BlueConfig.save();
    }

    public static final int[] VIEW_PRESETS = {0, 4, 6, 8, 12};

    public static void cycleView() {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        c.viewDistPreset = (c.viewDistPreset + 1) % VIEW_PRESETS.length;
        if (mc.options != null && VIEW_PRESETS[c.viewDistPreset] > 0) {
            mc.options.getViewDistance().setValue(VIEW_PRESETS[c.viewDistPreset]);
        }
        BlueConfig.save();
    }
}
