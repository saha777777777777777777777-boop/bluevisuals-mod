package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class HologramRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!BlueConfig.get().hologram) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            Entity target = pickTarget(mc);
            if (target == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            double x = MathHelper.lerp(td, target.prevX, target.getX()) - cam.x;
            double y = MathHelper.lerp(td, target.prevY, target.getY()) - cam.y;
            double z = MathHelper.lerp(td, target.prevZ, target.getZ()) - cam.z;

            float time = mc.world.getTime() + td;
            float half = target.getWidth() * 0.5f + 0.35f;
            float height = target.getHeight();

            MatrixStack m = ctx.matrixStack();
            m.push();
            m.translate(x, y, z);
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());

            float bob = MathHelper.sin(time * 0.1f) * 0.35f + 0.5f;
            drawSquare(m, vc, half, height * bob, time * 0.07f);
            drawSquare(m, vc, half * 0.7f, height * (1.0f - bob), -time * 0.09f);
            m.pop();
        });
    }

    private static Entity pickTarget(MinecraftClient mc) {
        Entity looked = mc.targetedEntity;
        if (looked instanceof LivingEntity && looked.isAlive() && looked != mc.player) {
            return looked;
        }
        Entity last = HitEffects.lastTarget;
        if (last != null && last.isAlive() && mc.world.getTime() - HitEffects.lastHitTime < 60) {
            return last;
        }
        return null;
    }

    private static void drawSquare(MatrixStack m, VertexConsumer vc, float half, float y, float angle) {
        float cos = MathHelper.cos(angle);
        float sin = MathHelper.sin(angle);
        float[][] corners = {{-half, -half}, {half, -half}, {half, half}, {-half, half}};
        float[][] r = new float[4][2];
        for (int i = 0; i < 4; i++) {
            r[i][0] = corners[i][0] * cos - corners[i][1] * sin;
            r[i][1] = corners[i][0] * sin + corners[i][1] * cos;
        }
        MatrixStack.Entry entry = m.peek();
        for (int i = 0; i < 4; i++) {
            float x1 = r[i][0];
            float z1 = r[i][1];
            float x2 = r[(i + 1) % 4][0];
            float z2 = r[(i + 1) % 4][1];
            float dx = x2 - x1;
            float dz = z2 - z1;
            float len = MathHelper.sqrt(dx * dx + dz * dz);
            float nx = dx / len;
            float nz = dz / len;
            vc.vertex(entry, x1, y, z1).color(60, 140, 255, 255).normal(entry, nx, 0.0f, nz);
            vc.vertex(entry, x2, y, z2).color(60, 140, 255, 255).normal(entry, nx, 0.0f, nz);
        }
    }
}
