package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class HologramRenderer {
    private static final double RANGE = 24.0;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            BlueConfig cfg = BlueConfig.get();
            if (!cfg.hologram || Perf.skip()) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            MatrixStack m = ctx.matrixStack();
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            float time = mc.world.getTime() + td;
            int rgb = BlueConfig.rgb();

            if (cfg.hologramAll) {
                int drawn = 0;
                for (Entity e : Scan.living) {
                    if (drawn >= 12) {
                        break;
                    }
                    if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity || (cfg.playerTarget == 1 && e instanceof net.minecraft.entity.player.PlayerEntity) || e.isRemoved()) {
                        continue;
                    }
                    boolean isPlayer = e instanceof net.minecraft.entity.player.PlayerEntity;
                    double range = isPlayer ? (cfg.lite ? 32.0 : 48.0) : (cfg.lite ? 10.0 : RANGE);
                    if (mc.player.squaredDistanceTo(e) > range * range) {
                        continue;
                    }
                    drawFor(m, vc, e, cam, td, time, rgb);
                    drawn++;
                }
            } else {
                Entity t = pickTarget(mc);
                if (t != null) {
                    drawFor(m, vc, t, cam, td, time, rgb);
                }
            }
        });
    }

    private static Entity pickTarget(MinecraftClient mc) {
        Entity looked = mc.targetedEntity;
        if (looked instanceof LivingEntity && !(BlueConfig.get().playerTarget == 1 && looked instanceof net.minecraft.entity.player.PlayerEntity) && !looked.isRemoved() && looked != mc.player) {
            return looked;
        }
        Entity last = HitEffects.lastTarget;
        if (last != null && !(BlueConfig.get().playerTarget == 1 && last instanceof net.minecraft.entity.player.PlayerEntity) && !last.isRemoved() && mc.world.getTime() - HitEffects.lastHitTime < 60) {
            return last;
        }
        return null;
    }

    private static void drawFor(MatrixStack m, VertexConsumer vc, Entity e, Vec3d cam, float td, float time, int rgb) {
        double x = MathHelper.lerp(td, e.prevX, e.getX()) - cam.x;
        double y = MathHelper.lerp(td, e.prevY, e.getY()) - cam.y;
        double z = MathHelper.lerp(td, e.prevZ, e.getZ()) - cam.z;
        float half = Math.max(0.6f, e.getWidth() * 0.5f + 0.7f);
        float height = e.getHeight();
        float bob = MathHelper.sin(time * 0.1f) * 0.35f + 0.5f;

        m.push();
        m.translate(x, y, z);
        boolean lite = BlueConfig.get().lite;
        int rings = lite ? 1 : 3;
        for (int k = 0; k < rings; k++) {
            float grow = k * 0.06f;
            drawSquare(m, vc, half + grow, height * bob, time * 0.07f, rgb);
            if (!lite) {
                drawSquare(m, vc, half * 0.7f + grow, height * (1.0f - bob), -time * 0.09f, rgb);
            }
        }
        m.pop();
    }

    private static void drawSquare(MatrixStack m, VertexConsumer vc, float half, float y, float angle, int rgb) {
        int cr = (rgb >> 16) & 0xFF;
        int cg = (rgb >> 8) & 0xFF;
        int cb = rgb & 0xFF;
        float cos = MathHelper.cos(angle);
        float sin = MathHelper.sin(angle);
        float[][] corners = Shapes.poly(BlueConfig.get().targetStyle, half);
        int cnt = corners.length;
        float[][] r = new float[cnt][2];
        for (int i = 0; i < cnt; i++) {
            r[i][0] = corners[i][0] * cos - corners[i][1] * sin;
            r[i][1] = corners[i][0] * sin + corners[i][1] * cos;
        }
        MatrixStack.Entry entry = m.peek();
        for (int i = 0; i < cnt; i++) {
            float x1 = r[i][0];
            float z1 = r[i][1];
            float x2 = r[(i + 1) % cnt][0];
            float z2 = r[(i + 1) % cnt][1];
            float dx = x2 - x1;
            float dz = z2 - z1;
            float len = MathHelper.sqrt(dx * dx + dz * dz);
            if (len < 0.0001f) {
                continue;
            }
            float nx = dx / len;
            float nz = dz / len;
            vc.vertex(entry, x1, y, z1).color(cr, cg, cb, 255).normal(entry, nx, 0.0f, nz);
            vc.vertex(entry, x2, y, z2).color(cr, cg, cb, 255).normal(entry, nx, 0.0f, nz);
        }
    }
}
