package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

public class SkinsScreen extends Screen {
    private static final int ACCENT = 0xFFA060FF;
    private static final String[] CATS = {"Тотемы", "Мечи", "Яблоки", "Перлы"};

    private final Screen parent;
    private int cat = 0;
    private int page = 0;
    private static final int PER = 6;
    private int px, py, pw, ph;

    public SkinsScreen(Screen parent) {
        super(Text.literal("Скины"));
        this.parent = parent;
    }

    private static String[] names(int c) {
        switch (c) {
            case 0: return Skins.TOTEM_NAMES;
            case 1: return Skins.SWORD_NAMES;
            case 2: return Skins.APPLE_NAMES;
            default: return Skins.PEARL_NAMES;
        }
    }

    private static Item vanilla(int c) {
        switch (c) {
            case 0: return Items.TOTEM_OF_UNDYING;
            case 1: return Items.NETHERITE_SWORD;
            case 2: return Items.ENCHANTED_GOLDEN_APPLE;
            default: return Items.ENDER_PEARL;
        }
    }

    private static int get(int c) {
        BlueConfig f = BlueConfig.get();
        switch (c) {
            case 0: return f.totemSkin;
            case 1: return f.swordSkin;
            case 2: return f.appleSkin;
            default: return f.pearlSkin;
        }
    }

    private static void set(int c, int v) {
        BlueConfig f = BlueConfig.get();
        switch (c) {
            case 0: f.totemSkin = v; break;
            case 1: f.swordSkin = v; break;
            case 2: f.appleSkin = v; break;
            default: f.pearlSkin = v; break;
        }
        BlueConfig.save();
    }

    @Override
    protected void init() {
        pw = Math.min(this.width - 8, 420);
        ph = Math.min(this.height - 6, 236);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
    }

    private int cardW() {
        return (pw - 124 - 10 - 8) / 3;
    }

    private int cardX(int k) {
        return px + 124 + (k % 3) * (cardW() + 4);
    }

    private int cardY(int k) {
        return py + 52 + (k / 3) * 66;
    }

    private int pages() {
        return Math.max(1, (names(cat).length + PER - 1) / PER);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int tx = px + 124;
        for (int i = 0; i < CATS.length; i++) {
            int w = 62;
            if (mx >= tx && mx <= tx + w && my >= py + 26 && my <= py + 44) {
                cat = i;
                page = 0;
                return true;
            }
            tx += w + 4;
        }
        int n = names(cat).length;
        for (int k = 0; k < PER; k++) {
            int idx = page * PER + k;
            if (idx >= n) {
                break;
            }
            int x = cardX(k);
            int y = cardY(k);
            if (mx >= x && mx <= x + cardW() && my >= y && my <= y + 62) {
                set(cat, idx);
                return true;
            }
        }
        int by = py + ph - 24;
        if (my >= by && my <= by + 18) {
            if (mx >= px + 124 && mx <= px + 142 && page > 0) {
                page--;
                return true;
            }
            if (mx >= px + 178 && mx <= px + 196 && page < pages() - 1) {
                page++;
                return true;
            }
            if (mx >= px + 8 && mx <= px + 108) {
                this.close();
                return true;
            }
            if (mx >= px + pw - 150 && mx <= px + pw - 8) {
                Skins.apply();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void renderBackground(DrawContext g, int mouseX, int mouseY, float delta) {
        g.fillGradient(0, 0, this.width, this.height, 0xFF160733, 0xFF030208);
        java.util.Random r = new java.util.Random(1337L);
        long t = net.minecraft.util.Util.getMeasuringTimeMs();
        int n = BlueConfig.get().lite ? 0 : 120;
        for (int i = 0; i < n; i++) {
            int x = r.nextInt(Math.max(1, this.width));
            int y = r.nextInt(Math.max(1, this.height));
            double phase = r.nextDouble() * 6.28;
            int a = (int) (70 + 110 * (0.5 + 0.5 * Math.sin(t / 600.0 + phase)));
            g.fill(x, y, x + 1, y + 1, (a << 24) | (r.nextBoolean() ? 0xC9A8FF : 0x8A4DFF));
        }
    }

    private void frame(DrawContext g, int x1, int y1, int x2, int y2, int fill, int border) {
        g.fill(x1, y1, x2, y2, fill);
        g.fill(x1, y1, x2, y1 + 1, border);
        g.fill(x1, y2 - 1, x2, y2, border);
        g.fill(x1, y1, x1 + 1, y2, border);
        g.fill(x2 - 1, y1, x2, y2, border);
    }

    private void art(DrawContext g, int c, int idx, int ox, int oy, int s) {
        int[] px16 = SkinArt.get(c, idx);
        if (px16 == null) {
            g.getMatrices().push();
            g.getMatrices().translate(ox, oy, 0);
            g.getMatrices().scale(s, s, 1.0f);
            g.drawItem(new ItemStack(vanilla(c)), 0, 0);
            g.getMatrices().pop();
            return;
        }
        int size = 16 * s;
        for (int y = 0; y < 32; y++) {
            for (int x = 0; x < 32; x++) {
                int p = px16[y * 32 + x];
                if ((p >>> 24) < 12) {
                    continue;
                }
                g.fill(ox + x * size / 32, oy + y * size / 32, ox + (x + 1) * size / 32, oy + (y + 1) * size / 32, p);
            }
        }
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        renderBackground(g, mx, my, delta);
        frame(g, px, py, px + pw, py + ph, 0xDD0E0520, ACCENT);
        g.drawText(this.textRenderer, "Скины", px + 8, py + 8, 0xFFFFFFFF, true);
        g.drawText(this.textRenderer, "Выбери и нажми «Применить»", px + 8, py + 18, 0xFF8070B0, false);
        if (!Skins.status.isEmpty()) {
            g.drawText(this.textRenderer, Skins.status, px + 180, py + 18, 0xFF80FF80, false);
        }

        // tabs
        int tx = px + 124;
        for (int i = 0; i < CATS.length; i++) {
            boolean sel = i == cat;
            g.fill(tx, py + 26, tx + 62, py + 44, sel ? 0xFF3A1A78 : 0xFF1C0D3C);
            if (sel) {
                g.fill(tx, py + 42, tx + 62, py + 44, ACCENT);
            }
            g.drawCenteredTextWithShadow(this.textRenderer, CATS[i], tx + 31, py + 31, sel ? 0xFFFFFFFF : 0xFFB8A8E0);
            tx += 66;
        }

        // preview panel
        int sel = Math.floorMod(get(cat), names(cat).length);
        frame(g, px + 8, py + 30, px + 116, py + ph - 30, 0xFF150A2E, 0xFF4A2A88);
        g.drawText(this.textRenderer, "Предпросмотр", px + 14, py + 35, 0xFF8070B0, false);
        g.fill(px + 16, py + 48, px + 108, py + 48 + 92, 0xFF1D0F3D);
        art(g, cat, sel, px + 18, py + 52, 5);
        g.drawCenteredTextWithShadow(this.textRenderer, names(cat)[sel], px + 62, py + 146, 0xFFFFFFFF);

        // cards
        String[] nm = names(cat);
        for (int k = 0; k < PER; k++) {
            int idx = page * PER + k;
            if (idx >= nm.length) {
                break;
            }
            int x = cardX(k);
            int y = cardY(k);
            int w = cardW();
            boolean on = idx == sel;
            boolean hov = mx >= x && mx <= x + w && my >= y && my <= y + 62;
            frame(g, x, y, x + w, y + 62, on ? 0xFF241048 : (hov ? 0xFF1E0D3E : 0xFF150A2E), on ? ACCENT : (hov ? 0xFF7050B0 : 0xFF3A2468));
            art(g, cat, idx, x + (w - 48) / 2, y + 4, 3);
            g.getMatrices().push();
            g.getMatrices().translate(x + 4, y + 53, 0);
            g.getMatrices().scale(0.8f, 0.8f, 1.0f);
            g.drawText(this.textRenderer, nm[idx], 0, 0, on ? 0xFFFFFFFF : 0xFFC0B0E8, false);
            g.getMatrices().pop();
            if (on) {
                int cx = x + w - 14;
                int cy = y + 5;
                g.fill(cx, cy, cx + 10, cy + 10, ACCENT);
                int[][] ck = {{2, 5}, {3, 6}, {4, 7}, {5, 6}, {6, 5}, {7, 4}, {8, 3}};
                for (int[] p : ck) {
                    g.fill(cx + p[0] - 1, cy + p[1] - 2, cx + p[0], cy + p[1] - 1, 0xFFFFFFFF);
                }
            }
        }

        // buttons
        int by = py + ph - 24;
        frame(g, px + 124, by, px + 142, by + 18, 0xFF241048, page > 0 ? ACCENT : 0xFF3A2468);
        g.drawText(this.textRenderer, "<", px + 130, by + 5, 0xFFFFFFFF, false);
        g.drawCenteredTextWithShadow(this.textRenderer, (page + 1) + "/" + pages(), px + 160, by + 5, 0xFFC0B0E8);
        frame(g, px + 178, by, px + 196, by + 18, 0xFF241048, page < pages() - 1 ? ACCENT : 0xFF3A2468);
        g.drawText(this.textRenderer, ">", px + 184, by + 5, 0xFFFFFFFF, false);
        frame(g, px + 8, by, px + 108, by + 18, 0xFF241048, 0xFF4A2A88);
        g.drawCenteredTextWithShadow(this.textRenderer, "Назад", px + 58, by + 5, 0xFFFFFFFF);
        frame(g, px + pw - 150, by, px + pw - 8, by + 18, 0xFF3A1A78, ACCENT);
        g.drawCenteredTextWithShadow(this.textRenderer, "Применить выбранное", px + pw - 79, by + 5, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
