package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.RotationAxis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Cosmetics {
    public static final String[] STYLES = {"Ангел", "Демон", "Кристалл"};

    private static final float[][][] WING = {
            {{0.1f, 1.45f}, {0.5f, 1.95f}, {1.2f, 2.15f}, {1.6f, 1.8f}, {1.4f, 1.4f}, {1.1f, 1.0f}, {0.7f, 1.1f}, {0.35f, 0.9f}},
            {{0.1f, 1.45f}, {0.7f, 2.2f}, {0.95f, 1.6f}, {1.5f, 2.0f}, {1.5f, 1.45f}, {2.0f, 1.4f}, {1.3f, 1.0f}, {0.6f, 0.85f}},
            {{0.1f, 1.4f}, {0.4f, 2.1f}, {0.9f, 1.5f}, {1.3f, 2.2f}, {1.5f, 1.3f}, {1.9f, 1.6f}, {1.2f, 0.8f}, {0.5f, 0.7f}}
    };

    private static int cr;
    private static int cg;
    private static int cb;
    private static VertexConsumer vc;
    private static MatrixStack.Entry en;
    private static float bx, by, bz, sfx, sfz, srx, srz, tm, yawR;
    private static boolean fillPass;
    private static MatrixStack ms;
    private static VertexConsumer fvc;

    private static class PS {
        float x, y, z, yaw;
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static void col(int rgb) {
        cr = (rgb >> 16) & 0xFF;
        cg = (rgb >> 8) & 0xFF;
        cb = rgb & 0xFF;
    }

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            BlueConfig f = BlueConfig.get();
            if (!(f.wings || f.mask || f.vest || f.shields || f.halo || f.horns || f.aura || f.crown || f.tail
                    || f.visor || f.stars3d || f.cape || f.pads || f.hearts3d || f.ears || f.jetpack || f.crystal)) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            ms = ctx.matrixStack();
            en = ms.peek();
            tm = mc.world.getTime() + td;
            boolean first = mc.options.getPerspective().isFirstPerson();
            List<PS> list = new ArrayList<>();

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity) || e.isRemoved()) {
                    continue;
                }
                PlayerEntity p = (PlayerEntity) e;
                boolean self = p == mc.player;
                if (self && first) {
                    continue;
                }
                if (!self && (!f.cosOthers || f.lite || p.isInvisible() || mc.player.squaredDistanceTo(p) > 32 * 32)) {
                    continue;
                }
                PS ps = new PS();
                ps.x = (float) (MathHelper.lerp(td, p.prevX, p.getX()) - cam.x);
                ps.y = (float) (MathHelper.lerp(td, p.prevY, p.getY()) - cam.y) + (p.isInSneakingPose() ? -0.25f : 0.0f);
                ps.z = (float) (MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z);
                ps.yaw = (float) Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
                list.add(ps);
            }
            if (list.isEmpty()) {
                return;
            }
            // pass 1: solid fills
            fillPass = true;
            fvc = ctx.consumers().getBuffer(RenderLayer.getDebugFilledBox());
            for (PS ps : list) {
                setPlayer(ps);
                draw(f);
            }
            // pass 2: lines (new buffer, never reuse the fill buffer)
            fillPass = false;
            vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            for (PS ps : list) {
                setPlayer(ps);
                draw(f);
            }
        });
    }

    private static void setPlayer(PS ps) {
        bx = ps.x;
        by = ps.y;
        bz = ps.z;
        yawR = ps.yaw;
        sfx = -MathHelper.sin(yawR);
        sfz = MathHelper.cos(yawR);
        srx = -MathHelper.cos(yawR);
        srz = -MathHelper.sin(yawR);
    }

    // solid box in player-local coords (a=right, b=up, c=forward)
    private static void solid(float a1, float a2, float b1, float b2, float c1, float c2, int rgb, float alpha) {
        if (fillPass) {
            ms.push();
            ms.translate(bx, by, bz);
            ms.multiply(RotationAxis.POSITIVE_Y.rotation(-yawR));
            WorldRenderer.renderFilledBox(ms, fvc, -a2, b1, c1, -a1, b2, c2,
                    ((rgb >> 16) & 255) / 255.0f, ((rgb >> 8) & 255) / 255.0f, (rgb & 255) / 255.0f, alpha);
            ms.pop();
        } else {
            col(mix(rgb, 0x000000, 0.5f));
            box(a1, a2, b1, b2, c1, c2);
        }
    }

    // fill-only slab with extra transform applied by caller (already pushed)
    private static void slabFill(float x1, float x2, float y1, float y2, float z1, float z2, int rgb) {
        WorldRenderer.renderFilledBox(ms, fvc, x1, y1, z1, x2, y2, z2,
                ((rgb >> 16) & 255) / 255.0f, ((rgb >> 8) & 255) / 255.0f, (rgb & 255) / 255.0f, 1.0f);
    }

    private static final float[][] W_ANG = {
            {-30, -12, 6, 24, 42, 60}, {-5, 15, 35, 55, 75}, {-20, 5, 30, 55}};
    private static final float[][] W_LEN = {
            {1.3f, 1.55f, 1.7f, 1.65f, 1.45f, 1.15f}, {1.1f, 1.7f, 2.1f, 1.9f, 1.4f}, {1.2f, 1.7f, 1.6f, 1.1f}};
    private static final float[] W_THICK = {0.075f, 0.05f, 0.11f};

    private static void draw(BlueConfig f) {
        if (f.wings && fillPass) {
            wingsFill(f.wingStyle);
        }
        if (f.cape) {
            if (fillPass) {
                capeFill();
            }
        }
        if (f.jetpack) {
            solid(-0.2f, 0.2f, 0.85f, 1.35f, -0.34f, -0.14f, 0x4A505C, 1.0f);
            solid(-0.17f, -0.04f, 0.5f, 0.85f, -0.3f, -0.18f, 0xB04A12, 1.0f);
            solid(0.04f, 0.17f, 0.5f, 0.85f, -0.3f, -0.18f, 0xB04A12, 1.0f);
            if (!fillPass) {
                col(0xFFD030);
                for (int s = -1; s <= 1; s += 2) {
                    float fl = 0.15f * MathHelper.sin(tm * 0.8f + s);
                    float[] a = L(0.105f * s, 0.5f, -0.24f);
                    float[] b = L(0.13f * s, 0.3f + fl, -0.26f);
                    float[] c = L(0.105f * s, 0.12f + fl, -0.24f);
                    float[] d = L(0.08f * s, 0.3f + fl, -0.26f);
                    seg(a, b);
                    seg(b, c);
                    seg(c, d);
                    seg(d, a);
                }
            }
        }
        if (f.vest) {
            solid(-0.3f, 0.3f, 0.72f, 1.42f, -0.18f, 0.18f, 0x2F5233, 1.0f);
            solid(-0.2f, -0.05f, 0.85f, 1.0f, 0.18f, 0.24f, 0x3F6B44, 1.0f);
            solid(0.05f, 0.2f, 0.85f, 1.0f, 0.18f, 0.24f, 0x3F6B44, 1.0f);
            solid(-0.3f, 0.3f, 0.76f, 0.82f, 0.18f, 0.2f, 0x1E3320, 1.0f);
        }
        if (f.pads) {
            solid(0.27f, 0.52f, 1.35f, 1.5f, -0.16f, 0.16f, 0x8A93A5, 1.0f);
            solid(-0.52f, -0.27f, 1.35f, 1.5f, -0.16f, 0.16f, 0x8A93A5, 1.0f);
        }
        if (f.mask) {
            solid(-0.2f, 0.2f, 1.42f, 1.68f, 0.26f, 0.3f, 0x44503F, 1.0f);
            solid(-0.09f, 0.09f, 1.42f, 1.56f, 0.3f, 0.45f, 0xB05A18, 1.0f);
            solid(-0.28f, 0.28f, 1.56f, 1.62f, -0.28f, 0.28f, 0x202020, 1.0f);
        }
        if (f.visor) {
            solid(-0.27f, 0.27f, 1.57f, 1.72f, 0.26f, 0.3f, 0x1B8FA6, 0.85f);
        }
        if (f.horns) {
            float[][] hp = {{0.18f, 1.84f}, {0.27f, 1.97f}, {0.31f, 2.1f}, {0.26f, 2.22f}};
            int[] hc = {0x6A0F0F, 0x8E1A12, 0xB8321A, 0xE06A20};
            for (int s = -1; s <= 1; s += 2) {
                for (int i = 0; i < hp.length; i++) {
                    float h = 0.055f - i * 0.009f;
                    solid(hp[i][0] * s - h, hp[i][0] * s + h, hp[i][1] - 0.07f, hp[i][1] + 0.07f, -h + 0.03f * i, h + 0.03f * i, hc[i], 1.0f);
                }
            }
        }
        if (f.ears) {
            for (int s = -1; s <= 1; s += 2) {
                solid(Math.min(0.08f * s, 0.24f * s), Math.max(0.08f * s, 0.24f * s), 1.87f, 1.97f, -0.02f, 0.02f, 0x5A3A4A, 1.0f);
                solid(Math.min(0.11f * s, 0.21f * s), Math.max(0.11f * s, 0.21f * s), 1.97f, 2.08f, -0.02f, 0.02f, 0x5A3A4A, 1.0f);
                solid(Math.min(0.12f * s, 0.2f * s), Math.max(0.12f * s, 0.2f * s), 1.89f, 2.0f, 0.02f, 0.03f, 0xE88AB8, 1.0f);
            }
        }
        if (f.crown) {
            solid(-0.27f, 0.27f, 1.9f, 1.97f, 0.25f, 0.29f, 0xC9A020, 1.0f);
            solid(-0.27f, 0.27f, 1.9f, 1.97f, -0.29f, -0.25f, 0xC9A020, 1.0f);
            solid(-0.29f, -0.25f, 1.9f, 1.97f, -0.27f, 0.27f, 0xC9A020, 1.0f);
            solid(0.25f, 0.29f, 1.9f, 1.97f, -0.27f, 0.27f, 0xC9A020, 1.0f);
            float[][] sp = {{-0.25f, 0.27f}, {0.0f, 0.27f}, {0.25f, 0.27f}, {-0.25f, -0.27f}, {0.0f, -0.27f}, {0.25f, -0.27f}, {-0.27f, 0.0f}, {0.27f, 0.0f}};
            for (float[] q : sp) {
                solid(q[0] - 0.03f, q[0] + 0.03f, 1.97f, 2.14f, q[1] - 0.03f, q[1] + 0.03f, 0xF0C830, 1.0f);
            }
        }
        if (f.shields && fillPass) {
            shieldsFill();
        }
        if (fillPass) {
            return;
        }
        // ---- line-only cosmetics ----
        if (f.halo) {
            col(0xFFE070);
            float bob = 0.05f * MathHelper.sin(tm * 0.1f);
            ring(by + 2.0f + bob, 0.32f, tm * 0.05f, 20, false);
            col(0xFFFFFF);
            ring(by + 2.0f + bob, 0.26f, -tm * 0.05f, 20, false);
        }
        if (f.crystal) {
            col(0x70F0FF);
            float cy = by + 2.5f + 0.08f * MathHelper.sin(tm * 0.08f);
            float rot = tm * 0.06f;
            float[] top = {bx, cy + 0.28f, bz};
            float[] bot = {bx, cy - 0.28f, bz};
            float[][] eq = new float[4][];
            for (int i = 0; i < 4; i++) {
                float a = rot + (float) (Math.PI / 2 * i);
                eq[i] = new float[]{bx + MathHelper.cos(a) * 0.17f, cy, bz + MathHelper.sin(a) * 0.17f};
            }
            for (int i = 0; i < 4; i++) {
                seg(top, eq[i]);
                seg(bot, eq[i]);
                seg(eq[i], eq[(i + 1) % 4]);
            }
        }
        if (f.tail) {
            col(0xFF70C0);
            float[] pv = null;
            for (int i = 0; i <= 9; i++) {
                float a = MathHelper.sin(tm * 0.12f + i * 0.6f) * 0.03f * i;
                float[] cur = L(a, 0.8f - i * 0.03f + i * i * 0.006f, -0.15f - i * 0.1f);
                if (pv != null) {
                    seg(pv, cur);
                }
                pv = cur;
            }
        }
        if (f.stars3d) {
            col(0xFFE060);
            for (int k = 0; k < 4; k++) {
                double ang = tm * 0.05 + k * Math.PI / 2;
                float cx = bx + (float) Math.cos(ang) * 0.95f;
                float cz = bz + (float) Math.sin(ang) * 0.95f;
                float cy = by + 1.0f + 0.4f * MathHelper.sin(tm * 0.07f + k * 1.7f);
                float tx = (float) -Math.sin(ang);
                float tz = (float) Math.cos(ang);
                float sz = 0.14f;
                float[] n = {cx, cy + sz, cz};
                float[] s = {cx, cy - sz, cz};
                float[] w = {cx - tx * sz, cy, cz - tz * sz};
                float[] e = {cx + tx * sz, cy, cz + tz * sz};
                seg(n, e);
                seg(e, s);
                seg(s, w);
                seg(w, n);
                seg(n, s);
                seg(w, e);
            }
        }
        if (f.hearts3d) {
            col(0xFF5080);
            for (int k = 0; k < 3; k++) {
                double ang = -tm * 0.04 + k * Math.PI * 2 / 3;
                float cx = bx + (float) Math.cos(ang) * 0.85f;
                float cz = bz + (float) Math.sin(ang) * 0.85f;
                float cy = by + 1.2f + 0.25f * MathHelper.sin(tm * 0.09f + k * 2.1f);
                heart(cx, cy, cz, (float) -Math.sin(ang), (float) Math.cos(ang), 0.1f);
            }
        }
        if (f.aura) {
            col(0xA050FF);
            float k = (tm * 0.02f) % 1.0f;
            float k2 = (k + 0.5f) % 1.0f;
            ring(by + 0.05f + k * 1.9f, 0.9f - 0.3f * k, tm * 0.04f, 24, true);
            col(0x40D0FF);
            ring(by + 0.05f + k2 * 1.9f, 0.9f - 0.3f * k2, -tm * 0.04f, 24, true);
        }
    }

    private static void wingsFill(int style) {
        int st = Math.floorMod(style, W_ANG.length);
        float[] ang = W_ANG[st];
        float[] len = W_LEN[st];
        float th = W_THICK[st];
        float flap = 6.0f * MathHelper.sin(tm * 0.15f);
        for (int side = -1; side <= 1; side += 2) {
            for (int k = 0; k < ang.length; k++) {
                ms.push();
                ms.translate(bx, by, bz);
                ms.multiply(RotationAxis.POSITIVE_Y.rotation(-yawR));
                ms.translate(0.0f, 1.45f, -0.12f);
                float deg = ang[k] + flap;
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side > 0 ? -deg : deg));
                int c = mix(BlueConfig.cosRgb(), 0xFFFFFF, k / (float) (ang.length + 2));
                if (side > 0) {
                    slabFill(-(0.1f + len[k]), -0.1f, -th, th, -0.02f, 0.02f, c);
                } else {
                    slabFill(0.1f, 0.1f + len[k], -th, th, -0.02f, 0.02f, c);
                }
                ms.pop();
            }
        }
    }

    private static void capeFill() {
        ms.push();
        ms.translate(bx, by, bz);
        ms.multiply(RotationAxis.POSITIVE_Y.rotation(-yawR));
        ms.translate(0.0f, 1.4f, -0.17f);
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(10.0f + 5.0f * MathHelper.sin(tm * 0.1f)));
        slabFill(-0.28f, 0.28f, -0.95f, 0.0f, -0.025f, 0.0f, 0xA8222F);
        slabFill(-0.28f, 0.28f, -0.99f, -0.93f, -0.03f, 0.005f, 0xE0B030);
        ms.pop();
    }

    private static void shieldsFill() {
        for (int k = 0; k < 3; k++) {
            double ang = tm * 0.06 + k * Math.PI * 2.0 / 3.0;
            ms.push();
            ms.translate(bx + (float) Math.cos(ang) * 1.15f, by, bz + (float) Math.sin(ang) * 1.15f);
            ms.multiply(RotationAxis.POSITIVE_Y.rotation((float) -(ang + Math.PI / 2)));
            slabFill(-0.3f, 0.3f, 0.55f, 1.45f, -0.025f, 0.025f, 0x2F4F86);
            slabFill(-0.2f, 0.2f, 0.7f, 1.3f, -0.04f, 0.04f, 0x5AA0E8);
            slabFill(-0.04f, 0.04f, 0.55f, 1.45f, -0.05f, 0.05f, 0xD8B030);
            ms.pop();
        }
    }

    private static void cape() {
        float[] as = {-0.28f, -0.09f, 0.09f, 0.28f};
        float[][] prev = null;
        for (int i = 0; i <= 5; i++) {
            float b = 1.4f - i * 0.21f;
            float[][] cur = new float[4][];
            for (int j = 0; j < 4; j++) {
                float c = -0.15f - i * 0.05f + MathHelper.sin(tm * 0.1f + i * 0.9f + as[j] * 3.0f) * 0.04f * i;
                cur[j] = L(as[j], b, c);
                if (j > 0) {
                    seg(cur[j - 1], cur[j]);
                }
                if (prev != null) {
                    seg(prev[j], cur[j]);
                }
            }
            prev = cur;
        }
    }

    private static void shields() {
        for (int k = 0; k < 3; k++) {
            double ang = tm * 0.06 + k * Math.PI * 2.0 / 3.0;
            float ox = (float) Math.cos(ang) * 1.15f;
            float oz = (float) Math.sin(ang) * 1.15f;
            float tx = (float) -Math.sin(ang);
            float tz = (float) Math.cos(ang);
            for (int r = 0; r < 2; r++) {
                col(r == 0 ? 0x40A0FF : 0xA0E0FF);
                float hw = r == 0 ? 0.3f : 0.2f;
                float lo = r == 0 ? 0.55f : 0.7f;
                float hi = r == 0 ? 1.45f : 1.3f;
                float[] a = {bx + ox - tx * hw, by + lo, bz + oz - tz * hw};
                float[] b = {bx + ox + tx * hw, by + lo, bz + oz + tz * hw};
                float[] c = {bx + ox + tx * hw, by + hi, bz + oz + tz * hw};
                float[] d = {bx + ox - tx * hw, by + hi, bz + oz - tz * hw};
                seg(a, b);
                seg(b, c);
                seg(c, d);
                seg(d, a);
            }
            col(0xFFD040);
            seg(new float[]{bx + ox - tx * 0.3f, by + 0.55f, bz + oz - tz * 0.3f}, new float[]{bx + ox + tx * 0.3f, by + 1.45f, bz + oz + tz * 0.3f});
            seg(new float[]{bx + ox + tx * 0.3f, by + 0.55f, bz + oz + tz * 0.3f}, new float[]{bx + ox - tx * 0.3f, by + 1.45f, bz + oz - tz * 0.3f});
        }
    }

    private static void ring(float y, float r, float rot, int n, boolean dashed) {
        float[] pv = null;
        for (int i = 0; i <= n; i++) {
            float a = rot + (float) (Math.PI * 2.0 * i / n);
            float[] cur = {bx + MathHelper.cos(a) * r, y, bz + MathHelper.sin(a) * r};
            if (pv != null && (!dashed || i % 2 == 0)) {
                seg(pv, cur);
            }
            pv = cur;
        }
    }

    private static void heart(float cx, float cy, float cz, float tx, float tz, float size) {
        float[] pv = null;
        int seg = 14;
        for (int k = 0; k <= seg; k++) {
            double t = Math.PI * 2.0 * k / seg;
            float hx = (float) (16.0 * Math.pow(Math.sin(t), 3)) / 17.0f * size;
            float hy = (float) (13.0 * Math.cos(t) - 5.0 * Math.cos(2 * t) - 2.0 * Math.cos(3 * t) - Math.cos(4 * t)) / 17.0f * size;
            float[] cur = {cx + tx * hx, cy + hy, cz + tz * hx};
            if (pv != null) {
                seg(pv, cur);
            }
            pv = cur;
        }
    }

    private static float[] L(float a, float b, float c) {
        return new float[]{bx + srx * a + sfx * c, by + b, bz + srz * a + sfz * c};
    }

    private static void box(float a1, float a2, float b1, float b2, float c1, float c2) {
        float[][] p = new float[8][];
        int i = 0;
        for (int ai = 0; ai < 2; ai++) {
            for (int bi = 0; bi < 2; bi++) {
                for (int ci = 0; ci < 2; ci++) {
                    p[i++] = L(ai == 0 ? a1 : a2, bi == 0 ? b1 : b2, ci == 0 ? c1 : c2);
                }
            }
        }
        for (int k = 0; k < 8; k++) {
            if ((k & 1) == 0) {
                seg(p[k], p[k + 1]);
            }
            if ((k & 2) == 0) {
                seg(p[k], p[k + 2]);
            }
            if ((k & 4) == 0) {
                seg(p[k], p[k + 4]);
            }
        }
    }

    private static void seg(float[] a, float[] b) {
        float dx = b[0] - a[0];
        float dy = b[1] - a[1];
        float dz = b[2] - a[2];
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.0001f) {
            return;
        }
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(en, a[0], a[1], a[2]).color(cr, cg, cb, 255).normal(en, dx, dy, dz);
        vc.vertex(en, b[0], b[1], b[2]).color(cr, cg, cb, 255).normal(en, dx, dy, dz);
    }
}
