package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Cosmetics {
    public static final String[] STYLES = {"Ангел", "Демон", "Кристалл"};

    private static final float[][][] WING = {
            {{0.1f, 1.45f}, {0.5f, 1.95f}, {1.2f, 2.15f}, {1.6f, 1.8f}, {1.4f, 1.4f}, {1.1f, 1.0f}, {0.7f, 1.1f}, {0.35f, 0.9f}},
            {{0.1f, 1.45f}, {0.7f, 2.2f}, {0.95f, 1.6f}, {1.5f, 2.0f}, {1.5f, 1.45f}, {2.0f, 1.4f}, {1.3f, 1.0f}, {0.6f, 0.85f}},
            {{0.1f, 1.4f}, {0.4f, 2.1f}, {0.9f, 1.5f}, {1.3f, 2.2f}, {1.5f, 1.3f}, {1.9f, 1.6f}, {1.2f, 0.8f}, {0.5f, 0.7f}}
    };

    private static int cr;
    private static int cg;
    private static int cb;
    private static VertexConsumer vc;
    private static MatrixStack.Entry en;
    private static float bx, by, bz, sfx, sfz, srx, srz, tm;

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static void col(int rgb) {
        cr = (rgb >> 16) & 0xFF;
        cg = (rgb >> 8) & 0xFF;
        cb = rgb & 0xFF;
    }

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            BlueConfig f = BlueConfig.get();
            if (!(f.wings || f.mask || f.vest || f.shields || f.halo || f.horns || f.aura || f.crown || f.tail
                    || f.visor || f.stars3d || f.cape || f.pads || f.hearts3d || f.ears || f.jetpack || f.crystal)) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            en = ctx.matrixStack().peek();
            tm = mc.world.getTime() + td;
            boolean first = mc.options.getPerspective().isFirstPerson();

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity) || e.isRemoved()) {
                    continue;
                }
                PlayerEntity p = (PlayerEntity) e;
                boolean self = p == mc.player;
                if (self && first) {
                    continue;
                }
                if (!self && (!f.cosOthers || f.lite || p.isInvisible() || mc.player.squaredDistanceTo(p) > 32 * 32)) {
                    continue;
                }
                bx = (float) (MathHelper.lerp(td, p.prevX, p.getX()) - cam.x);
                by = (float) (MathHelper.lerp(td, p.prevY, p.getY()) - cam.y) + (p.isInSneakingPose() ? -0.25f : 0.0f);
                bz = (float) (MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z);
                float yaw = (float) Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
                sfx = -MathHelper.sin(yaw);
                sfz = MathHelper.cos(yaw);
                srx = -MathHelper.cos(yaw);
                srz = -MathHelper.sin(yaw);
                draw(f);
            }
        });
    }

    private static void draw(BlueConfig f) {
        if (f.wings) {
            col(BlueConfig.cosRgb());
            wings(f.wingStyle);
        }
        if (f.cape) {
            col(0xFF4050);
            cape();
        }
        if (f.jetpack) {
            col(0xFF9030);
            box(-0.2f, 0.2f, 0.85f, 1.35f, -0.34f, -0.14f);
            box(-0.17f, -0.04f, 0.5f, 0.85f, -0.3f, -0.18f);
            box(0.04f, 0.17f, 0.5f, 0.85f, -0.3f, -0.18f);
            col(0xFFD030);
            for (int s = -1; s <= 1; s += 2) {
                float fl = 0.15f * MathHelper.sin(tm * 0.8f + s);
                float[] a = L(0.105f * s, 0.5f, -0.24f);
                float[] b = L(0.13f * s, 0.3f + fl, -0.26f);
                float[] c = L(0.105f * s, 0.12f + fl, -0.24f);
                float[] d = L(0.08f * s, 0.3f + fl, -0.26f);
                seg(a, b);
                seg(b, c);
                seg(c, d);
                seg(d, a);
            }
        }
        if (f.vest) {
            col(0x6C7CC0);
            box(-0.3f, 0.3f, 0.72f, 1.42f, -0.18f, 0.18f);
            col(0xFFB040);
            box(-0.2f, -0.05f, 0.85f, 1.0f, 0.18f, 0.26f);
            box(0.05f, 0.2f, 0.85f, 1.0f, 0.18f, 0.26f);
            col(0xFF5050);
            seg(L(-0.3f, 1.42f, 0.18f), L(0.3f, 0.72f, 0.18f));
            seg(L(0.3f, 1.42f, 0.18f), L(-0.3f, 0.72f, 0.18f));
        }
        if (f.pads) {
            col(0xC8D0E0);
            box(0.27f, 0.52f, 1.35f, 1.5f, -0.16f, 0.16f);
            box(-0.52f, -0.27f, 1.35f, 1.5f, -0.16f, 0.16f);
        }
        if (f.mask) {
            col(0x8FB08F);
            box(-0.2f, 0.2f, 1.42f, 1.68f, 0.26f, 0.3f);
            col(0xFF8030);
            box(-0.09f, 0.09f, 1.42f, 1.56f, 0.3f, 0.45f);
            col(0xD0D0D0);
            box(-0.28f, 0.28f, 1.55f, 1.68f, -0.28f, 0.28f);
        }
        if (f.visor) {
            col(0x30E0FF);
            box(-0.27f, 0.27f, 1.57f, 1.72f, 0.26f, 0.3f);
            seg(L(-0.27f, 1.65f, 0.3f), L(0.27f, 1.65f, 0.3f));
        }
        if (f.horns) {
            col(0xFF3030);
            for (int s = -1; s <= 1; s += 2) {
                float[][] hp = {{0.18f, 1.82f, 0.0f}, {0.3f, 1.95f, 0.02f}, {0.36f, 2.1f, 0.06f}, {0.3f, 2.25f, 0.12f}, {0.2f, 2.32f, 0.16f}};
                float[] pv = null;
                int hi = 0;
                for (float[] q : hp) {
                    float[] cur = L(q[0] * s, q[1], q[2]);
                    if (pv != null) {
                        col(mix(0xA01010, 0xFFA030, hi / 4.0f));
                        seg(pv, cur);
                    }
                    hi++;
                    pv = cur;
                }
            }
        }
        if (f.ears) {
            col(0xFF90C0);
            for (int s = -1; s <= 1; s += 2) {
                float[] a = L(0.07f * s, 1.87f, 0.0f);
                float[] b = L(0.24f * s, 1.87f, 0.0f);
                float[] t = L(0.22f * s, 2.1f, -0.03f);
                seg(a, t);
                seg(t, b);
                seg(a, b);
                seg(L(0.12f * s, 1.9f, 0.0f), L(0.2f * s, 2.0f, -0.02f));
            }
        }
        if (f.crown) {
            col(0xFFD040);
            int n = 8;
            for (int i = 0; i < n; i++) {
                float a1 = (float) (Math.PI * 2 * i / n);
                float a2 = (float) (Math.PI * 2 * (i + 1) / n);
                float am = (a1 + a2) / 2;
                float[] p1 = {bx + MathHelper.cos(a1) * 0.27f, by + 1.9f, bz + MathHelper.sin(a1) * 0.27f};
                float[] p2 = {bx + MathHelper.cos(a2) * 0.27f, by + 1.9f, bz + MathHelper.sin(a2) * 0.27f};
                float[] pk = {bx + MathHelper.cos(am) * 0.27f, by + 2.12f, bz + MathHelper.sin(am) * 0.27f};
                col(0xFFD040);
                seg(p1, p2);
                col(0xFFF0A0);
                seg(p1, pk);
                seg(pk, p2);
            }
        }
        if (f.halo) {
            col(0xFFE070);
            float bob = 0.05f * MathHelper.sin(tm * 0.1f);
            ring(by + 2.0f + bob, 0.32f, tm * 0.05f, 20, false);
            col(0xFFFFFF);
            ring(by + 2.0f + bob, 0.26f, -tm * 0.05f, 20, false);
        }
        if (f.crystal) {
            col(0x70F0FF);
            float cy = by + 2.5f + 0.08f * MathHelper.sin(tm * 0.08f);
            float rot = tm * 0.06f;
            float[] top = {bx, cy + 0.28f, bz};
            float[] bot = {bx, cy - 0.28f, bz};
            float[][] eq = new float[4][];
            for (int i = 0; i < 4; i++) {
                float a = rot + (float) (Math.PI / 2 * i);
                eq[i] = new float[]{bx + MathHelper.cos(a) * 0.17f, cy, bz + MathHelper.sin(a) * 0.17f};
            }
            for (int i = 0; i < 4; i++) {
                seg(top, eq[i]);
                seg(bot, eq[i]);
                seg(eq[i], eq[(i + 1) % 4]);
            }
        }
        if (f.tail) {
            col(0xFF70C0);
            float[] pv = null;
            for (int i = 0; i <= 9; i++) {
                float a = MathHelper.sin(tm * 0.12f + i * 0.6f) * 0.03f * i;
                float[] cur = L(a, 0.8f - i * 0.03f + i * i * 0.006f, -0.15f - i * 0.1f);
                if (pv != null) {
                    seg(pv, cur);
                }
                pv = cur;
            }
        }
        if (f.stars3d) {
            col(0xFFE060);
            for (int k = 0; k < 4; k++) {
                double ang = tm * 0.05 + k * Math.PI / 2;
                float cx = bx + (float) Math.cos(ang) * 0.95f;
                float cz = bz + (float) Math.sin(ang) * 0.95f;
                float cy = by + 1.0f + 0.4f * MathHelper.sin(tm * 0.07f + k * 1.7f);
                float tx = (float) -Math.sin(ang);
                float tz = (float) Math.cos(ang);
                float sz = 0.14f;
                float[] n = {cx, cy + sz, cz};
                float[] s = {cx, cy - sz, cz};
                float[] w = {cx - tx * sz, cy, cz - tz * sz};
                float[] e = {cx + tx * sz, cy, cz + tz * sz};
                seg(n, e);
                seg(e, s);
                seg(s, w);
                seg(w, n);
                seg(n, s);
                seg(w, e);
            }
        }
        if (f.hearts3d) {
            col(0xFF5080);
            for (int k = 0; k < 3; k++) {
                double ang = -tm * 0.04 + k * Math.PI * 2 / 3;
                float cx = bx + (float) Math.cos(ang) * 0.85f;
                float cz = bz + (float) Math.sin(ang) * 0.85f;
                float cy = by + 1.2f + 0.25f * MathHelper.sin(tm * 0.09f + k * 2.1f);
                heart(cx, cy, cz, (float) -Math.sin(ang), (float) Math.cos(ang), 0.1f);
            }
        }
        if (f.shields) {
            col(0x40A0FF);
            shields();
        }
        if (f.aura) {
            col(0xA050FF);
            float k = (tm * 0.02f) % 1.0f;
            float k2 = (k + 0.5f) % 1.0f;
            ring(by + 0.05f + k * 1.9f, 0.9f - 0.3f * k, tm * 0.04f, 24, true);
            col(0x40D0FF);
            ring(by + 0.05f + k2 * 1.9f, 0.9f - 0.3f * k2, -tm * 0.04f, 24, true);
        }
    }

    private static void wings(int style) {
        float[][] pts = WING[Math.floorMod(style, WING.length)];
        float flap = 0.9f + 0.1f * MathHelper.sin(tm * 0.15f);
        for (int side = -1; side <= 1; side += 2) {
            float[] px = null;
            float[] sh = L(pts[0][0] * side, pts[0][1], -0.15f);
            for (int i = 0; i < pts.length; i++) {
                float a = pts[i][0] * flap * side;
                float[] cur = L(a, pts[i][1], -0.15f - Math.abs(a) * 0.3f);
                if (px != null) {
                    col(mix(BlueConfig.cosRgb(), 0xFFFFFF, i / (float) pts.length * 0.5f));
                    seg(px, cur);
                }
                if (i > 0) {
                    col(mix(BlueConfig.cosRgb(), 0x000000, 0.45f));
                    seg(sh, cur);
                }
                px = cur;
            }
            col(BlueConfig.cosRgb());
            seg(px, sh);
        }
    }

    private static void cape() {
        float[] as = {-0.28f, -0.09f, 0.09f, 0.28f};
        float[][] prev = null;
        for (int i = 0; i <= 5; i++) {
            float b = 1.4f - i * 0.21f;
            float[][] cur = new float[4][];
            for (int j = 0; j < 4; j++) {
                float c = -0.15f - i * 0.05f + MathHelper.sin(tm * 0.1f + i * 0.9f + as[j] * 3.0f) * 0.04f * i;
                cur[j] = L(as[j], b, c);
                if (j > 0) {
                    seg(cur[j - 1], cur[j]);
                }
                if (prev != null) {
                    seg(prev[j], cur[j]);
                }
            }
            prev = cur;
        }
    }

    private static void shields() {
        for (int k = 0; k < 3; k++) {
            double ang = tm * 0.06 + k * Math.PI * 2.0 / 3.0;
            float ox = (float) Math.cos(ang) * 1.15f;
            float oz = (float) Math.sin(ang) * 1.15f;
            float tx = (float) -Math.sin(ang);
            float tz = (float) Math.cos(ang);
            for (int r = 0; r < 2; r++) {
                col(r == 0 ? 0x40A0FF : 0xA0E0FF);
                float hw = r == 0 ? 0.3f : 0.2f;
                float lo = r == 0 ? 0.55f : 0.7f;
                float hi = r == 0 ? 1.45f : 1.3f;
                float[] a = {bx + ox - tx * hw, by + lo, bz + oz - tz * hw};
                float[] b = {bx + ox + tx * hw, by + lo, bz + oz + tz * hw};
                float[] c = {bx + ox + tx * hw, by + hi, bz + oz + tz * hw};
                float[] d = {bx + ox - tx * hw, by + hi, bz + oz - tz * hw};
                seg(a, b);
                seg(b, c);
                seg(c, d);
                seg(d, a);
            }
            col(0xFFD040);
            seg(new float[]{bx + ox - tx * 0.3f, by + 0.55f, bz + oz - tz * 0.3f}, new float[]{bx + ox + tx * 0.3f, by + 1.45f, bz + oz + tz * 0.3f});
            seg(new float[]{bx + ox + tx * 0.3f, by + 0.55f, bz + oz + tz * 0.3f}, new float[]{bx + ox - tx * 0.3f, by + 1.45f, bz + oz - tz * 0.3f});
        }
    }

    private static void ring(float y, float r, float rot, int n, boolean dashed) {
        float[] pv = null;
        for (int i = 0; i <= n; i++) {
            float a = rot + (float) (Math.PI * 2.0 * i / n);
            float[] cur = {bx + MathHelper.cos(a) * r, y, bz + MathHelper.sin(a) * r};
            if (pv != null && (!dashed || i % 2 == 0)) {
                seg(pv, cur);
            }
            pv = cur;
        }
    }

    private static void heart(float cx, float cy, float cz, float tx, float tz, float size) {
        float[] pv = null;
        int seg = 14;
        for (int k = 0; k <= seg; k++) {
            double t = Math.PI * 2.0 * k / seg;
            float hx = (float) (16.0 * Math.pow(Math.sin(t), 3)) / 17.0f * size;
            float hy = (float) (13.0 * Math.cos(t) - 5.0 * Math.cos(2 * t) - 2.0 * Math.cos(3 * t) - Math.cos(4 * t)) / 17.0f * size;
            float[] cur = {cx + tx * hx, cy + hy, cz + tz * hx};
            if (pv != null) {
                seg(pv, cur);
            }
            pv = cur;
        }
    }

    private static float[] L(float a, float b, float c) {
        return new float[]{bx + srx * a + sfx * c, by + b, bz + srz * a + sfz * c};
    }

    private static void box(float a1, float a2, float b1, float b2, float c1, float c2) {
        float[][] p = new float[8][];
        int i = 0;
        for (int ai = 0; ai < 2; ai++) {
            for (int bi = 0; bi < 2; bi++) {
                for (int ci = 0; ci < 2; ci++) {
                    p[i++] = L(ai == 0 ? a1 : a2, bi == 0 ? b1 : b2, ci == 0 ? c1 : c2);
                }
            }
        }
        for (int k = 0; k < 8; k++) {
            if ((k & 1) == 0) {
                seg(p[k], p[k + 1]);
            }
            if ((k & 2) == 0) {
                seg(p[k], p[k + 2]);
            }
            if ((k & 4) == 0) {
                seg(p[k], p[k + 4]);
            }
        }
    }

    private static void seg(float[] a, float[] b) {
        float dx = b[0] - a[0];
        float dy = b[1] - a[1];
        float dz = b[2] - a[2];
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.0001f) {
            return;
        }
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(en, a[0], a[1], a[2]).color(cr, cg, cb, 255).normal(en, dx, dy, dz);
        vc.vertex(en, b[0], b[1], b[2]).color(cr, cg, cb, 255).normal(en, dx, dy, dz);
    }
}
