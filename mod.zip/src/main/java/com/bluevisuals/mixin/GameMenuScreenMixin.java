package com.bluevisuals.mixin;

import com.bluevisuals.BlueMenuScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {
    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void bluevisuals$addButton(CallbackInfo ci) {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Blue Visuals"),
                b -> this.client.setScreen(new BlueMenuScreen((Screen) (Object) this)))
                .dimensions(this.width - 106, this.height / 2 - 10, 100, 20).build());
    }
}
