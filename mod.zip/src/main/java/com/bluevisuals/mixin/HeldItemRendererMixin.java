package com.bluevisuals.mixin;

import com.bluevisuals.BlueConfig;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void bv$begin(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                          float swing, ItemStack item, float equip, MatrixStack matrices,
                          VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        int m = BlueConfig.get().viewModel;
        if (m <= 0 || hand != Hand.MAIN_HAND || item.isEmpty()) {
            return;
        }
        matrices.push();
        float sc;
        float dx;
        float dy;
        float dz;
        float rz;
        float ry = 0.0f;
        if (m == 1) {
            sc = 1.25f; dx = 0.32f; dy = -0.12f; dz = -0.72f; rz = -25.0f;
        } else if (m == 2) {
            sc = 1.5f; dx = 0.42f; dy = -0.2f; dz = -0.8f; rz = 0.0f;
        } else {
            sc = 1.9f; dx = 0.25f; dy = -0.08f; dz = -0.95f; rz = -35.0f; ry = 10.0f;
        }
        matrices.translate(dx, dy, dz);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rz));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
        matrices.scale(sc, sc, sc);
        matrices.translate(-0.56, 0.52, 0.72);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void bv$end(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                        float swing, ItemStack item, float equip, MatrixStack matrices,
                        VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        int m = BlueConfig.get().viewModel;
        if (m <= 0 || hand != Hand.MAIN_HAND || item.isEmpty()) {
            return;
        }
        matrices.pop();
    }
}
