package com.bluevisuals.mixin;

import com.bluevisuals.BlueConfig;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void bv$begin(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                          float swing, ItemStack item, float equip, MatrixStack matrices,
                          VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        int m = BlueConfig.get().viewModel;
        if (m <= 0 || hand != Hand.MAIN_HAND || item.isEmpty()) {
            return;
        }
        matrices.push();
        if (m == 1) {
            matrices.translate(-0.1, -0.15, 0.0);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-30.0f));
            matrices.scale(1.25f, 1.25f, 1.25f);
        } else if (m == 2) {
            matrices.translate(0.05, -0.1, -0.15);
            matrices.scale(1.5f, 1.5f, 1.5f);
        } else {
            matrices.translate(-0.25, -0.3, -0.3);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-40.0f));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(12.0f));
            matrices.scale(1.9f, 1.9f, 1.9f);
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void bv$end(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                        float swing, ItemStack item, float equip, MatrixStack matrices,
                        VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        int m = BlueConfig.get().viewModel;
        if (m <= 0 || hand != Hand.MAIN_HAND || item.isEmpty()) {
            return;
        }
        matrices.pop();
    }
}
