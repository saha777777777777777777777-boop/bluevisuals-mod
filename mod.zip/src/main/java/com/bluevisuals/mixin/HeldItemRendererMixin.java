package com.bluevisuals.mixin;

import com.bluevisuals.BlueConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    private static float bv$spin = 0.0f;
    private static boolean bv$pushed = false;

    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private float bv$swing(float swing) {
        bv$spin = 0.0f;
        BlueConfig cf = BlueConfig.get();
        if (!cf.spinSwing || swing <= 0.0f) {
            return swing;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.player.getMainHandStack().isIn(ItemTags.SWORDS)) {
            return swing;
        }
        bv$spin = swing;
        return 0.0f;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void bv$begin(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                          float swing, ItemStack item, float equip, MatrixStack matrices,
                          VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        bv$pushed = false;
        BlueConfig cf = BlueConfig.get();
        boolean main = hand == Hand.MAIN_HAND;
        int m = main ? cf.viewModel : 0;
        float ex = main ? cf.mDx : cf.oDx;
        float ey = main ? cf.mDy : cf.oDy;
        float ez = main ? cf.mDz : cf.oDz;
        float rx = main ? cf.mRx : cf.oRx;
        float rzz = main ? cf.mRz : cf.oRz;
        boolean spin = main && bv$spin > 0.0f && !item.isEmpty();
        boolean moved = ex != 0.0f || ey != 0.0f || ez != 0.0f || rx != 0.0f || rzz != 0.0f;
        if (item.isEmpty() || (m <= 0 && !moved && !spin)) {
            return;
        }
        matrices.push();
        bv$pushed = true;
        matrices.translate(ex, ey, ez);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rzz));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
        if (spin) {
            matrices.translate(0.56, -0.52, -0.72);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(bv$spin * 1080.0f));
            matrices.translate(-0.56, 0.52, 0.72);
        }
        if (m <= 0) {
            return;
        }
        float sc;
        float dx;
        float dy;
        float dz;
        float rz;
        float ry = 0.0f;
        if (m == 1) {
            sc = 1.25f; dx = 0.32f; dy = -0.45f; dz = -0.72f; rz = -25.0f;
        } else if (m == 2) {
            sc = 1.5f; dx = 0.42f; dy = -0.55f; dz = -0.8f; rz = 0.0f;
        } else {
            sc = 1.9f; dx = 0.25f; dy = -0.45f; dz = -0.95f; rz = -35.0f; ry = 10.0f;
        }
        matrices.translate(dx, dy, dz);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rz));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
        matrices.scale(sc, sc, sc);
        matrices.translate(-0.56, 0.52, 0.72);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void bv$end(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                        float swing, ItemStack item, float equip, MatrixStack matrices,
                        VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (bv$pushed) {
            bv$pushed = false;
            matrices.pop();
        }
    }
}
