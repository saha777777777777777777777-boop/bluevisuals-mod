package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Scan {
    public static final List<LivingEntity> living = new ArrayList<>();
    public static final List<PlayerEntity> players = new ArrayList<>();

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.world == null || mc.player == null) {
                living.clear();
                players.clear();
                return;
            }
            if (mc.world.getTime() % 3 != 0) {
                return;
            }
            List<LivingEntity> l = new ArrayList<>();
            List<PlayerEntity> p = new ArrayList<>();
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity || e.isRemoved()) {
                    continue;
                }
                if (mc.player.squaredDistanceTo(e) > 56.0 * 56.0) {
                    continue;
                }
                l.add((LivingEntity) e);
                if (e instanceof PlayerEntity) {
                    p.add((PlayerEntity) e);
                }
            }
            l.sort(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)));
            living.clear();
            for (int i = 0; i < Math.min(l.size(), 30); i++) {
                living.add(l.get(i));
            }
            players.clear();
            players.addAll(p);
        });
    }
}
