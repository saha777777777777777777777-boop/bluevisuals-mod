package com.bluevisuals;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;

public class HitEffects {
    public static Entity lastTarget;
    public static long lastHitTime;

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && entity instanceof LivingEntity) {
                lastTarget = entity;
                lastHitTime = world.getTime();
                if (BlueConfig.get().hitParticles) {
                    for (int i = 0; i < (BlueConfig.get().lite ? 5 : 12); i++) {
                        double px = entity.getX() + (world.random.nextDouble() - 0.5) * entity.getWidth();
                        double py = entity.getY() + world.random.nextDouble() * entity.getHeight();
                        double pz = entity.getZ() + (world.random.nextDouble() - 0.5) * entity.getWidth();
                        world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, px, py, pz,
                                (world.random.nextDouble() - 0.5) * 0.15, 0.08, (world.random.nextDouble() - 0.5) * 0.15);
                    }
                }
            }
            return ActionResult.PASS;
        });
    }
}
