package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public class PearlPath {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!BlueConfig.get().pearlPath) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            boolean holding = mc.player.getMainHandStack().isOf(Items.ENDER_PEARL)
                    || mc.player.getOffHandStack().isOf(Items.ENDER_PEARL);
            boolean any = holding;
            if (!any) {
                for (Entity e : mc.world.getEntities()) {
                    if (e instanceof EnderPearlEntity) {
                        any = true;
                        break;
                    }
                }
            }
            if (!any) {
                return;
            }

            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            MatrixStack.Entry entry = ctx.matrixStack().peek();
            int rgb = BlueConfig.rgb();
            int cr = (rgb >> 16) & 0xFF;
            int cg = (rgb >> 8) & 0xFF;
            int cb = rgb & 0xFF;

            if (holding) {
                Vec3d dir = mc.player.getRotationVec(td);
                Vec3d pv = mc.player.getVelocity();
                Vec3d vel = new Vec3d(dir.x * 1.5 + pv.x,
                        dir.y * 1.5 + (mc.player.isOnGround() ? 0.0 : pv.y),
                        dir.z * 1.5 + pv.z);
                Vec3d start = mc.player.getCameraPosVec(td).subtract(0.0, 0.1, 0.0);
                simulate(mc, vc, entry, cam, start, vel, cr, cg, cb);
            }
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof EnderPearlEntity) {
                    simulate(mc, vc, entry, cam, e.getPos(), e.getVelocity(), cr, cg, cb);
                }
            }
        });
    }

    private static void simulate(MinecraftClient mc, VertexConsumer vc, MatrixStack.Entry entry, Vec3d cam,
                                 Vec3d start, Vec3d vel, int cr, int cg, int cb) {
        Vec3d pos = start;
        Vec3d v = vel;
        int max = BlueConfig.get().lite ? 40 : 120;
        for (int i = 0; i < max; i++) {
            Vec3d next = pos.add(v);
            BlockHitResult hit = mc.world.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
            boolean landed = hit.getType() != HitResult.Type.MISS;
            Vec3d end = landed ? hit.getPos() : next;
            seg(vc, entry, cam, pos, end, cr, cg, cb);
            if (landed) {
                cross(vc, entry, cam, end, cr, cg, cb);
                return;
            }
            pos = next;
            v = v.multiply(0.99).add(0.0, -0.03, 0.0);
            if (pos.y < mc.world.getBottomY() - 5) {
                return;
            }
        }
    }

    private static void seg(VertexConsumer vc, MatrixStack.Entry entry, Vec3d cam, Vec3d a, Vec3d b,
                            int cr, int cg, int cb) {
        double dx = b.x - a.x;
        double dy = b.y - a.y;
        double dz = b.z - a.z;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-5) {
            return;
        }
        float nx = (float) (dx / len);
        float ny = (float) (dy / len);
        float nz = (float) (dz / len);
        vc.vertex(entry, (float) (a.x - cam.x), (float) (a.y - cam.y), (float) (a.z - cam.z))
                .color(cr, cg, cb, 255).normal(entry, nx, ny, nz);
        vc.vertex(entry, (float) (b.x - cam.x), (float) (b.y - cam.y), (float) (b.z - cam.z))
                .color(cr, cg, cb, 255).normal(entry, nx, ny, nz);
    }

    private static void cross(VertexConsumer vc, MatrixStack.Entry entry, Vec3d cam, Vec3d p,
                              int cr, int cg, int cb) {
        double s = 0.4;
        seg(vc, entry, cam, p.add(-s, 0.0, 0.0), p.add(s, 0.0, 0.0), cr, cg, cb);
        seg(vc, entry, cam, p.add(0.0, 0.0, -s), p.add(0.0, 0.0, s), cr, cg, cb);
        seg(vc, entry, cam, p, p.add(0.0, 1.6, 0.0), cr, cg, cb);
        seg(vc, entry, cam, p.add(-s, 0.05, -s), p.add(s, 0.05, -s), cr, cg, cb);
        seg(vc, entry, cam, p.add(s, 0.05, -s), p.add(s, 0.05, s), cr, cg, cb);
        seg(vc, entry, cam, p.add(s, 0.05, s), p.add(-s, 0.05, s), cr, cg, cb);
        seg(vc, entry, cam, p.add(-s, 0.05, s), p.add(-s, 0.05, -s), cr, cg, cb);
    }
}
