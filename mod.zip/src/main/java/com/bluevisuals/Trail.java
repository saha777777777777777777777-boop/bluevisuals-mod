package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Trail {
    private static final int LIFE = 50;
    private static final Map<Integer, ArrayDeque<double[]>> TRAILS = new HashMap<>();

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            BlueConfig cfg = BlueConfig.get();
            if (mc.world == null || mc.player == null || !cfg.trail) {
                TRAILS.clear();
                return;
            }
            long now = mc.world.getTime();
            Set<Integer> seen = new HashSet<>();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity) || e.isRemoved()) {
                    continue;
                }
                if (e != mc.player && (!cfg.cosOthers || cfg.lite || mc.player.squaredDistanceTo(e) > 40 * 40)) {
                    continue;
                }
                seen.add(e.getId());
                ArrayDeque<double[]> q = TRAILS.computeIfAbsent(e.getId(), k -> new ArrayDeque<>());
                double[] last = q.peekFirst();
                if (last == null || sq(last[0] - e.getX(), last[1] - e.getY(), last[2] - e.getZ()) > 0.04) {
                    q.addFirst(new double[]{e.getX(), e.getY(), e.getZ(), now});
                }
                while (!q.isEmpty() && now - q.peekLast()[3] > LIFE) {
                    q.removeLast();
                }
            }
            TRAILS.keySet().retainAll(seen);
        });

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            BlueConfig cfg = BlueConfig.get();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!cfg.trail || TRAILS.isEmpty() || mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            MatrixStack.Entry en = ctx.matrixStack().peek();
            int rgb = BlueConfig.rgb();
            int r = (rgb >> 16) & 255;
            int g = (rgb >> 8) & 255;
            int b = rgb & 255;
            int r2 = (r + 255) / 2;
            int g2 = (g + 255) / 2;
            int b2 = (b + 255) / 2;
            double nowT = mc.world.getTime() + td;

            for (Map.Entry<Integer, ArrayDeque<double[]>> en2 : TRAILS.entrySet()) {
                Entity e = mc.world.getEntityById(en2.getKey());
                if (e == null || e.isRemoved()) {
                    continue;
                }
                double hx = MathHelper.lerp(td, e.prevX, e.getX());
                double hy = MathHelper.lerp(td, e.prevY, e.getY());
                double hz = MathHelper.lerp(td, e.prevZ, e.getZ());
                float px = (float) (hx - cam.x);
                float py = (float) (hy + 0.9 - cam.y);
                float pz = (float) (hz - cam.z);
                int pa = 255;
                int idx = 0;
                for (double[] p : en2.getValue()) {
                    double age = nowT - p[3];
                    int a = (int) (255.0 * Math.max(0.0, 1.0 - age / LIFE));
                    float x = (float) (p[0] - cam.x);
                    float y = (float) (p[1] + 0.9 - cam.y);
                    float z = (float) (p[2] - cam.z);
                    line(vc, en, px, py, pz, pa, x, y, z, a, r, g, b);
                    px = x;
                    py = y;
                    pz = z;
                    pa = a;
                    if (idx % 5 == 0 && a > 10) {
                        ring(vc, en, (float) (p[0] - cam.x), (float) (p[1] + 0.05 - cam.y), (float) (p[2] - cam.z),
                                0.3f + (float) age * 0.012f, a, r2, g2, b2);
                    }
                    idx++;
                }
            }
        });
    }

    private static double sq(double a, double b, double c) {
        return a * a + b * b + c * c;
    }

    private static void ring(VertexConsumer vc, MatrixStack.Entry en, float cx, float cy, float cz, float rad, int a, int r, int g, int b) {
        int n = 16;
        float px = cx + rad;
        float pz = cz;
        for (int i = 1; i <= n; i++) {
            float ang = (float) (Math.PI * 2.0 * i / n);
            float x = cx + MathHelper.cos(ang) * rad;
            float z = cz + MathHelper.sin(ang) * rad;
            line(vc, en, px, cy, pz, a, x, cy, z, a, r, g, b);
            px = x;
            pz = z;
        }
    }

    private static void line(VertexConsumer vc, MatrixStack.Entry en, float x1, float y1, float z1, int a1,
                             float x2, float y2, float z2, int a2, int r, int g, int b) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.0001f) {
            return;
        }
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(en, x1, y1, z1).color(r, g, b, a1).normal(en, dx, dy, dz);
        vc.vertex(en, x2, y2, z2).color(r, g, b, a2).normal(en, dx, dy, dz);
    }
}
