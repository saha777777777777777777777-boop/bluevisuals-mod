package com.bluevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;

public class Optimizer {
    public static void set(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        GameOptions o = mc.options;
        if (o == null) {
            return;
        }
        if (on && !c.optimized) {
            c.optBackup = new int[]{
                    o.getViewDistance().getValue(),
                    o.getSimulationDistance().getValue(),
                    o.getGraphicsMode().getValue().ordinal(),
                    o.getParticles().getValue().ordinal(),
                    o.getCloudRenderMode().getValue().ordinal(),
                    (int) Math.round(o.getEntityDistanceScaling().getValue() * 100.0),
                    o.getBiomeBlendRadius().getValue(),
                    o.getEntityShadows().getValue() ? 1 : 0,
                    o.getMipmapLevels().getValue(),
                    c.lite ? 1 : 0,
                    c.stars ? 1 : 0,
                    c.fallingStars ? 1 : 0,
                    c.skyTint ? 1 : 0,
                    c.sparks ? 1 : 0,
                    c.trail ? 1 : 0
            };
            o.getViewDistance().setValue(5);
            o.getSimulationDistance().setValue(5);
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getEntityDistanceScaling().setValue(0.5);
            o.getBiomeBlendRadius().setValue(0);
            o.getEntityShadows().setValue(false);
            o.getMipmapLevels().setValue(0);
            c.lite = true;
            c.stars = false;
            c.fallingStars = false;
            c.skyTint = false;
            c.sparks = false;
            c.trail = false;
            c.optimized = true;
        } else if (!on && c.optimized) {
            int[] b = c.optBackup;
            if (b != null && b.length >= 15) {
                o.getViewDistance().setValue(b[0]);
                o.getSimulationDistance().setValue(b[1]);
                o.getGraphicsMode().setValue(GraphicsMode.values()[Math.min(b[2], GraphicsMode.values().length - 1)]);
                o.getParticles().setValue(ParticlesMode.values()[Math.min(b[3], ParticlesMode.values().length - 1)]);
                o.getCloudRenderMode().setValue(CloudRenderMode.values()[Math.min(b[4], CloudRenderMode.values().length - 1)]);
                o.getEntityDistanceScaling().setValue(b[5] / 100.0);
                o.getBiomeBlendRadius().setValue(b[6]);
                o.getEntityShadows().setValue(b[7] == 1);
                o.getMipmapLevels().setValue(b[8]);
                c.lite = b[9] == 1;
                c.stars = b[10] == 1;
                c.fallingStars = b[11] == 1;
                c.skyTint = b[12] == 1;
                c.sparks = b[13] == 1;
                c.trail = b[14] == 1;
            }
            c.optimized = false;
        }
        o.write();
        if (mc.worldRenderer != null) {
            mc.worldRenderer.reload();
        }
        BlueConfig.save();
    }
}
