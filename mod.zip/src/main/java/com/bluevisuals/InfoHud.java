package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Formatting;
import net.minecraft.sound.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;

public class InfoHud {
    private static int comboCount = 0;
    private static long lastHitMs = 0;

    private static int totems, apples, pearls;
    private static long lastStockTick = -100;
    private static long lastCombatMs = 0;
    private static final java.util.ArrayDeque<Long> HITS = new java.util.ArrayDeque<>();
    private static double lastX, lastZ, speed;
    private static boolean wasDead = false;
    private static int freeCount, blockCount, foodCount;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            BlueConfig cfg = BlueConfig.get();
            if (mc.player == null || mc.world == null) {
                return;
            }
            if (cfg.autoSprint && mc.currentScreen == null && mc.options.forwardKey.isPressed() && !mc.player.isSneaking()) {
                mc.options.sprintKey.setPressed(true);
            }
            double dx = mc.player.getX() - lastX;
            double dz = mc.player.getZ() - lastZ;
            speed = speed * 0.7 + Math.sqrt(dx * dx + dz * dz) * 20.0 * 0.3;
            lastX = mc.player.getX();
            lastZ = mc.player.getZ();
            boolean dead = mc.player.getHealth() <= 0.0f || mc.player.isDead();
            if (dead && !wasDead && cfg.deathMarker) {
                cfg.markers.removeIf(m -> "Смерть".equals(m.name));
                cfg.markers.add(new BlueConfig.Marker(mc.player.getX(), mc.player.getY(), mc.player.getZ(), "Смерть"));
                BlueConfig.save();
            }
            wasDead = dead;
            if (mc.player.hurtTime > 0) {
                lastCombatMs = System.currentTimeMillis();
            }
            if (mc.world.getTime() - lastStockTick >= 10) {
                lastStockTick = mc.world.getTime();
                int t = 0;
                int a = 0;
                int p = 0;
                int n = mc.player.getInventory().size();
                int fr = 0;
                int bl = 0;
                int fd = 0;
                for (int i = 0; i < n; i++) {
                    ItemStack st = mc.player.getInventory().getStack(i);
                    if (st.isEmpty()) {
                        if (i < 36) {
                            fr++;
                        }
                        continue;
                    }
                    if (i < 36) {
                        if (st.getItem() instanceof BlockItem) {
                            bl += st.getCount();
                        }
                        if (st.contains(DataComponentTypes.FOOD)) {
                            fd += st.getCount();
                        }
                    }
                    if (st.isOf(Items.TOTEM_OF_UNDYING)) {
                        t += st.getCount();
                    } else if (st.isOf(Items.GOLDEN_APPLE) || st.isOf(Items.ENCHANTED_GOLDEN_APPLE)) {
                        a += st.getCount();
                    } else if (st.isOf(Items.ENDER_PEARL)) {
                        p += st.getCount();
                    }
                }
                freeCount = fr;
                blockCount = bl;
                foodCount = fd;
                totems = t;
                apples = a;
                pearls = p;
            }
        });

        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (BlueConfig.get().tipDura && stack.isDamageable()) {
                int mx = stack.getMaxDamage();
                int left = mx - stack.getDamage();
                lines.add(Text.literal("Прочность: " + left + "/" + mx + " (" + (left * 100 / Math.max(1, mx)) + "%)").formatted(Formatting.GRAY));
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity) {
                long now = System.currentTimeMillis();
                if (now - lastHitMs > 2500) {
                    comboCount = 0;
                }
                comboCount++;
                lastHitMs = now;
                lastCombatMs = now;
                HITS.addLast(now);
                if (BlueConfig.get().hitSound) {
                    player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.4f);
                }
            }
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            BlueConfig cfg = BlueConfig.get();
            if (mc.player == null || mc.world == null || mc.options.hudHidden || mc.currentScreen != null) {
                return;
            }
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            int rgb = 0xFF000000 | BlueConfig.rgb();

            if (cfg.targetInfo) {
                Entity t = mc.targetedEntity;
                if (t instanceof LivingEntity && t != mc.player) {
                    LivingEntity le = (LivingEntity) t;
                    String name = le.getName().getString();
                    float hp = le.getHealth();
                    float max = Math.max(1.0f, le.getMaxHealth());
                    float ratio = Math.max(0.0f, Math.min(1.0f, hp / max));
                    int dist = (int) mc.player.distanceTo(le);
                    int x = sw / 2 + 18;
                    int y = sh / 2 + 12;
                    int w = Math.max(80, mc.textRenderer.getWidth(name) + 10);
                    int ph = 30 + (cfg.targetGear ? 16 : 0);
                    ctx.fill(x, y, x + w, y + ph, 0xB00C0618);
                    ctx.fill(x, y, x + w, y + 1, rgb);
                    ctx.drawText(mc.textRenderer, name, x + 4, y + 4, 0xFFFFFFFF, false);
                    int bar = w - 8;
                    ctx.fill(x + 4, y + 15, x + 4 + bar, y + 19, 0xFF2A1A44);
                    int col = ratio > 0.6f ? 0xFF40E060 : (ratio > 0.3f ? 0xFFFFC040 : 0xFFFF4040);
                    ctx.fill(x + 4, y + 15, x + 4 + (int) (bar * ratio), y + 19, col);
                    if (cfg.targetGear) {
                        EquipmentSlot[] sl = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
                        ctx.getMatrices().push();
                        ctx.getMatrices().translate(x + 4, y + 32, 0);
                        ctx.getMatrices().scale(0.75f, 0.75f, 1.0f);
                        for (int gi = 0; gi < sl.length; gi++) {
                            ItemStack gs = le.getEquippedStack(sl[gi]);
                            if (!gs.isEmpty()) {
                                ctx.drawItem(gs, gi * 17, 0);
                            }
                        }
                        ctx.getMatrices().pop();
                    }
                    ctx.drawText(mc.textRenderer, Math.round(hp * 10.0f) / 10.0f + " / " + Math.round(max) + "   " + dist + " бл", x + 4, y + 21, 0xFFC0B0E8, false);
                }
            }

            if (cfg.combo && comboCount > 1 && System.currentTimeMillis() - lastHitMs < 2500) {
                String s = "Комбо x" + comboCount;
                int w = mc.textRenderer.getWidth(s);
                ctx.fill(sw / 2 - w / 2 - 4, sh / 2 + 46, sw / 2 + w / 2 + 4, sh / 2 + 58, 0x900C0618);
                ctx.drawText(mc.textRenderer, s, sw / 2 - w / 2, sh / 2 + 48, rgb, false);
            }

            List<String> lines = new ArrayList<>();
            if (cfg.combatTimer && System.currentTimeMillis() - lastCombatMs < 15000) {
                lines.add("Бой: " + ((System.currentTimeMillis() - lastCombatMs) / 1000) + " с");
            }
            if (cfg.pvpStock) {
                lines.add("Тотемы " + totems + "  Яблоки " + apples + "  Перлы " + pearls);
            }
            if (cfg.hitsPerSec) {
                long nowMs = System.currentTimeMillis();
                while (!HITS.isEmpty() && nowMs - HITS.peekFirst() > 1000) {
                    HITS.pollFirst();
                }
                lines.add("Удары: " + HITS.size() + "/с");
            }
            if (cfg.speedHud) {
                lines.add("Скорость: " + (Math.round(speed * 10.0) / 10.0) + " бл/с");
            }
            if (cfg.pingHud && mc.getNetworkHandler() != null) {
                PlayerListEntry ple = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (ple != null) {
                    lines.add("Пинг: " + ple.getLatency() + " мс");
                }
            }
            if (cfg.handDura) {
                ItemStack hs = mc.player.getMainHandStack();
                if (!hs.isEmpty() && hs.isDamageable()) {
                    int mx = hs.getMaxDamage();
                    lines.add("В руке: " + ((mx - hs.getDamage()) * 100 / Math.max(1, mx)) + "%");
                }
            }
            if (cfg.nearestInfo) {
                double best = 1.0e9;
                String bn = null;
                for (net.minecraft.entity.player.PlayerEntity pe : Scan.players) {
                    double d = mc.player.squaredDistanceTo(pe);
                    if (d < best) {
                        best = d;
                        bn = pe.getName().getString();
                    }
                }
                if (bn != null) {
                    lines.add("Рядом: " + bn + " " + (int) Math.sqrt(best) + " бл");
                }
            }
            if (cfg.freeSlots) {
                lines.add("Слоты свободно: " + freeCount + "/36");
            }
            if (cfg.itemCounts) {
                lines.add("Блоки " + blockCount + "  Еда " + foodCount);
            }
            if (cfg.armorValue) {
                lines.add("Защита: " + mc.player.getArmor());
            }
            if (cfg.xpLevel) {
                lines.add("Уровень: " + mc.player.experienceLevel);
            }
            if (cfg.handStock) {
                ItemStack hs2 = mc.player.getMainHandStack();
                if (!hs2.isEmpty() && hs2.getMaxCount() > 1) {
                    int total = 0;
                    for (int i = 0; i < 36; i++) {
                        ItemStack q = mc.player.getInventory().getStack(i);
                        if (q.isOf(hs2.getItem())) {
                            total += q.getCount();
                        }
                    }
                    lines.add("В запасе: " + total);
                }
            }
            if (cfg.worldTime) {
                long tt = mc.world.getTimeOfDay();
                int hh = (int) (((tt / 1000L) + 6L) % 24L);
                int mm = (int) ((tt % 1000L) * 60L / 1000L);
                lines.add("Время: " + (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm);
            }
            if (cfg.effectsHud) {
                for (StatusEffectInstance ef : mc.player.getStatusEffects()) {
                    int sec = ef.getDuration() / 20;
                    lines.add(Text.translatable(ef.getTranslationKey()).getString() + " " + (ef.getAmplifier() + 1)
                            + "  " + (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60));
                }
            }
            if (!lines.isEmpty()) {
                int wmax = 0;
                for (String ln : lines) {
                    wmax = Math.max(wmax, mc.textRenderer.getWidth(ln));
                }
                int x0 = sw - wmax - 8;
                int y0 = 26;
                ctx.fill(x0 - 2, y0 - 2, sw - 2, y0 + lines.size() * 11 + 1, 0x900C0618);
                ctx.fill(x0 - 2, y0 - 2, x0 - 1, y0 + lines.size() * 11 + 1, rgb);
                for (int i = 0; i < lines.size(); i++) {
                    ctx.drawText(mc.textRenderer, lines.get(i), x0 + 2, y0 + i * 11, 0xFFFFFFFF, false);
                }
            }

            int wy = sh / 2 - 44;
            if (cfg.totemWarn && !mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) && totems > 0) {
                ctx.drawCenteredTextWithShadow(mc.textRenderer, "ТОТЕМ НЕ В РУКЕ", sw / 2, wy, 0xFFFF5050);
                wy -= 11;
            }
            if (cfg.hungerWarn && mc.player.getHungerManager().getFoodLevel() <= 6) {
                ctx.drawCenteredTextWithShadow(mc.textRenderer, "ГОЛОД", sw / 2, wy, 0xFFFFC040);
                wy -= 11;
            }
            if (cfg.freeSlots && freeCount == 0) {
                ctx.drawCenteredTextWithShadow(mc.textRenderer, "ИНВЕНТАРЬ ПОЛОН", sw / 2, wy, 0xFFFF8040);
            }
            if (cfg.miniInv) {
                int mx0 = sw - 9 * 13 - 6;
                int my0 = sh - 3 * 13 - 6;
                ctx.fill(mx0 - 2, my0 - 2, mx0 + 9 * 13 + 2, my0 + 3 * 13 + 2, 0x900C0618);
                ctx.getMatrices().push();
                ctx.getMatrices().translate(mx0, my0, 0);
                ctx.getMatrices().scale(0.8f, 0.8f, 1.0f);
                for (int i = 9; i < 36; i++) {
                    ItemStack ms2 = mc.player.getInventory().getStack(i);
                    if (!ms2.isEmpty()) {
                        int cx = ((i - 9) % 9) * 16;
                        int cy = ((i - 9) / 9) * 16;
                        ctx.drawItem(ms2, cx, cy);
                        ctx.drawStackOverlay(mc.textRenderer, ms2, cx, cy);
                    }
                }
                ctx.getMatrices().pop();
            }

            if (cfg.lowHp && mc.player.getHealth() <= 6.0f && mc.player.isAlive()) {
                int pulse = (int) (40 + 40 * Math.abs(Math.sin(System.currentTimeMillis() / 300.0)));
                int c = (pulse << 24) | 0xFF2020;
                ctx.fill(0, 0, sw, 5, c);
                ctx.fill(0, sh - 5, sw, sh, c);
                ctx.fill(0, 5, 5, sh - 5, c);
                ctx.fill(sw - 5, 5, sw, sh - 5, c);
            }

            if (cfg.coords) {
                float yaw = mc.player.getYaw();
                int d = Math.floorMod((int) Math.floor((yaw + 45.0f) / 90.0f), 4);
                String[] dir = {"Юг", "Запад", "Север", "Восток"};
                String s = (int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ()
                        + "  " + dir[d] + "  " + mc.getCurrentFps() + " FPS";
                int w = mc.textRenderer.getWidth(s);
                ctx.fill(sw / 2 - w / 2 - 4, 2, sw / 2 + w / 2 + 4, 14, 0x900C0618);
                ctx.drawText(mc.textRenderer, s, sw / 2 - w / 2, 4, 0xFFFFFFFF, false);
            }
        });
    }
}
