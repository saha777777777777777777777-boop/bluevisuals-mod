package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;

public class InfoHud {
    private static int comboCount = 0;
    private static long lastHitMs = 0;

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity) {
                long now = System.currentTimeMillis();
                if (now - lastHitMs > 2500) {
                    comboCount = 0;
                }
                comboCount++;
                lastHitMs = now;
            }
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            BlueConfig cfg = BlueConfig.get();
            if (mc.player == null || mc.world == null || mc.options.hudHidden || mc.currentScreen != null) {
                return;
            }
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            int rgb = 0xFF000000 | BlueConfig.rgb();

            if (cfg.targetInfo) {
                Entity t = mc.targetedEntity;
                if (t instanceof LivingEntity && t != mc.player) {
                    LivingEntity le = (LivingEntity) t;
                    String name = le.getName().getString();
                    float hp = le.getHealth();
                    float max = Math.max(1.0f, le.getMaxHealth());
                    float ratio = Math.max(0.0f, Math.min(1.0f, hp / max));
                    int dist = (int) mc.player.distanceTo(le);
                    int x = sw / 2 + 18;
                    int y = sh / 2 + 12;
                    int w = Math.max(80, mc.textRenderer.getWidth(name) + 10);
                    ctx.fill(x, y, x + w, y + 30, 0xB00C0618);
                    ctx.fill(x, y, x + w, y + 1, rgb);
                    ctx.drawText(mc.textRenderer, name, x + 4, y + 4, 0xFFFFFFFF, false);
                    int bar = w - 8;
                    ctx.fill(x + 4, y + 15, x + 4 + bar, y + 19, 0xFF2A1A44);
                    int col = ratio > 0.6f ? 0xFF40E060 : (ratio > 0.3f ? 0xFFFFC040 : 0xFFFF4040);
                    ctx.fill(x + 4, y + 15, x + 4 + (int) (bar * ratio), y + 19, col);
                    ctx.drawText(mc.textRenderer, Math.round(hp * 10.0f) / 10.0f + " / " + Math.round(max) + "   " + dist + " бл", x + 4, y + 21, 0xFFC0B0E8, false);
                }
            }

            if (cfg.combo && comboCount > 1 && System.currentTimeMillis() - lastHitMs < 2500) {
                String s = "Комбо x" + comboCount;
                int w = mc.textRenderer.getWidth(s);
                ctx.fill(sw / 2 - w / 2 - 4, sh / 2 + 46, sw / 2 + w / 2 + 4, sh / 2 + 58, 0x900C0618);
                ctx.drawText(mc.textRenderer, s, sw / 2 - w / 2, sh / 2 + 48, rgb, false);
            }

            if (cfg.coords) {
                float yaw = mc.player.getYaw();
                int d = Math.floorMod((int) Math.floor((yaw + 45.0f) / 90.0f), 4);
                String[] dir = {"Юг", "Запад", "Север", "Восток"};
                String s = (int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ()
                        + "  " + dir[d] + "  " + mc.getCurrentFps() + " FPS";
                int w = mc.textRenderer.getWidth(s);
                ctx.fill(sw / 2 - w / 2 - 4, 2, sw / 2 + w / 2 + 4, 14, 0x900C0618);
                ctx.drawText(mc.textRenderer, s, sw / 2 - w / 2, 4, 0xFFFFFFFF, false);
            }
        });
    }
}
