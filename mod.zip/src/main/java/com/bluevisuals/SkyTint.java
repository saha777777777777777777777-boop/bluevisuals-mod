package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class SkyTint {
    public static void register() {
        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            BlueConfig cfg = BlueConfig.get();
            if (!cfg.skyTint || cfg.lite) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || mc.options.hudHidden) {
                return;
            }
            if (!mc.world.getDimension().hasSkyLight() || !mc.world.isSkyVisible(mc.player.getBlockPos())) {
                return;
            }
            int w = ctx.getScaledWindowWidth();
            int h = ctx.getScaledWindowHeight();
            double fov = mc.options.getFov().getValue();
            double pitch = Math.toRadians(mc.player.getPitch());
            double f = (h / 2.0) / Math.tan(Math.toRadians(fov) / 2.0);
            double horizonY = h / 2.0 - f * Math.tan(pitch);
            int horizon = (int) Math.max(0.0, Math.min((double) h, horizonY));
            if (horizon <= 0) {
                return;
            }
            int rgb = BlueConfig.skyRgb();
            int a0 = cfg.lite ? 0x30 : 0x50;
            ctx.fillGradient(0, 0, w, horizon, (a0 << 24) | rgb, rgb);
        });
    }
}
