package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class BlueMenuScreen extends Screen {
    private final Screen parent;
    private int px1, py1, px2, py2;

    public BlueMenuScreen(Screen parent) {
        super(Text.literal("Blue Visuals"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        BlueConfig c = BlueConfig.get();
        int w = 150;
        int cx = this.width / 2;
        int lx = cx - 155;
        int rx = cx + 5;
        int y = 28;
        int step = 20;

        addToggle(lx, y, w, "Броня на экране", () -> c.armorHud, v -> c.armorHud = v);
        addToggle(lx, y + step, w, "Прочность в %", () -> c.armorPercent, v -> c.armorPercent = v);
        addToggle(lx, y + step * 2, w, "Без огня на экране", () -> c.noFire, v -> c.noFire = v);
        addToggle(lx, y + step * 3, w, "Частицы удара", () -> c.hitParticles, v -> c.hitParticles = v);
        addToggle(lx, y + step * 4, w, "Здоровье над головой", () -> c.healthTags, v -> c.healthTags = v);
        addToggle(lx, y + step * 5, w, "Путь перла", () -> c.pearlPath, v -> c.pearlPath = v);

        addToggle(rx, y, w, "Квадрат на целях", () -> c.hologram, v -> c.hologram = v);
        addToggle(rx, y + step, w, "Квадрат на всех", () -> c.hologramAll, v -> c.hologramAll = v);

        this.addDrawableChild(ButtonWidget.builder(colorLabel(), b -> {
            c.colorIndex = (c.colorIndex + 1) % BlueConfig.COLOR_RGB.length;
            b.setMessage(colorLabel());
            BlueConfig.save();
        }).dimensions(rx, y + step * 2, w, 18).build());

        addToggle(rx, y + step * 3, w, "Упрощённо", () -> c.lite, v -> c.lite = v);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Небо..."), b -> {
            if (this.client != null) {
                this.client.setScreen(new SkyScreen(this));
            }
        }).dimensions(rx, y + step * 4, w, 18).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Косметика..."), b -> {
            if (this.client != null) {
                this.client.setScreen(new CosmeticsScreen(this));
            }
        }).dimensions(rx, y + step * 5, w, 18).build());

        int by = y + step * 6;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Метки..."), b -> {
            if (this.client != null) {
                this.client.setScreen(new MarkerScreen(this));
            }
        }).dimensions(lx, by, w, 18).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> this.close())
                .dimensions(rx, by, w, 18).build());

        px1 = lx - 10;
        py1 = y - 22;
        px2 = rx + w + 10;
        py2 = by + 18 + 8;
    }

    private static Text colorLabel() {
        return Text.literal("Цвет: " + BlueConfig.colorName());
    }

    private void addToggle(int x, int y, int w, String name, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        this.addDrawableChild(ButtonWidget.builder(label(name, getter.get()), b -> {
            boolean now = !getter.get();
            setter.accept(now);
            b.setMessage(label(name, now));
            BlueConfig.save();
        }).dimensions(x, y, w, 18).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, 0xFF14062B, 0xFF030208);
        drawSpeckles(context);
        context.fill(px1, py1, px2, py2, 0xCC12061F);
        int border = 0xFF8A4DFF;
        context.fill(px1, py1, px2, py1 + 1, border);
        context.fill(px1, py2 - 1, px2, py2, border);
        context.fill(px1, py1, px1 + 1, py2, border);
        context.fill(px2 - 1, py1, px2, py2, border);
    }

    private void drawSpeckles(DrawContext context) {
        java.util.Random r = new java.util.Random(1337L);
        long t = net.minecraft.util.Util.getMeasuringTimeMs();
        int n = BlueConfig.get().lite ? 0 : 170;
        for (int i = 0; i < n; i++) {
            int x = r.nextInt(Math.max(1, this.width));
            int y = r.nextInt(Math.max(1, this.height));
            int kind = r.nextInt(3);
            double phase = r.nextDouble() * 6.28;
            int a = (int) (80 + 120 * (0.5 + 0.5 * Math.sin(t / 600.0 + phase)));
            int rgb = kind == 0 ? 0xC9A8FF : (kind == 1 ? 0x8A4DFF : 0xFFFFFF);
            int size = (kind != 2 && r.nextInt(4) == 0) ? 2 : 1;
            context.fill(x, y, x + size, y + size, (a << 24) | rgb);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFF000000 | BlueConfig.rgb());
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
