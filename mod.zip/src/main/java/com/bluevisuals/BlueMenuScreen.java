package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class BlueMenuScreen extends Screen {
    private final Screen parent;
    private int px1, py1, px2, py2;

    public BlueMenuScreen(Screen parent) {
        super(Text.literal("Blue Visuals"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        BlueConfig c = BlueConfig.get();
        int w = 150;
        int lx = this.width / 2 - 155;
        int rx = this.width / 2 + 5;
        int y = 34;
        int step = 22;

        addToggle(lx, y, w, "Armor HUD", () -> c.armorHud, v -> c.armorHud = v);
        addToggle(lx, y + step, w, "Durability in %", () -> c.armorPercent, v -> c.armorPercent = v);
        addToggle(lx, y + step * 2, w, "No fire overlay", () -> c.noFire, v -> c.noFire = v);
        addToggle(lx, y + step * 3, w, "Hit particles", () -> c.hitParticles, v -> c.hitParticles = v);
        addToggle(lx, y + step * 4, w, "Health above heads", () -> c.healthTags, v -> c.healthTags = v);

        addToggle(rx, y, w, "Target hologram", () -> c.hologram, v -> c.hologram = v);
        addToggle(rx, y + step, w, "Hologram on all", () -> c.hologramAll, v -> c.hologramAll = v);
        addToggle(rx, y + step * 2, w, "Night stars", () -> c.stars, v -> c.stars = v);
        addToggle(rx, y + step * 4, w, "Falling stars", () -> c.fallingStars, v -> c.fallingStars = v);

        this.addDrawableChild(ButtonWidget.builder(colorLabel(), b -> {
            c.colorIndex = (c.colorIndex + 1) % BlueConfig.COLOR_RGB.length;
            b.setMessage(colorLabel());
            BlueConfig.save();
        }).dimensions(rx, y + step * 3, w, 20).build());

        px1 = lx - 10;
        py1 = y - 24;
        px2 = rx + w + 10;
        py2 = y + step * 5 + 4 + 20 + 10;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(this.width / 2 - 100, y + step * 5 + 4, 200, 20).build());
    }

    private static Text colorLabel() {
        return Text.literal("Color: " + BlueConfig.colorName());
    }

    private void addToggle(int x, int y, int w, String name, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        this.addDrawableChild(ButtonWidget.builder(label(name, getter.get()), b -> {
            boolean now = !getter.get();
            setter.accept(now);
            b.setMessage(label(name, now));
            BlueConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, 0xFF14062B, 0xFF030208);
        drawSpeckles(context);
        context.fill(px1, py1, px2, py2, 0xCC12061F);
        int border = 0xFF8A4DFF;
        context.fill(px1, py1, px2, py1 + 1, border);
        context.fill(px1, py2 - 1, px2, py2, border);
        context.fill(px1, py1, px1 + 1, py2, border);
        context.fill(px2 - 1, py1, px2, py2, border);
    }

    private void drawSpeckles(DrawContext context) {
        java.util.Random r = new java.util.Random(1337L);
        long t = net.minecraft.util.Util.getMeasuringTimeMs();
        for (int i = 0; i < 170; i++) {
            int x = r.nextInt(Math.max(1, this.width));
            int y = r.nextInt(Math.max(1, this.height));
            int kind = r.nextInt(3);
            double phase = r.nextDouble() * 6.28;
            int a = (int) (80 + 120 * (0.5 + 0.5 * Math.sin(t / 600.0 + phase)));
            int rgb = kind == 0 ? 0xC9A8FF : (kind == 1 ? 0x8A4DFF : 0xFFFFFF);
            int size = (kind != 2 && r.nextInt(4) == 0) ? 2 : 1;
            context.fill(x, y, x + size, y + size, (a << 24) | rgb);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFF000000 | BlueConfig.rgb());
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
