package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

public class BlueMenuScreen extends Screen {
    private static final int ACCENT = 0xFFA060FF;
    private static final String[] TABS = {"Бой", "Экран", "Инвентарь", "Косметика", "Мир"};

    private static class Tile {
        String name;
        int swatch;
        BooleanSupplier on;
        Supplier<String> value;
        Runnable click;
    }

    private final Screen parent;
    private int tab = 0;
    private int page = 0;
    private final List<Tile> tiles = new ArrayList<>();
    private int px, py, pw, ph, sb = 76, cx0, cw, tw, perPage, rows;

    public BlueMenuScreen(Screen parent) {
        super(Text.literal("Blue Visuals  v25"));
        this.parent = parent;
    }

    private Tile toggle(String name, int swatch, BooleanSupplier get, Runnable flip) {
        Tile t = new Tile();
        t.name = name;
        t.swatch = swatch;
        t.on = get;
        t.click = () -> {
            flip.run();
            BlueConfig.save();
        };
        tiles.add(t);
        return t;
    }

    private void choice(String name, int swatch, Supplier<String> value, Runnable next) {
        Tile t = new Tile();
        t.name = name;
        t.swatch = swatch;
        t.value = value;
        t.click = () -> {
            next.run();
            BlueConfig.save();
        };
        tiles.add(t);
    }

    private void button(String name, Runnable r) {
        Tile t = new Tile();
        t.name = name;
        t.swatch = ACCENT & 0xFFFFFF;
        t.value = () -> ">";
        t.click = r;
        tiles.add(t);
    }

    private void build() {
        tiles.clear();
        BlueConfig c = BlueConfig.get();
        if (tab == 0) {
            toggle("Метка на цели", 0xA060FF, () -> c.hologram, () -> c.hologram = !c.hologram);
            toggle("Метка на всех", 0xA060FF, () -> c.hologramAll, () -> c.hologramAll = !c.hologramAll);
            choice("Вид метки", 0xA060FF, () -> Shapes.NAMES[Math.floorMod(c.targetStyle, Shapes.NAMES.length)],
                    () -> c.targetStyle = (c.targetStyle + 1) % Shapes.NAMES.length);
            choice("Цвет мода", BlueConfig.rgb(), BlueConfig::colorName,
                    () -> c.colorIndex = (c.colorIndex + 1) % BlueConfig.COLOR_RGB.length);
            toggle("Здоровье над целью", 0xFF5060, () -> c.healthTags, () -> c.healthTags = !c.healthTags);
            toggle("Круг у прицела", 0x40FF60, () -> c.crosshair, () -> c.crosshair = !c.crosshair);
            toggle("Частицы при ударе", 0x60C0FF, () -> c.hitParticles, () -> c.hitParticles = !c.hitParticles);
            toggle("Траектория перла", 0x40E0C0, () -> c.pearlPath, () -> c.pearlPath = !c.pearlPath);
        } else if (tab == 1) {
            toggle("Броня на экране", 0x8AB4FF, () -> c.armorHud, () -> c.armorHud = !c.armorHud);
            toggle("Прочность в %", 0x8AB4FF, () -> c.armorPercent, () -> c.armorPercent = !c.armorPercent);
            toggle("Без огня на экране", 0xFF8030, () -> c.noFire, () -> c.noFire = !c.noFire);
            toggle("Искры на экране", 0xFFE060, () -> c.sparks, () -> c.sparks = !c.sparks);
            choice("Предмет в руке", 0xB080FF, () -> Shapes.VIEW_NAMES[Math.floorMod(c.viewModel, Shapes.VIEW_NAMES.length)],
                    () -> c.viewModel = (c.viewModel + 1) % Shapes.VIEW_NAMES.length);
            toggle("Инфо о цели", 0xFF8060, () -> c.targetInfo, () -> c.targetInfo = !c.targetInfo);
            toggle("Счётчик комбо", 0xFFC040, () -> c.combo, () -> c.combo = !c.combo);
            toggle("Координаты и FPS", 0x80E0A0, () -> c.coords, () -> c.coords = !c.coords);
            toggle("Упрощённый режим", 0xC0C0C0, () -> c.lite, () -> c.lite = !c.lite);
        } else if (tab == 2) {
            toggle("Просмотр шалкера", 0xC080FF, () -> c.shulkerPreview, () -> c.shulkerPreview = !c.shulkerPreview);
        } else if (tab == 3) {
            toggle("Крылья", BlueConfig.cosRgb(), () -> c.wings, () -> c.wings = !c.wings);
            choice("Вид крыльев", BlueConfig.cosRgb(), () -> Cosmetics.STYLES[Math.floorMod(c.wingStyle, Cosmetics.STYLES.length)],
                    () -> c.wingStyle = (c.wingStyle + 1) % Cosmetics.STYLES.length);
            choice("Цвет крыльев", BlueConfig.cosRgb(),
                    () -> BlueConfig.COLOR_NAMES[Math.floorMod(c.cosColorIndex, BlueConfig.COLOR_NAMES.length)],
                    () -> c.cosColorIndex = (c.cosColorIndex + 1) % BlueConfig.COLOR_RGB.length);
            toggle("Нимб", 0xFFE070, () -> c.halo, () -> c.halo = !c.halo);
            toggle("Корона", 0xFFD040, () -> c.crown, () -> c.crown = !c.crown);
            toggle("Рога", 0xFF3030, () -> c.horns, () -> c.horns = !c.horns);
            toggle("Кошачьи ушки", 0xFF90C0, () -> c.ears, () -> c.ears = !c.ears);
            toggle("Кристалл", 0x70F0FF, () -> c.crystal, () -> c.crystal = !c.crystal);
            toggle("Очки-визор", 0x30E0FF, () -> c.visor, () -> c.visor = !c.visor);
            toggle("Противогаз", 0x8FB08F, () -> c.mask, () -> c.mask = !c.mask);
            toggle("Бронежилет", 0x6C7CC0, () -> c.vest, () -> c.vest = !c.vest);
            toggle("Наплечники", 0xC8D0E0, () -> c.pads, () -> c.pads = !c.pads);
            toggle("Плащ", 0xFF4050, () -> c.cape, () -> c.cape = !c.cape);
            toggle("Реактивный ранец", 0xFF9030, () -> c.jetpack, () -> c.jetpack = !c.jetpack);
            toggle("Хвост", 0xFF70C0, () -> c.tail, () -> c.tail = !c.tail);
            toggle("Щиты вокруг", 0x40A0FF, () -> c.shields, () -> c.shields = !c.shields);
            toggle("Звёзды вокруг", 0xFFE060, () -> c.stars3d, () -> c.stars3d = !c.stars3d);
            toggle("Сердечки вокруг", 0xFF5080, () -> c.hearts3d, () -> c.hearts3d = !c.hearts3d);
            toggle("Аура-кольца", 0xA050FF, () -> c.aura, () -> c.aura = !c.aura);
            toggle("На других игроках", 0xFFFFFF, () -> c.cosOthers, () -> c.cosOthers = !c.cosOthers);
        } else {
            toggle("Оттенок неба", BlueConfig.skyRgb(), () -> c.skyTint, () -> c.skyTint = !c.skyTint);
            choice("Цвет неба", BlueConfig.skyRgb(), BlueConfig::skyColorName,
                    () -> c.skyColorIndex = (c.skyColorIndex + 1) % BlueConfig.COLOR_RGB.length);
            toggle("Звёзды ночью", 0xFFFFFF, () -> c.stars, () -> c.stars = !c.stars);
            toggle("Падающие кометы", 0x80D0FF, () -> c.fallingStars, () -> c.fallingStars = !c.fallingStars);
            button("Метки...", () -> {
                if (this.client != null) {
                    this.client.setScreen(new MarkerScreen(this));
                }
            });
        }
    }

    @Override
    protected void init() {
        pw = Math.min(this.width - 8, 420);
        ph = Math.min(this.height - 6, 236);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        cx0 = px + sb + 6;
        cw = pw - sb - 12;
        tw = (cw - 4) / 2;
        rows = Math.max(2, (ph - 26 - 28) / 23);
        perPage = rows * 2;
        build();
        page = Math.min(page, Math.max(0, (tiles.size() - 1) / perPage));
    }

    private int pages() {
        return Math.max(1, (tiles.size() + perPage - 1) / perPage);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 28 + i * 24;
            if (mx >= px + 6 && mx <= px + sb - 4 && my >= ty && my <= ty + 20) {
                tab = i;
                page = 0;
                build();
                return true;
            }
        }
        int start = page * perPage;
        for (int i = start; i < Math.min(tiles.size(), start + perPage); i++) {
            int k = i - start;
            int x = cx0 + (k % 2) * (tw + 4);
            int y = py + 24 + (k / 2) * 23;
            if (mx >= x && mx <= x + tw && my >= y && my <= y + 20) {
                tiles.get(i).click.run();
                return true;
            }
        }
        int fy = py + ph - 22;
        if (my >= fy && my <= fy + 18) {
            if (mx >= cx0 && mx <= cx0 + 22 && page > 0) {
                page--;
                return true;
            }
            if (mx >= cx0 + 58 && mx <= cx0 + 80 && page < pages() - 1) {
                page++;
                return true;
            }
            if (mx >= px + pw - 76 && mx <= px + pw - 6) {
                this.close();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (v < 0 && page < pages() - 1) {
            page++;
        } else if (v > 0 && page > 0) {
            page--;
        }
        return true;
    }

    @Override
    public void renderBackground(DrawContext g, int mouseX, int mouseY, float delta) {
        g.fillGradient(0, 0, this.width, this.height, 0xFF160733, 0xFF030208);
        speckles(g);
    }

    private void speckles(DrawContext g) {
        java.util.Random r = new java.util.Random(1337L);
        long t = net.minecraft.util.Util.getMeasuringTimeMs();
        int n = BlueConfig.get().lite ? 0 : 170;
        for (int i = 0; i < n; i++) {
            int x = r.nextInt(Math.max(1, this.width));
            int y = r.nextInt(Math.max(1, this.height));
            int kind = r.nextInt(3);
            double phase = r.nextDouble() * 6.28;
            int a = (int) (80 + 120 * (0.5 + 0.5 * Math.sin(t / 600.0 + phase)));
            int rgb = kind == 0 ? 0xC9A8FF : (kind == 1 ? 0x8A4DFF : 0xFFFFFF);
            int size = (kind != 2 && r.nextInt(4) == 0) ? 2 : 1;
            g.fill(x, y, x + size, y + size, (a << 24) | rgb);
        }
    }

    private void frame(DrawContext g, int x1, int y1, int x2, int y2, int fill, int border) {
        g.fill(x1, y1, x2, y2, fill);
        g.fill(x1, y1, x2, y1 + 1, border);
        g.fill(x1, y2 - 1, x2, y2, border);
        g.fill(x1, y1, x1 + 1, y2, border);
        g.fill(x2 - 1, y1, x2, y2, border);
    }

    private void small(DrawContext g, String s, int x, int y, int color) {
        g.getMatrices().push();
        g.getMatrices().translate(x, y, 0);
        g.getMatrices().scale(0.8f, 0.8f, 1.0f);
        g.drawText(this.textRenderer, s, 0, 0, color, false);
        g.getMatrices().pop();
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        renderBackground(g, mx, my, delta);
        frame(g, px, py, px + pw, py + ph, 0xDD0E0520, ACCENT);
        // sidebar
        g.fill(px + 1, py + 1, px + sb, py + ph - 1, 0xEE180A33);
        g.drawText(this.textRenderer, "BLUE", px + 8, py + 6, ACCENT, true);
        g.drawText(this.textRenderer, "v25", px + 8 + 30, py + 6, 0xFF8070B0, false);
        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 28 + i * 24;
            boolean sel = i == tab;
            boolean hov = mx >= px + 6 && mx <= px + sb - 4 && my >= ty && my <= ty + 20;
            g.fill(px + 6, ty, px + sb - 4, ty + 20, sel ? 0xFF3A1A78 : (hov ? 0xFF2A1458 : 0xFF1C0D3C));
            if (sel) {
                g.fill(px + 6, ty, px + 8, ty + 20, ACCENT);
            }
            g.drawText(this.textRenderer, TABS[i], px + 13, ty + 6, sel ? 0xFFFFFFFF : 0xFFB8A8E0, false);
        }
        // title
        g.drawText(this.textRenderer, TABS[tab], cx0, py + 8, 0xFFFFFFFF, true);
        // tiles
        int start = page * perPage;
        for (int i = start; i < Math.min(tiles.size(), start + perPage); i++) {
            Tile t = tiles.get(i);
            int k = i - start;
            int x = cx0 + (k % 2) * (tw + 4);
            int y = py + 24 + (k / 2) * 23;
            boolean hov = mx >= x && mx <= x + tw && my >= y && my <= y + 20;
            boolean on = t.on != null && t.on.getAsBoolean();
            int border = on ? (0xFF000000 | t.swatch) : (hov ? 0xFF7050B0 : 0xFF3A2468);
            frame(g, x, y, x + tw, y + 20, on ? 0xFF241048 : (hov ? 0xFF1E0D3E : 0xFF150A2E), border);
            g.fill(x + 4, y + 6, x + 10, y + 14, 0xFF000000 | t.swatch);
            small(g, t.name, x + 14, y + 6, on ? 0xFFFFFFFF : 0xFFC0B0E8);
            if (t.on != null) {
                int bx = x + tw - 24;
                g.fill(bx, y + 6, bx + 20, y + 14, on ? (0xFF000000 | t.swatch) : 0xFF3A2E58);
                int kx = on ? bx + 12 : bx;
                g.fill(kx, y + 5, kx + 8, y + 15, on ? 0xFFFFFFFF : 0xFF8878B0);
            } else if (t.value != null) {
                String v = t.value.get();
                int vw = (int) (this.textRenderer.getWidth(v) * 0.8f);
                small(g, v, x + tw - vw - 5, y + 6, 0xFF000000 | t.swatch);
            }
        }
        // footer
        int fy = py + ph - 22;
        frame(g, cx0, fy, cx0 + 22, fy + 18, 0xFF241048, page > 0 ? ACCENT : 0xFF3A2468);
        g.drawText(this.textRenderer, "<", cx0 + 8, fy + 5, 0xFFFFFFFF, false);
        g.drawText(this.textRenderer, (page + 1) + "/" + pages(), cx0 + 28, fy + 5, 0xFFC0B0E8, false);
        frame(g, cx0 + 58, fy, cx0 + 80, fy + 18, 0xFF241048, page < pages() - 1 ? ACCENT : 0xFF3A2468);
        g.drawText(this.textRenderer, ">", cx0 + 66, fy + 5, 0xFFFFFFFF, false);
        frame(g, px + pw - 76, fy, px + pw - 6, fy + 18, 0xFF3A1A78, ACCENT);
        g.drawCenteredTextWithShadow(this.textRenderer, "Готово", px + pw - 41, fy + 5, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
