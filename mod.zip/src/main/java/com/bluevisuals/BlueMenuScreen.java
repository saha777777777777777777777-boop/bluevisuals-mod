package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class BlueMenuScreen extends Screen {
    private final Screen parent;

    public BlueMenuScreen(Screen parent) {
        super(Text.literal("Blue Visuals"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        BlueConfig c = BlueConfig.get();
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = 40;
        int step = 24;

        addToggle(x, y, w, "Armor HUD", () -> c.armorHud, v -> c.armorHud = v);
        addToggle(x, y + step, w, "Armor durability in %", () -> c.armorPercent, v -> c.armorPercent = v);
        addToggle(x, y + step * 2, w, "No fire overlay", () -> c.noFire, v -> c.noFire = v);
        addToggle(x, y + step * 3, w, "Hit particles", () -> c.hitParticles, v -> c.hitParticles = v);
        addToggle(x, y + step * 4, w, "Target hologram", () -> c.hologram, v -> c.hologram = v);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(x, y + step * 6, w, 20).build());
    }

    private void addToggle(int x, int y, int w, String name, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        ButtonWidget[] holder = new ButtonWidget[1];
        holder[0] = ButtonWidget.builder(label(name, getter.get()), b -> {
            boolean now = !getter.get();
            setter.accept(now);
            b.setMessage(label(name, now));
            BlueConfig.save();
        }).dimensions(x, y, w, 20).build();
        this.addDrawableChild(holder[0]);
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFF55AAFF);
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
