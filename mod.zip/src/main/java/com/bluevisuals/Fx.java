package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;

public class Fx {
    public static final String[] FOOT_NAMES = {"Искры", "Огонь", "Сердца", "Душа", "Облака"};
    private static boolean wasGround = true;
    private static int tick = 0;

    private static ParticleEffect foot(int i) {
        switch (Math.floorMod(i, 5)) {
            case 0:
                return ParticleTypes.END_ROD;
            case 1:
                return ParticleTypes.FLAME;
            case 2:
                return ParticleTypes.HEART;
            case 3:
                return ParticleTypes.SOUL_FIRE_FLAME;
            default:
                return ParticleTypes.CLOUD;
        }
    }

    public static void hit(LivingEntity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig cfg = BlueConfig.get();
        if (mc.world == null || e == null) {
            return;
        }
        double x = e.getX();
        double y = e.getY() + e.getHeight() * 0.6;
        double z = e.getZ();
        java.util.Random r = new java.util.Random();
        if (cfg.hitLightning) {
            for (int i = 0; i < 12; i++) {
                mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK, x, y, z, (r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.9);
            }
        }
        if (cfg.hitBlood) {
            for (int i = 0; i < 6; i++) {
                mc.world.addParticle(ParticleTypes.DAMAGE_INDICATOR, x + (r.nextDouble() - 0.5) * 0.5, y + (r.nextDouble() - 0.5) * 0.5, z + (r.nextDouble() - 0.5) * 0.5, 0.0, 0.1, 0.0);
            }
        }
        if (cfg.hitFire) {
            for (int i = 0; i < 10; i++) {
                mc.world.addParticle(ParticleTypes.FLAME, x, y, z, (r.nextDouble() - 0.5) * 0.3, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.3);
            }
        }
        if (cfg.hitMagic) {
            for (int i = 0; i < 10; i++) {
                mc.world.addParticle(ParticleTypes.ENCHANTED_HIT, x, y, z, (r.nextDouble() - 0.5) * 0.6, r.nextDouble() * 0.4, (r.nextDouble() - 0.5) * 0.6);
            }
        }
    }

    private static int lastXpLevel = -1;

    public static void kill(LivingEntity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig cfg = BlueConfig.get();
        if (!cfg.killFx || mc.world == null || e == null) {
            return;
        }
        double x = e.getX();
        double y = e.getY() + e.getHeight() / 2.0;
        double z = e.getZ();
        java.util.Random r = new java.util.Random();
        for (int i = 0; i < 40; i++) {
            mc.world.addParticle(ParticleTypes.TOTEM_OF_UNDYING, x, y, z,
                    (r.nextDouble() - 0.5) * 0.8, r.nextDouble() * 0.6, (r.nextDouble() - 0.5) * 0.8);
        }
        if (mc.player != null) {
            mc.player.playSound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.4f, 1.6f);
        }
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            BlueConfig cfg = BlueConfig.get();
            if (mc.player == null || mc.world == null || mc.isPaused()) {
                return;
            }
            tick++;
            double px = mc.player.getX();
            double py = mc.player.getY();
            double pz = mc.player.getZ();
            boolean ground = mc.player.isOnGround();
            if (cfg.jumpRing && wasGround && !ground && mc.player.getVelocity().y > 0.1) {
                for (int i = 0; i < 20; i++) {
                    double a = Math.PI * 2.0 * i / 20.0;
                    mc.world.addParticle(ParticleTypes.CLOUD, px + Math.cos(a) * 0.5, py + 0.05, pz + Math.sin(a) * 0.5,
                            Math.cos(a) * 0.12, 0.0, Math.sin(a) * 0.12);
                }
            }
            wasGround = ground;
            if (cfg.footFx) {
                double vx = mc.player.getVelocity().x;
                double vz = mc.player.getVelocity().z;
                if (vx * vx + vz * vz > 0.004 || !ground) {
                    mc.world.addParticle(foot(cfg.footStyle), px, py + 0.1, pz, 0.0, 0.02, 0.0);
                }
            }
            if (cfg.auraFx && !cfg.lite) {
                for (int k = 0; k < 2; k++) {
                    double a = tick * 0.25 + k * Math.PI;
                    mc.world.addParticle(ParticleTypes.END_ROD, px + Math.cos(a) * 0.8, py + 0.9 + Math.sin(tick * 0.1) * 0.5,
                            pz + Math.sin(a) * 0.8, 0.0, 0.0, 0.0);
                }
            }
            java.util.Random rr = new java.util.Random();
            if (!cfg.lite && tick % 2 == 0) {
                if (cfg.rainHearts) {
                    mc.world.addParticle(ParticleTypes.HEART, px + (rr.nextDouble() - 0.5) * 8.0, py + 3.0 + rr.nextDouble() * 2.0, pz + (rr.nextDouble() - 0.5) * 8.0, 0.0, -0.04, 0.0);
                }
                if (cfg.magicFx) {
                    mc.world.addParticle(ParticleTypes.ENCHANT, px + (rr.nextDouble() - 0.5) * 3.0, py + 1.5 + rr.nextDouble(), pz + (rr.nextDouble() - 0.5) * 3.0, 0.0, -0.1, 0.0);
                }
                if (cfg.portalFx) {
                    mc.world.addParticle(ParticleTypes.PORTAL, px + (rr.nextDouble() - 0.5) * 2.0, py + 1.0 + rr.nextDouble(), pz + (rr.nextDouble() - 0.5) * 2.0, (rr.nextDouble() - 0.5), -0.3, (rr.nextDouble() - 0.5));
                }
                if (cfg.notesFx) {
                    mc.world.addParticle(ParticleTypes.NOTE, px + (rr.nextDouble() - 0.5) * 2.0, py + 2.0 + rr.nextDouble() * 0.5, pz + (rr.nextDouble() - 0.5) * 2.0, rr.nextDouble(), 0.0, 0.0);
                }
                if (cfg.ashFx) {
                    mc.world.addParticle(ParticleTypes.ASH, px + (rr.nextDouble() - 0.5) * 12.0, py + 1.0 + rr.nextDouble() * 4.0, pz + (rr.nextDouble() - 0.5) * 12.0, 0.0, -0.02, 0.0);
                }
                if (cfg.petalsFx) {
                    mc.world.addParticle(ParticleTypes.CHERRY_LEAVES, px + (rr.nextDouble() - 0.5) * 12.0, py + 3.0 + rr.nextDouble() * 3.0, pz + (rr.nextDouble() - 0.5) * 12.0, 0.0, -0.03, 0.0);
                }
            }
            if (cfg.haloFx && !cfg.lite) {
                for (int k = 0; k < 2; k++) {
                    double a = tick * 0.2 + k * Math.PI;
                    mc.world.addParticle(ParticleTypes.END_ROD, px + Math.cos(a) * 0.35, py + mc.player.getHeight() + 0.25, pz + Math.sin(a) * 0.35, 0.0, 0.0, 0.0);
                }
            }
            if (cfg.flameAura && !cfg.lite) {
                double a = tick * 0.3;
                mc.world.addParticle(ParticleTypes.FLAME, px + Math.cos(a) * 0.7, py + 0.3 + (tick % 20) * 0.07, pz + Math.sin(a) * 0.7, 0.0, 0.0, 0.0);
            }
            if (cfg.helixFx && !cfg.lite) {
                double a = tick * 0.35;
                double h = (tick % 24) / 24.0 * mc.player.getHeight();
                mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, px + Math.cos(a) * 0.6, py + h, pz + Math.sin(a) * 0.6, 0.0, 0.0, 0.0);
                mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, px + Math.cos(a + Math.PI) * 0.6, py + h, pz + Math.sin(a + Math.PI) * 0.6, 0.0, 0.0, 0.0);
            }
            if (cfg.rocketTrail) {
                double vx = mc.player.getVelocity().x;
                double vz = mc.player.getVelocity().z;
                if (vx * vx + vz * vz > 0.01 && ground) {
                    mc.world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, px, py + 0.1, pz, 0.0, 0.03, 0.0);
                }
            }
            if (cfg.targetRing && mc.targetedEntity instanceof LivingEntity te && tick % 2 == 0) {
                double a = tick * 0.4;
                mc.world.addParticle(ParticleTypes.FLAME, te.getX() + Math.cos(a) * 0.8, te.getY() + 0.1, te.getZ() + Math.sin(a) * 0.8, 0.0, 0.0, 0.0);
                mc.world.addParticle(ParticleTypes.FLAME, te.getX() + Math.cos(a + Math.PI) * 0.8, te.getY() + 0.1, te.getZ() + Math.sin(a + Math.PI) * 0.8, 0.0, 0.0, 0.0);
            }
            if (cfg.levelUpFx) {
                if (lastXpLevel >= 0 && mc.player.experienceLevel > lastXpLevel) {
                    for (int i = 0; i < 30; i++) {
                        mc.world.addParticle(ParticleTypes.TOTEM_OF_UNDYING, px, py + 1.0, pz, (rr.nextDouble() - 0.5) * 0.7, rr.nextDouble() * 0.5, (rr.nextDouble() - 0.5) * 0.7);
                    }
                }
                lastXpLevel = mc.player.experienceLevel;
            } else {
                lastXpLevel = -1;
            }
            if (cfg.snowFx && !cfg.lite && tick % 2 == 0) {
                java.util.Random r = new java.util.Random();
                for (int i = 0; i < 3; i++) {
                    mc.world.addParticle(ParticleTypes.SNOWFLAKE, px + (r.nextDouble() - 0.5) * 14.0, py + 2.0 + r.nextDouble() * 4.0,
                            pz + (r.nextDouble() - 0.5) * 14.0, 0.0, -0.05, 0.0);
                }
            }
        });
    }
}
