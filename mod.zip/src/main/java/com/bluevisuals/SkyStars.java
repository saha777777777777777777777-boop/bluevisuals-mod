package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.random.Random;

public class SkyStars {
    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!BlueConfig.get().stars || mc.world == null || mc.player == null || mc.isPaused()) {
                return;
            }
            long t = mc.world.getTimeOfDay() % 24000L;
            if (t < 13000L || t > 23000L) {
                return;
            }
            Random r = mc.world.random;
            double px = mc.player.getX();
            double py = mc.player.getY();
            double pz = mc.player.getZ();
            for (int i = 0; i < 3; i++) {
                mc.world.addParticle(ParticleTypes.END_ROD,
                        px + (r.nextDouble() - 0.5) * 60.0,
                        py + 12.0 + r.nextDouble() * 18.0,
                        pz + (r.nextDouble() - 0.5) * 60.0,
                        0.0, 0.0, 0.0);
            }
            if (r.nextInt(40) == 0) {
                mc.world.addParticle(ParticleTypes.END_ROD,
                        px + (r.nextDouble() - 0.5) * 40.0,
                        py + 30.0,
                        pz + (r.nextDouble() - 0.5) * 40.0,
                        0.5, -0.4, 0.2);
            }
        });
    }
}
