package com.bluevisuals;

import com.bluevisuals.mixin.HandledScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.Slot;

import java.util.ArrayList;
import java.util.List;

public class ShulkerPreview {
    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof HandledScreen)) {
                return;
            }
            ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> {
                if (!BlueConfig.get().shulkerPreview) {
                    return;
                }
                Slot slot = ((HandledScreenAccessor) scr).bluevisuals$getFocusedSlot();
                if (slot == null || !slot.hasStack()) {
                    return;
                }
                ItemStack st = slot.getStack();
                if (!Registries.ITEM.getId(st.getItem()).getPath().endsWith("shulker_box")) {
                    return;
                }
                ContainerComponent cc = st.get(DataComponentTypes.CONTAINER);
                if (cc == null) {
                    return;
                }
                List<ItemStack> items = new ArrayList<>();
                cc.stream().forEach(items::add);
                draw(ctx, mx, my, items, scr.width);
            });
        });
    }

    private static void draw(DrawContext ctx, int mx, int my, List<ItemStack> items, int sw) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int pw = 9 * 18 + 8;
        int ph = 3 * 18 + 8;
        int x = mx + 10;
        if (x + pw > sw - 2) {
            x = mx - pw - 10;
        }
        int y = Math.max(2, my - ph - 8);
        int rgb = 0xFF000000 | BlueConfig.rgb();
        ctx.getMatrices().push();
        ctx.getMatrices().translate(0.0f, 0.0f, 600.0f);
        ctx.fill(x - 1, y - 1, x + pw + 1, y + ph + 1, rgb);
        ctx.fill(x, y, x + pw, y + ph, 0xF00C0618);
        for (int i = 0; i < 27; i++) {
            int cx = x + 4 + (i % 9) * 18;
            int cy = y + 4 + (i / 9) * 18;
            ctx.fill(cx, cy, cx + 17, cy + 17, 0x60301860);
            if (i < items.size() && !items.get(i).isEmpty()) {
                ctx.drawItem(items.get(i), cx + 1, cy + 1);
                ctx.drawStackOverlay(mc.textRenderer, items.get(i), cx + 1, cy + 1);
            }
        }
        ctx.getMatrices().pop();
    }
}
