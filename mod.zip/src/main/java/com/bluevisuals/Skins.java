package com.bluevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class Skins {
    public static final String[] TOTEM_NAMES = {"Обычный", "Пингвин", "Кубок", "Пончик"};
    public static final String[] TOTEM_FILES = {null, "BV_Totem_Penguin.zip", "BV_Totem_Cup.zip", "BV_Totem_Donut.zip"};
    public static final String[] SWORD_NAMES = {"Обычный", "Керамбит", "Дубинка", "Морковка"};
    public static final String[] SWORD_FILES = {null, "BV_Sword_Karambit.zip", "BV_Sword_Baton.zip", "BV_Sword_Carrot.zip"};

    public static void install() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Path dir = mc.runDirectory.toPath().resolve("resourcepacks");
            Files.createDirectories(dir);
            for (String[] arr : new String[][]{TOTEM_FILES, SWORD_FILES}) {
                for (String f : arr) {
                    if (f == null) {
                        continue;
                    }
                    Path target = dir.resolve(f);
                    if (Files.exists(target)) {
                        continue;
                    }
                    try (InputStream is = Skins.class.getResourceAsStream("/assets/bluevisuals/packs/" + f)) {
                        if (is != null) {
                            Files.copy(is, target, StandardCopyOption.REPLACE_EXISTING);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void apply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        install();
        ResourcePackManager m = mc.getResourcePackManager();
        m.scanPacks();
        for (String[] arr : new String[][]{TOTEM_FILES, SWORD_FILES}) {
            for (String f : arr) {
                if (f != null) {
                    m.disable("file/" + f);
                }
            }
        }
        String t = TOTEM_FILES[Math.floorMod(c.totemSkin, TOTEM_FILES.length)];
        String s = SWORD_FILES[Math.floorMod(c.swordSkin, SWORD_FILES.length)];
        if (t != null) {
            m.enable("file/" + t);
        }
        if (s != null) {
            m.enable("file/" + s);
        }
        mc.options.refreshResourcePacks(m);
        BlueConfig.save();
        mc.reloadResources();
    }
}
