package com.bluevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class Skins {
    public static final String[] TOTEM_NAMES = {"Обычный", "Пингвин", "Кубок", "Пончик", "Чёрный", "Россия", "Кристалл-ядро", "Тотем с носом", "Тукс", "Кот"};
    public static final String[] TOTEM_FILES = {null, "BV_Totem_penguin.zip", "BV_Totem_cup.zip", "BV_Totem_donut.zip", "BV_Totem_black.zip", "BV_Totem_russia.zip", "BV_Totem_crystal.zip", "BV_Totem_nose.zip", "BV_Totem_tux.zip", "BV_Totem_cat.zip"};
    public static final String[] SWORD_NAMES = {"Обычный", "Керамбит", "Дубинка", "Морковка", "М9 Сталь", "М9 Рубин", "М9 Изумруд", "М9 Аметист", "М9 Сапфир", "М9 Розовый", "Бабочка Снег", "Бабочка Обсидиан", "Керамбит Обсидиан", "Керамбит Рубин", "Нож классик"};
    public static final String[] SWORD_FILES = {null, "BV_Sword_karambit.zip", "BV_Sword_baton.zip", "BV_Sword_carrot.zip", "BV_Sword_m9steel.zip", "BV_Sword_m9ruby.zip", "BV_Sword_m9emerald.zip", "BV_Sword_m9amethyst.zip", "BV_Sword_m9sapphire.zip", "BV_Sword_m9pink.zip", "BV_Sword_bflysnow.zip", "BV_Sword_bflyobs.zip", "BV_Sword_karaobs.zip", "BV_Sword_kararuby.zip", "BV_Sword_classic.zip"};

    public static final String[] APPLE_NAMES = {"Обычное", "Сердце", "Звезда", "Кристалл"};
    public static final String[] APPLE_FILES = {null, "BV_Apple_heart.zip", "BV_Apple_star.zip", "BV_Apple_crystal.zip"};
    public static final String[] PEARL_NAMES = {"Обычный", "Глаз", "Планета", "Огненный шар"};
    public static final String[] PEARL_FILES = {null, "BV_Pearl_eye.zip", "BV_Pearl_planet.zip", "BV_Pearl_fire.zip"};

    private static String[][] all() {
        return new String[][]{TOTEM_FILES, SWORD_FILES, APPLE_FILES, PEARL_FILES};
    }

    public static void install() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Path dir = mc.runDirectory.toPath().resolve("resourcepacks");
            Files.createDirectories(dir);
            for (String[] arr : all()) {
                for (String f : arr) {
                    if (f == null) {
                        continue;
                    }
                    Path target = dir.resolve(f);
                    try (InputStream is = Skins.class.getResourceAsStream("/assets/bluevisuals/packs/" + f)) {
                        if (is != null) {
                            byte[] data = is.readAllBytes();
                            if (Files.exists(target) && Files.size(target) == data.length) {
                                continue;
                            }
                            Files.write(target, data);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void apply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlueConfig c = BlueConfig.get();
        install();
        ResourcePackManager m = mc.getResourcePackManager();
        m.scanPacks();
        for (String[] arr : all()) {
            for (String f : arr) {
                if (f != null) {
                    m.disable("file/" + f);
                }
            }
        }
        String t = TOTEM_FILES[Math.floorMod(c.totemSkin, TOTEM_FILES.length)];
        String s = SWORD_FILES[Math.floorMod(c.swordSkin, SWORD_FILES.length)];
        String a = APPLE_FILES[Math.floorMod(c.appleSkin, APPLE_FILES.length)];
        String p = PEARL_FILES[Math.floorMod(c.pearlSkin, PEARL_FILES.length)];
        for (String f : new String[]{t, s, a, p}) {
            if (f != null) {
                m.enable("file/" + f);
            }
        }
        mc.options.refreshResourcePacks(m);
        BlueConfig.save();
    }
}
