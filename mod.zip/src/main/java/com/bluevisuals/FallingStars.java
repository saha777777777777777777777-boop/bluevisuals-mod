package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FallingStars {
    private static class Star {
        double x, y, z, px, py, pz, vx, vy, vz;
        int age, life;
    }

    private static final List<Star> STARS = new ArrayList<>();

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.world == null || mc.player == null || !BlueConfig.get().fallingStars) {
                STARS.clear();
                return;
            }
            if (mc.isPaused()) {
                return;
            }
            Random r = mc.world.random;
            double ppx = mc.player.getX();
            double ppy = mc.player.getY();
            double ppz = mc.player.getZ();

            boolean lite = BlueConfig.get().lite;
            if (STARS.size() < (lite ? 5 : 25) && r.nextInt(lite ? 25 : 8) == 0) {
                Star s = new Star();
                s.x = ppx + (r.nextDouble() - 0.5) * 90.0;
                s.y = ppy + 45.0 + r.nextDouble() * 20.0;
                s.z = ppz + (r.nextDouble() - 0.5) * 90.0;
                s.px = s.x;
                s.py = s.y;
                s.pz = s.z;
                s.vx = (r.nextDouble() - 0.5) * 0.5;
                s.vy = -(0.5 + r.nextDouble() * 0.4);
                s.vz = (r.nextDouble() - 0.5) * 0.5;
                s.life = 70 + r.nextInt(40);
                STARS.add(s);
            }

            Iterator<Star> it = STARS.iterator();
            while (it.hasNext()) {
                Star s = it.next();
                s.px = s.x;
                s.py = s.y;
                s.pz = s.z;
                s.x += s.vx;
                s.y += s.vy;
                s.z += s.vz;
                s.age++;
                if (s.age > s.life || s.y < ppy - 5.0) {
                    it.remove();
                }
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!BlueConfig.get().fallingStars || STARS.isEmpty()) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null || ctx.matrixStack() == null || ctx.consumers() == null) {
                return;
            }
            float td = ctx.tickCounter().getTickDelta(false);
            Vec3d cam = ctx.camera().getPos();
            VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
            MatrixStack.Entry entry = ctx.matrixStack().peek();
            int rgb = BlueConfig.rgb();
            int cr = (rgb >> 16) & 0xFF;
            int cg = (rgb >> 8) & 0xFF;
            int cb = rgb & 0xFF;

            for (Star s : STARS) {
                float x = (float) (MathHelper.lerp(td, s.px, s.x) - cam.x);
                float y = (float) (MathHelper.lerp(td, s.py, s.y) - cam.y);
                float z = (float) (MathHelper.lerp(td, s.pz, s.z) - cam.z);
                float fade = MathHelper.clamp((1.0f - (float) s.age / s.life) * 1.5f, 0.0f, 1.0f);
                int a = (int) (255 * fade);

                double len = Math.sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz);
                float nx = (float) (s.vx / len);
                float ny = (float) (s.vy / len);
                float nz = (float) (s.vz / len);

                // tail
                line(vc, entry, x, y, z, a, x - (float) s.vx * 8.0f, y - (float) s.vy * 8.0f, z - (float) s.vz * 8.0f, 0,
                        nx, ny, nz, cr, cg, cb);
                // star cross at the head
                float c = 0.45f;
                line(vc, entry, x - c, y, z, a, x + c, y, z, a, 1, 0, 0, cr, cg, cb);
                line(vc, entry, x, y - c, z, a, x, y + c, z, a, 0, 1, 0, cr, cg, cb);
                line(vc, entry, x, y, z - c, a, x, y, z + c, a, 0, 0, 1, cr, cg, cb);
            }
        });
    }

    private static void line(VertexConsumer vc, MatrixStack.Entry e,
                             float x1, float y1, float z1, int a1,
                             float x2, float y2, float z2, int a2,
                             float nx, float ny, float nz, int cr, int cg, int cb) {
        vc.vertex(e, x1, y1, z1).color(cr, cg, cb, a1).normal(e, nx, ny, nz);
        vc.vertex(e, x2, y2, z2).color(cr, cg, cb, a2).normal(e, nx, ny, nz);
    }
}
