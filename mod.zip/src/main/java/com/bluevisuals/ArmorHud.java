package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public static void register() {
        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            BlueConfig cfg = BlueConfig.get();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!cfg.armorHud || mc.player == null || mc.options.hudHidden) {
                return;
            }
            int x = ctx.getScaledWindowWidth() / 2 - 91;
            int y = ctx.getScaledWindowHeight() - 62;
            for (EquipmentSlot slot : SLOTS) {
                ItemStack stack = mc.player.getEquippedStack(slot);
                if (stack.isEmpty()) {
                    continue;
                }
                ctx.drawItem(stack, x, y);
                if (stack.isDamageable()) {
                    int max = stack.getMaxDamage();
                    int left = max - stack.getDamage();
                    String text = cfg.armorPercent ? (left * 100 / max) + "%" : left + "";
                    ctx.drawText(mc.textRenderer, text, x + 17, y + 4, 0xFF8CC8FF, true);
                }
                x += 44;
            }
        });
    }
}
