package com.bluevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class ScreenSparks {
    public static void register() {
        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            BlueConfig cfg = BlueConfig.get();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!cfg.sparks || cfg.lite || Perf.skip() || mc.player == null || mc.options.hudHidden) {
                return;
            }
            int w = mc.getWindow().getScaledWidth();
            int h = mc.getWindow().getScaledHeight();
            double t = System.currentTimeMillis() / 1000.0;
            int rgb = BlueConfig.rgb();
            for (int i = 0; i < 40; i++) {
                double sx = frac(Math.sin(i * 12.9898) * 43758.5453);
                double sy = frac(Math.sin(i * 78.233) * 12345.6789);
                double sp = 0.02 + frac(Math.sin(i * 3.7) * 999.1) * 0.04;
                double ph = frac(Math.sin(i * 5.1) * 777.7) * 6.28;
                int x = (int) (sx * w + Math.sin(t * 0.6 + ph) * 6);
                int y = (int) (((sy + t * sp) % 1.0) * h);
                double tw = 0.5 + 0.5 * Math.sin(t * 2.5 + ph);
                int a = (int) (40 + 150 * tw);
                int col = (a << 24) | rgb;
                ctx.fill(x, y, x + 2, y + 2, col);
                if (i % 4 == 0) {
                    int a2 = a / 2;
                    int col2 = (a2 << 24) | rgb;
                    ctx.fill(x - 2, y, x, y + 2, col2);
                    ctx.fill(x + 2, y, x + 4, y + 2, col2);
                    ctx.fill(x, y - 2, x + 2, y, col2);
                    ctx.fill(x, y + 2, x + 2, y + 4, col2);
                }
            }
        });
    }

    private static double frac(double v) {
        return v - Math.floor(v);
    }
}
