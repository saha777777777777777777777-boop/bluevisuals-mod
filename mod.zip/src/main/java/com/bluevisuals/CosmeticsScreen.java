package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class CosmeticsScreen extends Screen {
    private final Screen parent;

    public CosmeticsScreen(Screen parent) {
        super(Text.literal("Косметика"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        BlueConfig c = BlueConfig.get();
        int w = 150;
        int lx = this.width / 2 - 155;
        int rx = this.width / 2 + 5;
        int y = 34;
        int step = 22;

        addToggle(lx, y, w, "Крылья", () -> c.wings, v -> c.wings = v);
        this.addDrawableChild(ButtonWidget.builder(styleLabel(), b -> {
            c.wingStyle = (c.wingStyle + 1) % Cosmetics.STYLES.length;
            b.setMessage(styleLabel());
            BlueConfig.save();
        }).dimensions(lx, y + step, w, 20).build());
        addToggle(lx, y + step * 2, w, "Противогаз", () -> c.mask, v -> c.mask = v);
        addToggle(lx, y + step * 3, w, "Бронежилет", () -> c.vest, v -> c.vest = v);
        addToggle(lx, y + step * 4, w, "Что в шалкере", () -> c.shulkerPreview, v -> c.shulkerPreview = v);
        addToggle(rx, y, w, "Щиты вокруг", () -> c.shields, v -> c.shields = v);
        addToggle(rx, y + step, w, "На других игроках", () -> c.cosOthers, v -> c.cosOthers = v);
        this.addDrawableChild(ButtonWidget.builder(colorLabel(), b -> {
            c.cosColorIndex = (c.cosColorIndex + 1) % BlueConfig.COLOR_RGB.length;
            b.setMessage(colorLabel());
            BlueConfig.save();
        }).dimensions(rx, y + step * 2, w, 20).build());
        addToggle(rx, y + step * 3, w, "Искры на экране", () -> c.sparks, v -> c.sparks = v);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), b -> this.close())
                .dimensions(this.width / 2 - 75, y + step * 5 + 8, 150, 20).build());
    }

    private static Text styleLabel() {
        return Text.literal("Вид: " + Cosmetics.STYLES[Math.floorMod(BlueConfig.get().wingStyle, Cosmetics.STYLES.length)]);
    }

    private static Text colorLabel() {
        return Text.literal("Цвет: " + BlueConfig.COLOR_NAMES[Math.floorMod(BlueConfig.get().cosColorIndex, BlueConfig.COLOR_NAMES.length)]);
    }

    private void addToggle(int x, int y, int w, String name, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        this.addDrawableChild(ButtonWidget.builder(label(name, getter.get()), b -> {
            boolean now = !getter.get();
            setter.accept(now);
            b.setMessage(label(name, now));
            BlueConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, 0xFF14062B, 0xFF030208);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 16, 0xFF000000 | BlueConfig.cosRgb());
    }

    @Override
    public void close() {
        BlueConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
