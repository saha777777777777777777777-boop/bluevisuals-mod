package com.bluevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class Perf {
    private static boolean low = false;
    private static long lowUntil = 0;
    private static long nextCheck = 0;
    private static int badCount = 0;

    public static boolean skip() {
        return low && BlueConfig.get().fpsGuard;
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long now = System.currentTimeMillis();
            if (now < nextCheck) {
                return;
            }
            nextCheck = now + 1000;
            if (mc.world == null) {
                return;
            }
            int fps = mc.getCurrentFps();
            if (low) {
                if (now > lowUntil) {
                    low = false;
                    badCount = 0;
                }
                return;
            }
            if (fps > 0 && fps < 15) {
                badCount++;
            } else {
                badCount = 0;
            }
            if (badCount >= 2) {
                low = true;
                lowUntil = now + 20000;
            }
        });
    }
}
