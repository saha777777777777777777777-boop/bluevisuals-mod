package com.bluevisuals;

import net.minecraft.client.gui.DrawContext;

public class Theme {
    public static final String[] MODE_NAMES = {"Авто (по дате)", "Классика", "Новый год", "Масленица", "Лето", "Осень"};

    // accent, bgTop, bgBot, panel, tile0, tile1, tile2, dim, btn
    private static final int[][] P = {
            {0xFFA060FF, 0xFF160733, 0xFF030208, 0xDD0E0520, 0xFF150A2E, 0xFF1E0D3E, 0xFF241048, 0xFF3A2468, 0xFF3A1A78},
            {0xFFFF4A5A, 0xFF0B1E3F, 0xFF020712, 0xDD08142B, 0xFF0F2347, 0xFF16305E, 0xFF1F3F7A, 0xFF2B4670, 0xFF7A1F2B},
            {0xFFFFB02E, 0xFF3A1E08, 0xFF120801, 0xDD2A1505, 0xFF3A2108, 0xFF4A2C0C, 0xFF5C3A10, 0xFF6A4A22, 0xFF8A5510},
            {0xFF3CE08A, 0xFF06384A, 0xFF021018, 0xDD042A36, 0xFF073A48, 0xFF0B4D5E, 0xFF106070, 0xFF2A6A70, 0xFF107A55},
            {0xFFFF7A2E, 0xFF3A1208, 0xFF100403, 0xDD2A0D06, 0xFF3A1A0E, 0xFF4A2412, 0xFF5E2E16, 0xFF6A3A22, 0xFF8A3A12},
    };

    // 0 classic, 1 new year, 2 maslenitsa, 3 summer, 4 autumn
    public static int season() {
        int mode = Math.floorMod(BlueConfig.get().themeMode, MODE_NAMES.length);
        if (mode >= 1) {
            return mode - 1;
        }
        int m = java.time.LocalDate.now().getMonthValue();
        if (m == 12 || m == 1) {
            return 1;
        }
        if (m >= 2 && m <= 5) {
            return 2;
        }
        if (m >= 6 && m <= 8) {
            return 3;
        }
        return 4;
    }

    private static int p(int i) {
        return P[season()][i];
    }

    public static int accent() { return p(0); }
    public static int panel() { return p(3); }
    public static int t0() { return p(4); }
    public static int t1() { return p(5); }
    public static int t2() { return p(6); }
    public static int dim() { return p(7); }
    public static int btn() { return p(8); }

    public static String greeting() {
        switch (season()) {
            case 1:
                return "С Новым годом!";
            case 2:
                return "Весёлой Масленицы!";
            case 3:
                return "Тёплого лета!";
            case 4:
                return "Золотая осень";
            default:
                return "";
        }
    }

    public static void background(DrawContext g, int w, int h) {
        int s = season();
        g.fillGradient(0, 0, w, h, p(1), p(2));
        long t = net.minecraft.util.Util.getMeasuringTimeMs();
        boolean lite = BlueConfig.get().lite;
        java.util.Random r = new java.util.Random(1337L);
        int n = lite ? 0 : 150;
        if (s == 0) {
            for (int i = 0; i < n; i++) {
                int x = r.nextInt(Math.max(1, w));
                int y = r.nextInt(Math.max(1, h));
                int kind = r.nextInt(3);
                double ph = r.nextDouble() * 6.28;
                int a = (int) (80 + 120 * (0.5 + 0.5 * Math.sin(t / 600.0 + ph)));
                int rgb = kind == 0 ? 0xC9A8FF : (kind == 1 ? 0x8A4DFF : 0xFFFFFF);
                g.fill(x, y, x + 1, y + 1, (a << 24) | rgb);
            }
            return;
        }
        for (int i = 0; i < n; i++) {
            double sp = 8.0 + r.nextDouble() * 22.0;
            double bx = r.nextDouble() * w;
            double by = r.nextDouble() * h;
            double ph = r.nextDouble() * 6.28;
            int kind = r.nextInt(4);
            int x;
            int y;
            int col;
            int sz = 1 + r.nextInt(2);
            if (s == 1) {
                y = (int) ((by + t / 1000.0 * sp) % h);
                x = (int) (bx + Math.sin(t / 1500.0 + ph) * 6.0);
                col = 0xE0FFFFFF;
            } else if (s == 2) {
                y = (int) (h - ((h - by) + t / 1000.0 * sp * 0.6) % h);
                x = (int) (bx + Math.sin(t / 1300.0 + ph) * 5.0);
                col = kind == 0 ? 0xE0FFE08A : (kind == 1 ? 0xE0FFB02E : 0xC0FFF4C0);
                sz = 2;
            } else if (s == 3) {
                y = (int) ((by + Math.sin(t / 2000.0 + ph) * 8.0 + h) % h);
                x = (int) (bx + Math.cos(t / 1700.0 + ph) * 8.0);
                int a = (int) (90 + 130 * (0.5 + 0.5 * Math.sin(t / 500.0 + ph)));
                col = (a << 24) | (kind == 0 ? 0xFFF08A : (kind == 1 ? 0x7CFFB0 : 0x8AE8FF));
            } else {
                y = (int) ((by + t / 1000.0 * sp) % h);
                x = (int) (bx + Math.sin(t / 900.0 + ph) * 10.0);
                col = 0xE0000000 | (kind == 0 ? 0xFF7A2E : (kind == 1 ? 0xE0A020 : (kind == 2 ? 0xC0392B : 0x8B4513)));
                sz = 3;
            }
            g.fill(x, y, x + sz, y + sz, col);
        }
        if (s == 1) {
            // garland
            for (int x = 0; x < w; x += 10) {
                int y = 3 + (int) (3.0 * Math.sin(x / 40.0));
                g.fill(x, y, x + 10, y + 1, 0xFF1B5E20);
                int[] cols = {0xFFFF3030, 0xFFFFD040, 0xFF40FF70, 0xFF4090FF};
                int on = ((int) (t / 500L) + x / 10) % 4;
                int cc = cols[(x / 10) % 4];
                int al = on == 0 ? 0xFF : 0x90;
                g.fill(x + 3, y + 1, x + 6, y + 5, (al << 24) | (cc & 0xFFFFFF));
            }
        } else if (s == 2 || s == 3) {
            int cx = w - 30;
            int cy = 28;
            int rad = 11;
            for (int dy = -rad; dy <= rad; dy++) {
                int dx = (int) Math.sqrt(rad * rad - dy * dy);
                g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, 0xFFFFD84A);
            }
            for (int k = 0; k < 12; k++) {
                double a = k * Math.PI / 6.0 + t / 4000.0;
                int x1 = cx + (int) (Math.cos(a) * (rad + 4));
                int y1 = cy + (int) (Math.sin(a) * (rad + 4));
                g.fill(x1, y1, x1 + 2, y1 + 2, 0xFFFFD84A);
            }
        }
    }
}
