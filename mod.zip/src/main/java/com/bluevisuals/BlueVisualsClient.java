package com.bluevisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class BlueVisualsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlueConfig.load();

        KeyBinding menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bluevisuals.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.bluevisuals"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new BlueMenuScreen(client.currentScreen));
            }
        });

        // Button in the pause menu (works on phone, no keyboard needed)
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Blue Visuals"),
                        b -> client.setScreen(new BlueMenuScreen(screen))).dimensions(w - 106, h / 2 - 10, 100, 20).build());
            }
        });

        ArmorHud.register();
        HitEffects.register();
        HologramRenderer.register();
        SkyStars.register();
        HealthTags.register();
        FallingStars.register();
    }
}
