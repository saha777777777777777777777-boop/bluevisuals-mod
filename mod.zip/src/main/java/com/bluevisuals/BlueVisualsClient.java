package com.bluevisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BlueVisualsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlueConfig.load();

        KeyBinding menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bluevisuals.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.bluevisuals"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new BlueMenuScreen(client.currentScreen));
            }
        });

        ArmorHud.register();
        HitEffects.register();
        HologramRenderer.register();
        SkyStars.register();
        HealthTags.register();
        FallingStars.register();
        MarkerRenderer.register();
        PearlPath.register();
        SkyTint.register();
    }
}
