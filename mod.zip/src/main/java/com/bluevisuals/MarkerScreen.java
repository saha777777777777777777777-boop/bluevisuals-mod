package com.bluevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class MarkerScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget fx;
    private TextFieldWidget fy;
    private TextFieldWidget fz;
    private TextFieldWidget fname;

    public MarkerScreen(Screen parent) {
        super(Text.literal("Метки"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = 28;

        fx = new TextFieldWidget(this.textRenderer, cx - 95, y, 60, 20, Text.literal("X"));
        fy = new TextFieldWidget(this.textRenderer, cx - 30, y, 60, 20, Text.literal("Y"));
        fz = new TextFieldWidget(this.textRenderer, cx + 35, y, 60, 20, Text.literal("Z"));
        fx.setPlaceholder(Text.literal("X"));
        fy.setPlaceholder(Text.literal("Y"));
        fz.setPlaceholder(Text.literal("Z"));
        this.addDrawableChild(fx);
        this.addDrawableChild(fy);
        this.addDrawableChild(fz);

        fname = new TextFieldWidget(this.textRenderer, cx - 95, y + 24, 190, 20, Text.literal("Название"));
        fname.setPlaceholder(Text.literal("Название метки"));
        fname.setMaxLength(24);
        this.addDrawableChild(fname);

        int w = 150;
        int lx = cx - 155;
        int rx = cx + 5;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Добавить по X Y Z"), b -> addAtCoords())
                .dimensions(lx, y + 50, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Добавить где стою"), b -> addHere())
                .dimensions(rx, y + 50, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Удалить последнюю"), b -> {
            java.util.List<BlueConfig.Marker> l = BlueConfig.get().markers;
            if (!l.isEmpty()) {
                l.remove(l.size() - 1);
                BlueConfig.save();
            }
        }).dimensions(lx, y + 74, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Удалить все"), b -> {
            BlueConfig.get().markers.clear();
            BlueConfig.save();
        }).dimensions(rx, y + 74, w, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), b -> this.close())
                .dimensions(cx - 100, y + 114, 200, 20).build());
    }

    private String nameOrDefault() {
        String n = fname.getText().trim();
        return n.isEmpty() ? "Метка " + (BlueConfig.get().markers.size() + 1) : n;
    }

    private void addHere() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) {
            return;
        }
        BlueConfig.get().markers.add(new BlueConfig.Marker(mc.player.getX(), mc.player.getY(), mc.player.getZ(), nameOrDefault()));
        BlueConfig.save();
        fname.setText("");
    }

    private void addAtCoords() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            double x = Double.parseDouble(fx.getText().trim());
            double z = Double.parseDouble(fz.getText().trim());
            String ys = fy.getText().trim();
            double y = ys.isEmpty() ? (mc.player != null ? mc.player.getY() : 64.0) : Double.parseDouble(ys);
            BlueConfig.get().markers.add(new BlueConfig.Marker(x, y, z, nameOrDefault()));
            BlueConfig.save();
            fname.setText("");
        } catch (NumberFormatException ignored) {
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, 0xFF14062B, 0xFF030208);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int color = 0xFF000000 | BlueConfig.rgb();
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, color);
        MinecraftClient mc = MinecraftClient.getInstance();
        String info = "Меток: " + BlueConfig.get().markers.size();
        if (mc.player != null) {
            info += "   Вы тут: " + (int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ();
        }
        context.drawCenteredTextWithShadow(this.textRenderer, info, this.width / 2, 28 + 100, 0xFFC9A8FF);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
